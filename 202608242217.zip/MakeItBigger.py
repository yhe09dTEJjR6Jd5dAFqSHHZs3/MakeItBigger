import sys
sys.dont_write_bytecode = True

import os
import math
import time
import json
import random
import re
import threading
import subprocess
import colorsys
import hashlib
import shutil
from pathlib import Path

if os.name != "nt":
    raise SystemExit("MakeItBigger.py requires Windows 11 x64.")

import ctypes
from ctypes import wintypes
import tkinter as tk
from tkinter import filedialog, messagebox

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

ULONG_PTR = ctypes.c_size_t
LRESULT = ctypes.c_ssize_t
INPUT_TAG = 0x4D4942472026
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_XDOWN = 0x0080
MOUSEEVENTF_XUP = 0x0100
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_HWHEEL = 0x01000
MOUSEEVENTF_VIRTUALDESK = 0x4000
MOUSEEVENTF_ABSOLUTE = 0x8000
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
KEYEVENTF_SCANCODE = 0x0008
MOUSEEVENTF_MOVE_NOCOALESCE = 0x2000
WH_KEYBOARD_LL = 13
WH_MOUSE_LL = 14
WM_QUIT = 0x0012
GA_ROOT = 2

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", INPUTUNION)]

class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("pt", wintypes.POINT), ("mouseData", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
kernel32.GetModuleHandleW.argtypes = (wintypes.LPCWSTR,)
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
user32.SendInput.restype = wintypes.UINT
user32.GetForegroundWindow.restype = wintypes.HWND
user32.WindowFromPoint.argtypes = (wintypes.POINT,)
user32.WindowFromPoint.restype = wintypes.HWND
user32.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
user32.GetAncestor.restype = wintypes.HWND
user32.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
user32.GetClassNameW.restype = ctypes.c_int
user32.GetWindowTextLengthW.argtypes = (wintypes.HWND,)
user32.GetWindowTextLengthW.restype = ctypes.c_int
user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
user32.GetWindowTextW.restype = ctypes.c_int
user32.SetWindowsHookExW.argtypes = (ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD)
user32.SetWindowsHookExW.restype = wintypes.HHOOK
user32.CallNextHookEx.argtypes = (wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
user32.CallNextHookEx.restype = LRESULT
user32.UnhookWindowsHookEx.argtypes = (wintypes.HHOOK,)
user32.UnhookWindowsHookEx.restype = wintypes.BOOL
user32.PostThreadMessageW.argtypes = (wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
user32.PostThreadMessageW.restype = wintypes.BOOL
try:
    user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
except Exception:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass

SW_HIDE = 0
console = kernel32.GetConsoleWindow()
if console:
    user32.ShowWindow(console, SW_HIDE)

SYSTEM_DRIVE = os.environ.get("SystemDrive", "C:").upper().rstrip("\\/")

root = tk.Tk()
root.withdraw()
root.update_idletasks()

while True:
    chosen = filedialog.askdirectory(title="选择非系统盘文件夹")
    if not chosen:
        root.destroy()
        raise SystemExit
    chosen_path = Path(chosen).resolve()
    drive = chosen_path.drive.upper().rstrip("\\/")
    if drive and drive != SYSTEM_DRIVE:
        break
    messagebox.showerror("请选择非系统盘", f"系统盘是 {SYSTEM_DRIVE}。请选择其他磁盘上的文件夹。")

app_dir = chosen_path / ".makeitbigger"
deps_dir = app_dir / "deps"
temp_dir = app_dir / "temp"
app_dir.mkdir(parents=True, exist_ok=True)
deps_dir.mkdir(parents=True, exist_ok=True)
temp_dir.mkdir(parents=True, exist_ok=True)
for key in ("TMP", "TEMP", "TMPDIR", "PIP_CACHE_DIR"):
    os.environ[key] = str(temp_dir)
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["PYTHONNOUSERSITE"] = "1"
os.environ["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
os.environ["PIP_NO_INPUT"] = "1"
os.environ["PIP_PROGRESS_BAR"] = "off"
os.environ["PIP_CONFIG_FILE"] = os.devnull
os.environ["OPENCV_LOG_LEVEL"] = "SILENT"
if str(deps_dir) not in sys.path:
    sys.path.insert(0, str(deps_dir))

root.title("Make It Bigger")
root.geometry("320x170")
root.resizable(False, False)
root.protocol("WM_DELETE_WINDOW", lambda: shutdown())

status_var = tk.StringVar(value="正在准备本地自建识别器…")
status = tk.Label(root, textvariable=status_var, anchor="center", justify="center", wraplength=280)
status.pack(pady=(24, 14))
number_button = tk.Button(root, text="数", font=("Segoe UI", 22), width=6, state="disabled")
number_button.pack()
root.deiconify()
root.lift()

np = None
cv2 = None
Image = None
ImageGrab = None
ImageDraw = None
ImageFont = None

def ui_status(text):
    if root.winfo_exists():
        root.after(0, lambda: status_var.set(text))


def bootstrap_dependencies():
    global np, cv2, Image, ImageGrab, ImageDraw, ImageFont
    marker = deps_dir / ".ready-v2"
    for repair_round in range(2):
        if not marker.exists():
            ui_status("首次运行：正在把运行依赖安装到所选文件夹…" if repair_round == 0 else "正在自动修复本地运行依赖…")
            cmd = [
                sys.executable, "-m", "pip", "install", "--no-cache-dir", "--disable-pip-version-check",
                "--only-binary=:all:", "--upgrade", "--target", str(deps_dir),
                "numpy>=1.26,<3", "Pillow>=10,<13", "opencv-python-headless>=4.10,<5"
            ]
            ok = False
            for attempt in range(3):
                result = subprocess.run(
                    cmd, cwd=str(app_dir), env=os.environ.copy(),
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
                if result.returncode == 0:
                    ok = True
                    break
                time.sleep(1.0 + attempt * 1.5)
            if not ok:
                root.after(0, lambda: dependency_failed("本地运行依赖自动准备失败。"))
                return
            marker.write_text("2", encoding="ascii")
        try:
            import importlib
            importlib.invalidate_caches()
            import numpy as _np
            import cv2 as _cv2
            from PIL import Image as _Image, ImageGrab as _ImageGrab, ImageDraw as _ImageDraw, ImageFont as _ImageFont
            np, cv2 = _np, _cv2
            Image, ImageGrab, ImageDraw, ImageFont = _Image, _ImageGrab, _ImageDraw, _ImageFont
            root.after(0, build_runtime)
            return
        except Exception:
            try:
                marker.unlink(missing_ok=True)
            except Exception:
                pass
    root.after(0, lambda: dependency_failed("本地运行依赖加载失败。"))


def dependency_failed(text):
    status_var.set(text)
    number_button.config(state="disabled")


def _same_number(a, b):
    try:
        return math.isclose(float(a), float(b), rel_tol=1e-9, abs_tol=1e-9)
    except Exception:
        return False


def _number_key(value):
    number = float(value)
    if math.isfinite(number) and number.is_integer():
        return ("i", int(number))
    return ("f", round(number, 12))


def _format_number(value):
    value = float(value)
    if math.isfinite(value) and value.is_integer():
        return str(int(value))
    return format(value, ".15g")


class LocalDigitRecognizer:
    LABELS = tuple("0123456789+-.,")
    MODEL_VERSION = "self-trained-digit-mlp-v2"
    INPUT_SHAPE = (28, 20)
    HIDDEN = 96

    def __init__(self):
        self.model_path = app_dir / "digit_model.npz"
        self.label_to_index = {label: i for i, label in enumerate(self.LABELS)}
        if not self._load_model():
            ui_status("正在用本机生成的样本训练数字视觉模型…")
            self._train_model()
            self._save_model()

    def _font_paths(self):
        windir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
        preferred = [
            "segoeui.ttf", "seguisb.ttf", "arial.ttf", "arialbd.ttf", "calibri.ttf", "calibrib.ttf",
            "consola.ttf", "consolab.ttf", "tahoma.ttf", "verdana.ttf", "times.ttf", "trebuc.ttf",
            "cour.ttf", "courbd.ttf", "georgia.ttf", "impact.ttf"
        ]
        found = []
        for name in preferred:
            path = windir / name
            if path.exists():
                found.append(path)
        for pattern in ("*.ttf", "*.otf", "*.ttc"):
            for path in sorted(windir.glob(pattern)):
                if path not in found:
                    found.append(path)
        usable = []
        for path in found:
            try:
                ImageFont.truetype(str(path), 32)
                usable.append(path)
            except Exception:
                continue
        if not usable:
            raise RuntimeError("找不到可用的 Windows 字体。")
        return usable

    def _normalize_mask(self, mask):
        mask = np.asarray(mask, dtype=np.uint8)
        ys, xs = np.where(mask > 0)
        if len(xs) == 0:
            return np.zeros(self.INPUT_SHAPE, dtype=np.float32).reshape(-1)
        crop = mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        h, w = crop.shape
        target_h, target_w = self.INPUT_SHAPE
        scale = min((target_w - 4.0) / max(w, 1), (target_h - 4.0) / max(h, 1))
        nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
        interpolation = cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LINEAR
        resized = cv2.resize(crop, (nw, nh), interpolation=interpolation)
        out = np.zeros((target_h, target_w), dtype=np.uint8)
        x0 = (target_w - nw) // 2
        y0 = (target_h - nh) // 2
        out[y0:y0 + nh, x0:x0 + nw] = resized
        return out.astype(np.float32).reshape(-1) / 255.0

    def _augment_mask(self, mask, rng):
        arr = np.asarray(mask, dtype=np.uint8)
        h, w = arr.shape
        angle = rng.uniform(-10.0, 10.0)
        scale_x = rng.uniform(0.76, 1.24)
        scale_y = rng.uniform(0.78, 1.22)
        matrix = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
        matrix[0, 0] *= scale_x
        matrix[0, 1] *= scale_x
        matrix[1, 0] *= scale_y
        matrix[1, 1] *= scale_y
        matrix[0, 2] += rng.uniform(-5.0, 5.0)
        matrix[1, 2] += rng.uniform(-5.0, 5.0)
        arr = cv2.warpAffine(arr, matrix, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
        if rng.random() < 0.65:
            shift = rng.uniform(-0.10, 0.10) * w
            src = np.float32([[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]])
            dst = np.float32([[shift, 0], [w - 1 - shift, 0], [-shift, h - 1], [w - 1 + shift, h - 1]])
            perspective = cv2.getPerspectiveTransform(src, dst)
            arr = cv2.warpPerspective(arr, perspective, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
        if rng.random() < 0.48:
            k = rng.choice((2, 3))
            kernel = np.ones((k, k), dtype=np.uint8)
            if rng.random() < 0.5:
                arr = cv2.dilate(arr, kernel, iterations=1)
            else:
                arr = cv2.erode(arr, kernel, iterations=1)
        if rng.random() < 0.55:
            sigma = rng.uniform(0.15, 1.05)
            arr = cv2.GaussianBlur(arr, (0, 0), sigmaX=sigma, sigmaY=sigma)
        if rng.random() < 0.52:
            noise_rng = np.random.default_rng(rng.getrandbits(64))
            noise = noise_rng.normal(0.0, 13.0, size=arr.shape).astype(np.float32)
            arr = np.clip(arr.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        threshold = rng.randint(45, 175)
        _, arr = cv2.threshold(arr, threshold, 255, cv2.THRESH_BINARY)
        return arr

    def _font_sample(self, label, font_path, rng):
        canvas = Image.new("L", (88, 88), 0)
        draw = ImageDraw.Draw(canvas)
        size = rng.randint(22, 66)
        font = ImageFont.truetype(str(font_path), size)
        stroke = rng.randint(0, 2)
        bbox = draw.textbbox((0, 0), label, font=font, stroke_width=stroke)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        x = 44 - tw // 2 - bbox[0] + rng.randint(-5, 5)
        y = 44 - th // 2 - bbox[1] + rng.randint(-5, 5)
        draw.text((x, y), label, fill=255, font=font, stroke_width=stroke, stroke_fill=255)
        return self._augment_mask(np.asarray(canvas), rng)

    def _seven_segment_sample(self, label, rng):
        canvas = np.zeros((88, 88), dtype=np.uint8)
        thickness = rng.randint(3, 8)
        left = rng.randint(17, 24)
        right = rng.randint(62, 70)
        top = rng.randint(12, 18)
        middle = rng.randint(40, 46)
        bottom = rng.randint(70, 77)
        segments = {
            "a": ((left + 4, top), (right - 4, top)),
            "b": ((right, top + 4), (right, middle - 4)),
            "c": ((right, middle + 4), (right, bottom - 4)),
            "d": ((left + 4, bottom), (right - 4, bottom)),
            "e": ((left, middle + 4), (left, bottom - 4)),
            "f": ((left, top + 4), (left, middle - 4)),
            "g": ((left + 4, middle), (right - 4, middle)),
        }
        digits = {
            "0": "ab cdef".replace(" ", ""), "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg",
            "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg"
        }
        if label in digits:
            for name in digits[label]:
                p0, p1 = segments[name]
                cv2.line(canvas, p0, p1, 255, thickness=thickness, lineType=cv2.LINE_AA)
        elif label == "-":
            p0, p1 = segments["g"]
            cv2.line(canvas, p0, p1, 255, thickness=thickness, lineType=cv2.LINE_AA)
        elif label == "+":
            p0, p1 = segments["g"]
            cv2.line(canvas, p0, p1, 255, thickness=thickness, lineType=cv2.LINE_AA)
            cv2.line(canvas, ((left + right) // 2, top + 12), ((left + right) // 2, bottom - 12), 255, thickness=thickness, lineType=cv2.LINE_AA)
        elif label in ".,":
            cx = rng.randint(42, 51)
            cy = rng.randint(68, 77)
            cv2.circle(canvas, (cx, cy), max(2, thickness // 2), 255, -1, lineType=cv2.LINE_AA)
            if label == ",":
                cv2.line(canvas, (cx, cy + 1), (cx - rng.randint(2, 5), min(86, cy + rng.randint(7, 12))), 255, max(1, thickness // 2), lineType=cv2.LINE_AA)
        return self._augment_mask(canvas, rng)

    def _make_training_set(self):
        rng = random.Random(731921)
        fonts = self._font_paths()
        features = []
        labels = []
        for label in self.LABELS:
            font_rounds = 46 if label in ".," else 40
            for _ in range(font_rounds):
                mask = self._font_sample(label, rng.choice(fonts), rng)
                feat = self._normalize_mask(mask)
                if feat.sum() >= 2.0:
                    features.append(feat)
                    labels.append(self.label_to_index[label])
            synth_rounds = 34 if label.isdigit() else 20
            for _ in range(synth_rounds):
                mask = self._seven_segment_sample(label, rng)
                feat = self._normalize_mask(mask)
                if feat.sum() >= 2.0:
                    features.append(feat)
                    labels.append(self.label_to_index[label])
        x = np.asarray(features, dtype=np.float32)
        y = np.asarray(labels, dtype=np.int32)
        order = np.random.default_rng(731921).permutation(len(x))
        return x[order], y[order]

    def _forward(self, x):
        hidden = np.maximum(0.0, x @ self.w1 + self.b1)
        logits = hidden @ self.w2 + self.b2
        logits -= logits.max(axis=1, keepdims=True)
        exp = np.exp(logits)
        probs = exp / np.maximum(exp.sum(axis=1, keepdims=True), 1e-8)
        return hidden, probs

    def _train_model(self):
        x, y = self._make_training_set()
        if len(x) < 300:
            raise RuntimeError("本机训练样本不足。")
        split = max(1, int(len(x) * 0.90))
        train_x, train_y = x[:split], y[:split]
        valid_x, valid_y = x[split:], y[split:]
        rng = np.random.default_rng(731921)
        input_dim = train_x.shape[1]
        output_dim = len(self.LABELS)
        self.w1 = (rng.standard_normal((input_dim, self.HIDDEN)).astype(np.float32) * math.sqrt(2.0 / input_dim))
        self.b1 = np.zeros((self.HIDDEN,), dtype=np.float32)
        self.w2 = (rng.standard_normal((self.HIDDEN, output_dim)).astype(np.float32) * math.sqrt(2.0 / self.HIDDEN))
        self.b2 = np.zeros((output_dim,), dtype=np.float32)
        params = [self.w1, self.b1, self.w2, self.b2]
        moments = [np.zeros_like(param) for param in params]
        variances = [np.zeros_like(param) for param in params]
        best_weights = [param.copy() for param in params]
        best_score = -1.0
        step = 0
        batch = 96
        for _ in range(32):
            order = rng.permutation(len(train_x))
            for start in range(0, len(order), batch):
                idx = order[start:start + batch]
                xb = train_x[idx]
                yb = train_y[idx]
                hidden, probs = self._forward(xb)
                grad = probs.copy()
                grad[np.arange(len(yb)), yb] -= 1.0
                grad /= max(1, len(yb))
                gw2 = hidden.T @ grad + self.w2 * 0.0001
                gb2 = grad.sum(axis=0)
                gh = grad @ self.w2.T
                gh[hidden <= 0.0] = 0.0
                gw1 = xb.T @ gh + self.w1 * 0.0001
                gb1 = gh.sum(axis=0)
                step += 1
                for i, gradient in enumerate((gw1, gb1, gw2, gb2)):
                    moments[i] *= 0.9
                    moments[i] += gradient * 0.1
                    variances[i] *= 0.999
                    variances[i] += gradient * gradient * 0.001
                    m_hat = moments[i] / (1.0 - 0.9 ** step)
                    v_hat = variances[i] / (1.0 - 0.999 ** step)
                    params[i] -= 0.003 * m_hat / (np.sqrt(v_hat) + 1e-8)
            if len(valid_x):
                _, valid_probs = self._forward(valid_x)
                score = float(np.mean(np.argmax(valid_probs, axis=1) == valid_y))
                if score > best_score:
                    best_score = score
                    best_weights = [param.copy() for param in params]
        self.w1[:], self.b1[:], self.w2[:], self.b2[:] = best_weights
        self.centroids = np.zeros((output_dim, input_dim), dtype=np.float32)
        self.radii = np.zeros((output_dim,), dtype=np.float32)
        for idx in range(output_dim):
            members = x[y == idx]
            center = members.mean(axis=0)
            self.centroids[idx] = center
            distances = np.mean((members - center) ** 2, axis=1)
            self.radii[idx] = max(0.012, float(np.quantile(distances, 0.985)) * 2.2)

    def _save_model(self):
        tmp = app_dir / "digit_model.tmp.npz"
        np.savez_compressed(
            tmp, version=np.asarray([self.MODEL_VERSION]), labels=np.asarray(self.LABELS),
            w1=self.w1, b1=self.b1, w2=self.w2, b2=self.b2,
            centroids=self.centroids, radii=self.radii
        )
        os.replace(tmp, self.model_path)

    def _load_model(self):
        try:
            with np.load(self.model_path, allow_pickle=False) as data:
                version = str(data["version"][0])
                labels = tuple(str(v) for v in data["labels"].tolist())
                if version != self.MODEL_VERSION or labels != self.LABELS:
                    return False
                w1 = np.asarray(data["w1"], dtype=np.float32)
                b1 = np.asarray(data["b1"], dtype=np.float32)
                w2 = np.asarray(data["w2"], dtype=np.float32)
                b2 = np.asarray(data["b2"], dtype=np.float32)
                centroids = np.asarray(data["centroids"], dtype=np.float32)
                radii = np.asarray(data["radii"], dtype=np.float32)
            if w1.shape != (self.INPUT_SHAPE[0] * self.INPUT_SHAPE[1], self.HIDDEN):
                return False
            if w2.shape != (self.HIDDEN, len(self.LABELS)) or centroids.shape != (len(self.LABELS), w1.shape[0]):
                return False
            if b1.shape != (self.HIDDEN,) or b2.shape != (len(self.LABELS),) or radii.shape != (len(self.LABELS),):
                return False
            self.w1, self.b1, self.w2, self.b2 = w1, b1, w2, b2
            self.centroids, self.radii = centroids, radii
            return True
        except Exception:
            return False

    def _classify_mask(self, crop):
        feat = self._normalize_mask(crop)
        if feat.sum() < 2.0:
            return None
        _, probs = self._forward(feat.reshape(1, -1))
        row = probs[0]
        order = np.argsort(row)[::-1]
        best_idx = int(order[0])
        second_idx = int(order[1])
        best_prob = float(row[best_idx])
        margin = best_prob - float(row[second_idx])
        distance = float(np.mean((feat - self.centroids[best_idx]) ** 2))
        label = self.LABELS[best_idx]
        min_prob = 0.32 if label in "+-.," else 0.35
        if best_prob < min_prob or margin < 0.06 or distance > float(self.radii[best_idx]):
            return None
        distance_score = max(0.0, 1.0 - distance / max(float(self.radii[best_idx]), 1e-6))
        return label, max(0.0, min(1.0, best_prob * 0.72 + distance_score * 0.28))

    def _parse_number_text(self, text):
        text = str(text).strip()
        if not text or not re.fullmatch(r"[+-]?(?:\d+[.,]?\d*|[.,]\d+)(?:[.,]\d+)*", text):
            return None
        sign = 1
        body = text
        if body[0] in "+-":
            if body[0] == "-":
                sign = -1
            body = body[1:]
        if not any(ch.isdigit() for ch in body):
            return None
        dots = [i for i, ch in enumerate(body) if ch == "."]
        commas = [i for i, ch in enumerate(body) if ch == ","]
        decimal_sep = None
        if dots and commas:
            decimal_sep = "." if dots[-1] > commas[-1] else ","
        elif dots:
            parts = body.split(".")
            if len(parts) > 2:
                if not all(len(part) == 3 for part in parts[1:]):
                    return None
            else:
                decimal_sep = "."
        elif commas:
            parts = body.split(",")
            if len(parts) > 2:
                if not all(len(part) == 3 for part in parts[1:]):
                    return None
            elif len(parts) == 2 and 1 <= len(parts[0]) <= 3 and len(parts[1]) == 3:
                decimal_sep = None
            else:
                decimal_sep = ","
        if decimal_sep is None:
            digits = body.replace(",", "").replace(".", "")
            return sign * int(digits) if digits.isdigit() else None
        other = "," if decimal_sep == "." else "."
        body = body.replace(other, "")
        if body.count(decimal_sep) > 1:
            head, tail = body.rsplit(decimal_sep, 1)
            body = head.replace(decimal_sep, "") + decimal_sep + tail
        normalized = body.replace(decimal_sep, ".")
        if normalized.startswith("."):
            normalized = "0" + normalized
        if normalized.endswith("."):
            normalized += "0"
        try:
            return sign * float(normalized)
        except ValueError:
            return None

    def _best_numeric_span(self, selected):
        best = None
        for i in range(len(selected)):
            for j in range(i + 1, len(selected) + 1):
                span = selected[i:j]
                text = "".join(char["char"] for char in span)
                value = self._parse_number_text(text)
                if value is None:
                    continue
                digit_count = sum(char["char"].isdigit() for char in span)
                if digit_count == 0:
                    continue
                mean_conf = sum(float(char["conf"]) for char in span) / len(span)
                score = digit_count * 2.0 + len(span) * 0.35 + mean_conf
                if best is None or score > best[0]:
                    best = (score, span, value, text)
        return best

    def _candidate_masks(self, gray):
        h_img, w_img = gray.shape
        block = 31 if min(h_img, w_img) >= 31 else max(3, min(h_img, w_img) | 1)
        adaptive_inv = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, block, 9)
        adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block, 9)
        _, otsu_inv = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        close_kernel = np.ones((5, 5), dtype=np.uint8)
        return [
            adaptive_inv, adaptive, otsu_inv, otsu,
            cv2.morphologyEx(adaptive_inv, cv2.MORPH_CLOSE, close_kernel, iterations=1),
            cv2.morphologyEx(adaptive, cv2.MORPH_CLOSE, close_kernel, iterations=1),
        ]

    def _char_overlap_fraction(self, a, b):
        x0 = max(a[0], b[0])
        y0 = max(a[1], b[1])
        x1 = min(a[2], b[2])
        y1 = min(a[3], b[3])
        inter = max(0, x1 - x0) * max(0, y1 - y0)
        area_a = max(1, (a[2] - a[0]) * (a[3] - a[1]))
        area_b = max(1, (b[2] - b[0]) * (b[3] - b[1]))
        return inter / float(min(area_a, area_b))

    def _add_char(self, chars, item):
        new_box = item["box"]
        new_area = max(1, (new_box[2] - new_box[0]) * (new_box[3] - new_box[1]))
        for old in chars:
            old_box = old["box"]
            overlap = self._char_overlap_fraction(new_box, old_box)
            if overlap < 0.82:
                continue
            old_area = max(1, (old_box[2] - old_box[0]) * (old_box[3] - old_box[1]))
            if new_area > old_area * 1.22 and float(item["conf"]) >= float(old["conf"]) - 0.12:
                old.update(item)
            elif old_area <= new_area * 1.22 and float(item["conf"]) > float(old["conf"]):
                old.update(item)
            return
        chars.append(item)

    def _repair_punctuation(self, chars):
        for item in chars:
            box = item["box"]
            h = max(1, box[3] - box[1])
            w = max(1, box[2] - box[0])
            if w / float(h) > 1.65 or item.get("char") in "+-":
                continue
            neighbors = []
            cx = (box[0] + box[2]) / 2.0
            for other in chars:
                if other is item:
                    continue
                ob = other["box"]
                oh = max(1, ob[3] - ob[1])
                ocx = (ob[0] + ob[2]) / 2.0
                if oh >= h * 1.8 and abs(ocx - cx) <= oh * 5.5 and abs(ob[3] - box[3]) <= oh * 0.38:
                    neighbors.append(oh)
            if not neighbors:
                continue
            reference = sorted(neighbors)[len(neighbors) // 2]
            if h <= reference * 0.42 and w <= reference * 0.42:
                item["char"] = "," if h > w * 1.45 else "."
                item["conf"] = max(float(item.get("conf", 0.0)), 0.86)

    def _mser_chars(self, gray):
        h_img, w_img = gray.shape
        detector = cv2.MSER_create()
        detector.setMinArea(3)
        detector.setMaxArea(max(64, int(h_img * w_img * 0.025)))
        _, boxes = detector.detectRegions(gray)
        seen = set()
        chars = []
        for raw in boxes:
            x, y, w, h = (int(raw[0]), int(raw[1]), int(raw[2]), int(raw[3]))
            key = (x, y, w, h)
            if key in seen:
                continue
            seen.add(key)
            if h < 2 or h > min(640, h_img * 0.70) or w < 1 or w > min(520, w_img * 0.45):
                continue
            aspect = w / float(max(h, 1))
            if aspect < 0.035 or aspect > 8.0:
                continue
            pad = max(1, int(round(max(h, w) * 0.05)))
            x0, y0 = max(0, x - pad), max(0, y - pad)
            x1, y1 = min(w_img, x + w + pad), min(h_img, y + h + pad)
            crop = gray[y0:y1, x0:x1]
            _, light = cv2.threshold(crop, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
            dark = 255 - light
            choices = [candidate for candidate in (self._classify_mask(light), self._classify_mask(dark)) if candidate is not None]
            if not choices:
                continue
            label, conf = max(choices, key=lambda candidate: candidate[1])
            if label in ".," and h > max(20, int(w * 3.0)):
                continue
            self._add_char(chars, {"char": label, "conf": conf, "box": (x, y, x + w, y + h)})
        return chars

    def detect(self, pil_image, origin):
        rgb = np.asarray(pil_image.convert("RGB"))
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        h_img, w_img = gray.shape
        chars = []
        for mask in self._candidate_masks(gray):
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                if h < 2 or h > min(640, h_img * 0.70) or w < 1 or w > min(520, w_img * 0.45):
                    continue
                aspect = w / float(max(h, 1))
                if aspect < 0.035 or aspect > 8.0:
                    continue
                area = cv2.contourArea(contour)
                fill_ratio = area / float(max(1, w * h))
                if area < 3 or fill_ratio < 0.018 or (fill_ratio > 0.94 and w * h > 600):
                    continue
                pad = max(1, int(round(max(h, w) * 0.07)))
                x0, y0 = max(0, x - pad), max(0, y - pad)
                x1, y1 = min(w_img, x + w + pad), min(h_img, y + h + pad)
                result = self._classify_mask(mask[y0:y1, x0:x1])
                if result is None:
                    continue
                label, conf = result
                if label in ".," and h > max(20, int(w * 3.0)):
                    continue
                self._add_char(chars, {"char": label, "conf": conf, "box": (x, y, x + w, y + h)})
        for item in self._mser_chars(gray):
            self._add_char(chars, item)
        self._repair_punctuation(chars)
        chars.sort(key=lambda char: (char["box"][1], char["box"][0]))
        groups = []
        used = set()
        for i, char in enumerate(chars):
            if i in used:
                continue
            line = [i]
            box = char["box"]
            cy = (box[1] + box[3]) / 2.0
            hh = max(1, box[3] - box[1])
            for j in range(i + 1, len(chars)):
                if j in used:
                    continue
                other = chars[j]["box"]
                hj = max(1, other[3] - other[1])
                cyj = (other[1] + other[3]) / 2.0
                center_close = abs(cyj - cy) <= 0.55 * max(hh, hj)
                baseline_close = abs(other[3] - box[3]) <= 0.42 * max(hh, hj)
                punctuation = char["char"] in "+-.," or chars[j]["char"] in "+-.,"
                ratio_ok = 0.38 <= hj / max(hh, 1) <= 2.7
                if (center_close and (ratio_ok or punctuation)) or (punctuation and baseline_close):
                    line.append(j)
            line.sort(key=lambda idx: chars[idx]["box"][0])
            seq = [line[0]]
            for idx in line[1:]:
                prev = chars[seq[-1]]["box"]
                curr = chars[idx]["box"]
                gap = curr[0] - prev[2]
                typical_h = max(1, prev[3] - prev[1], curr[3] - curr[1])
                if gap <= typical_h * 0.85:
                    seq.append(idx)
            if len(seq) >= 1:
                selected = [chars[idx] for idx in seq]
                best = self._best_numeric_span(selected)
                if best is not None:
                    _, span, value, text = best
                    gx0 = min(item["box"][0] for item in span)
                    gy0 = min(item["box"][1] for item in span)
                    gx1 = max(item["box"][2] for item in span)
                    gy1 = max(item["box"][3] for item in span)
                    confidence = sum(float(item["conf"]) for item in span) / len(span)
                    groups.append({
                        "value": value, "text": text, "box": (gx0 + origin[0], gy0 + origin[1], gx1 + origin[0], gy1 + origin[1]),
                        "conf": confidence
                    })
                    for idx in seq:
                        used.add(idx)
        return self._dedupe_groups(groups)

    def _dedupe_groups(self, groups):
        groups.sort(key=lambda group: (group["conf"], len(group["text"])), reverse=True)
        kept = []
        for group in groups:
            duplicate = False
            for old in kept:
                if self._iou(group["box"], old["box"]) > 0.60:
                    duplicate = True
                    break
            if not duplicate:
                kept.append(group)
        return kept[:48]

    def _iou(self, a, b):
        x0 = max(a[0], b[0])
        y0 = max(a[1], b[1])
        x1 = min(a[2], b[2])
        y1 = min(a[3], b[3])
        inter = max(0, x1 - x0) * max(0, y1 - y0)
        area_a = max(1, (a[2] - a[0]) * (a[3] - a[1]))
        area_b = max(1, (b[2] - b[0]) * (b[3] - b[1]))
        return inter / float(area_a + area_b - inter)


class LearningController:
    STATE_VERSION = 5
    MAX_STORED_POLICY_BYTES = 98304
    VALID_OPS = ("mouse_abs", "mouse_rel", "mouse_button", "wheel", "key_event", "unicode_event", "unicode_text", "raw_mouse", "raw_keyboard", "wait")

    def __init__(self):
        self.state_path = app_dir / "learning.json"
        self._limit_cache = None
        self._limit_cache_until = 0.0
        self.state = self._load_state()
        self.running = False
        self.interrupting = False
        self.stop_event = threading.Event()
        self.overlay_mode = False
        self.last_user_activity = time.monotonic()
        self.target = None
        self.original_target = None
        self.current_value = None
        self.target_identity = None
        self.overlays = []
        self.overlay_targets = []
        self.hook_thread_id = 0
        self.mouse_hook = None
        self.keyboard_hook = None
        self.mouse_proc = None
        self.keyboard_proc = None
        self.held_keys = set()
        self.held_mouse = set()
        self.lock = threading.Lock()

    def _fresh_state(self):
        return {
            "version": self.STATE_VERSION, "trials": 0, "successes": 0, "best_gain": 0.0,
            "contexts": {}, "success_memory": []
        }

    def _storage_limits(self):
        now = time.monotonic()
        if self._limit_cache is not None and now < self._limit_cache_until:
            return self._limit_cache
        try:
            usage = shutil.disk_usage(app_dir)
            total_gib = usage.total / float(1 << 30)
            free_gib = usage.free / float(1 << 30)
        except Exception:
            total_gib, free_gib = 128.0, 8.0
        if total_gib >= 512.0 and free_gib >= 64.0:
            limits = {"programs": 512, "contexts": 128, "memory": 1024, "history": 32, "bytes": 24 << 20}
        elif total_gib >= 256.0 and free_gib >= 16.0:
            limits = {"programs": 384, "contexts": 96, "memory": 768, "history": 24, "bytes": 16 << 20}
        elif total_gib >= 96.0 and free_gib >= 4.0:
            limits = {"programs": 256, "contexts": 64, "memory": 512, "history": 18, "bytes": 10 << 20}
        else:
            limits = {"programs": 128, "contexts": 48, "memory": 256, "history": 12, "bytes": 6 << 20}
        self._limit_cache = limits
        self._limit_cache_until = now + 30.0
        return limits

    def _normalize_program(self, program):
        if not isinstance(program, list):
            return []
        out = []
        for source in program:
            if not isinstance(source, dict):
                continue
            kind = source.get("op")
            if kind not in self.VALID_OPS:
                continue
            op = dict(source)
            op["op"] = kind
            out.append(op)
        try:
            if len(json.dumps(out, ensure_ascii=False, separators=(",", ":")).encode("utf-8")) > self.MAX_STORED_POLICY_BYTES:
                return []
        except Exception:
            return []
        return out

    def _load_state(self):
        fresh = self._fresh_state()
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or int(data.get("version", -1)) != self.STATE_VERSION:
                return fresh
            fresh["trials"] = max(0, int(data.get("trials", 0)))
            fresh["successes"] = max(0, int(data.get("successes", 0)))
            fresh["best_gain"] = float(data.get("best_gain", 0.0))
            contexts = data.get("contexts", {})
            if isinstance(contexts, dict):
                for key, source_ctx in contexts.items():
                    if not isinstance(source_ctx, dict):
                        continue
                    ctx = {
                        "programs": [], "best_policy": None, "challenger": None,
                        "champion_history": [], "trials": max(0, int(source_ctx.get("trials", 0))),
                        "last_used": max(0, int(source_ctx.get("last_used", 0)))
                    }
                    source_programs = source_ctx.get("programs", [])
                    if isinstance(source_programs, list):
                        for source_rec in source_programs:
                            rec = self._load_record(source_rec)
                            if rec is not None:
                                ctx["programs"].append(rec)
                    best = self._load_policy(source_ctx.get("best_policy"))
                    if best is not None:
                        ctx["best_policy"] = best
                    challenger = self._load_challenger(source_ctx.get("challenger"))
                    if challenger is not None:
                        ctx["challenger"] = challenger
                    history = source_ctx.get("champion_history", [])
                    if isinstance(history, list):
                        for item in history:
                            loaded = self._load_policy(item)
                            if loaded is not None:
                                ctx["champion_history"].append(loaded)
                    fresh["contexts"][str(key)] = ctx
            memory = data.get("success_memory", [])
            if isinstance(memory, list):
                for source in memory:
                    if not isinstance(source, dict):
                        continue
                    program = self._normalize_program(source.get("program"))
                    fingerprint = str(source.get("fingerprint", ""))
                    if not program or not fingerprint:
                        continue
                    fresh["success_memory"].append({
                        "window": str(source.get("window", "")), "fingerprint": fingerprint, "program": program,
                        "n": max(1, int(source.get("n", 1))), "reward_sum": float(source.get("reward_sum", 0.0)),
                        "gain_sum": float(source.get("gain_sum", 0.0)), "best_reward": float(source.get("best_reward", 0.0)),
                        "best_gain": float(source.get("best_gain", 0.0)), "last_seen": max(0, int(source.get("last_seen", 0)))
                    })
            self.state = fresh
            self._compact_state()
            return fresh
        except Exception:
            return fresh

    def _load_record(self, source):
        if not isinstance(source, dict):
            return None
        program = self._normalize_program(source.get("program"))
        fingerprint = str(source.get("fingerprint", ""))
        if not program or not fingerprint:
            return None
        n = max(0, int(source.get("n", 0)))
        return {
            "fingerprint": fingerprint, "program": program, "n": n, "wins": max(0, int(source.get("wins", 0))),
            "q": float(source.get("q", 0.0)), "best_gain": float(source.get("best_gain", 0.0)),
            "best_reward": float(source.get("best_reward", 0.0)), "total_reward": float(source.get("total_reward", 0.0)),
            "total_gain": float(source.get("total_gain", 0.0)), "last_seen": max(0, int(source.get("last_seen", 0))),
            "blocked_until": max(0, int(source.get("blocked_until", 0)))
        }

    def _load_eval(self, source):
        if not isinstance(source, dict):
            return {"n": 0, "wins": 0, "reward_sum": 0.0, "gain_sum": 0.0}
        return {
            "n": max(0, int(source.get("n", 0))), "wins": max(0, int(source.get("wins", 0))),
            "reward_sum": float(source.get("reward_sum", 0.0)), "gain_sum": float(source.get("gain_sum", 0.0))
        }

    def _load_policy(self, source):
        if not isinstance(source, dict):
            return None
        program = self._normalize_program(source.get("program"))
        fingerprint = str(source.get("fingerprint", ""))
        if not program or not fingerprint:
            return None
        return {
            "fingerprint": fingerprint, "program": program, "accepted_trial": max(0, int(source.get("accepted_trial", 0))),
            "success_floor": max(0.0, min(1.0, float(source.get("success_floor", 0.0)))),
            "gain_floor": max(0.0, float(source.get("gain_floor", 0.0))),
            "reward_floor": float(source.get("reward_floor", -1e9)), "evidence": self._load_eval(source.get("evidence"))
        }

    def _load_challenger(self, source):
        if not isinstance(source, dict):
            return None
        program = self._normalize_program(source.get("program"))
        fingerprint = str(source.get("fingerprint", ""))
        if not program or not fingerprint:
            return None
        return {
            "fingerprint": fingerprint, "program": program, "started_trial": max(0, int(source.get("started_trial", 0))),
            "candidate_eval": self._load_eval(source.get("candidate_eval")),
            "incumbent_eval": self._load_eval(source.get("incumbent_eval"))
        }

    def _save_state(self):
        self.state["version"] = self.STATE_VERSION
        self._compact_state()
        limits = self._storage_limits()
        payload = self._fit_state_payload(limits["bytes"])
        tmp = app_dir / "learning.tmp"
        tmp.write_text(payload, encoding="utf-8")
        os.replace(tmp, self.state_path)

    def _fit_state_payload(self, max_bytes):
        def encode():
            return json.dumps(self.state, ensure_ascii=False, separators=(",", ":"))

        payload = encode()
        if len(payload.encode("utf-8")) <= max_bytes:
            return payload
        self._compact_state(aggressive=True)
        payload = encode()
        if len(payload.encode("utf-8")) <= max_bytes:
            return payload
        memory = self.state.get("success_memory", [])
        if isinstance(memory, list):
            while memory and len(payload.encode("utf-8")) > max_bytes:
                del memory[max(1, len(memory) // 2):]
                payload = encode()
        contexts = self.state.get("contexts", {})
        for cap in (96, 64, 32, 16, 8):
            if len(payload.encode("utf-8")) <= max_bytes:
                break
            for ctx in contexts.values():
                self._compact_context(ctx, cap, max(2, min(6, cap // 8)))
            payload = encode()
        while len(payload.encode("utf-8")) > max_bytes and len(contexts) > 1:
            victim = min(contexts.items(), key=lambda pair: self._context_quality(pair[1]))[0]
            del contexts[victim]
            payload = encode()
        if len(payload.encode("utf-8")) > max_bytes and contexts:
            only = next(iter(contexts.values()))
            only["programs"] = sorted(only.get("programs", []), key=self._record_quality, reverse=True)[:2]
            only["champion_history"] = only.get("champion_history", [])[-1:]
            payload = encode()
        return payload

    def _policy_fingerprint(self, program, target):
        x0, y0, x1, y1 = target["box"]
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        scale = max(8.0, y1 - y0)
        canonical = []
        for op in program:
            kind = op.get("op")
            if kind == "mouse_abs":
                canonical.append((kind, round((float(op.get("x", cx)) - cx) / scale * 4.0) / 4.0,
                                  round((float(op.get("y", cy)) - cy) / scale * 4.0) / 4.0,
                                  self._time_bucket(op.get("duration", 0.0))))
            elif kind == "mouse_rel":
                canonical.append((kind, round(float(op.get("dx", 0)) / scale * 4.0) / 4.0,
                                  round(float(op.get("dy", 0)) / scale * 4.0) / 4.0,
                                  self._time_bucket(op.get("duration", 0.0)), bool(op.get("no_coalesce", False))))
            elif kind == "mouse_button":
                canonical.append((kind, str(op.get("button", "left")), bool(op.get("down", True))))
            elif kind == "wheel":
                canonical.append((kind, int(round(float(op.get("delta", 0)) / 120.0)), bool(op.get("horizontal", False))))
            elif kind == "key_event":
                canonical.append((kind, str(op.get("mode", "vk")), int(op.get("code", 0)) & 0xFFFF,
                                  bool(op.get("down", True)), bool(op.get("extended", False))))
            elif kind == "unicode_event":
                canonical.append((kind, int(op.get("unit", 0)) & 0xFFFF, bool(op.get("down", True))))
            elif kind == "unicode_text":
                text = str(op.get("text", ""))
                number = recognizer._parse_number_text(text) if recognizer is not None else None
                if number is not None:
                    number = float(number)
                    text_key = ("numeric", self._magnitude_bucket(number), 1 if number >= 0 else -1)
                else:
                    text_key = ("text", hashlib.blake2b(text.encode("utf-8", "replace"), digest_size=6).hexdigest())
                canonical.append((kind, text_key, self._time_bucket(op.get("interval", 0.0))))
            elif kind == "raw_mouse":
                canonical.append((kind, round(float(op.get("dx", 0)) / scale * 2.0) / 2.0,
                                  round(float(op.get("dy", 0)) / scale * 2.0) / 2.0,
                                  int(op.get("data", 0)) & 0xFFFFFFFF, int(op.get("flags", 0)) & 0xFFFFFFFF))
            elif kind == "raw_keyboard":
                canonical.append((kind, int(op.get("vk", 0)) & 0xFFFF, int(op.get("scan", 0)) & 0xFFFF,
                                  int(op.get("flags", 0)) & 0xFFFFFFFF))
            elif kind == "wait":
                canonical.append((kind, self._time_bucket(op.get("seconds", 0.0))))
        raw = json.dumps(canonical, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return hashlib.blake2b(raw, digest_size=12).hexdigest()

    def _time_bucket(self, value):
        seconds = max(0.0, float(value))
        return int(round(math.log1p(seconds) * 12.0))

    def _magnitude_bucket(self, value):
        magnitude = abs(float(value))
        if magnitude < 1e-12:
            return 0
        return int(round(math.log10(magnitude) * 8.0))

    def _record_quality(self, rec):
        n = max(1, int(rec.get("n", 0)))
        rate = int(rec.get("wins", 0)) / n
        gain = float(rec.get("total_gain", 0.0)) / n
        reward = float(rec.get("total_reward", 0.0)) / n
        confidence = 1.0 - math.exp(-n / 8.0)
        weak_penalty = 1.0 if n >= 8 and rate < 0.05 and gain <= 0.0 and reward < -0.1 else 0.0
        return rate * 4.0 + math.log1p(max(0.0, gain)) * 0.55 + reward * 0.65 + float(rec.get("q", 0.0)) * 0.35 + confidence * 0.20 - weak_penalty

    def _memory_quality(self, item):
        n = max(1, int(item.get("n", 1)))
        return (float(item.get("gain_sum", 0.0)) / n, float(item.get("reward_sum", 0.0)) / n, math.log1p(n), int(item.get("last_seen", 0)))

    def _compact_context(self, ctx, program_cap, history_cap):
        protected = set()
        best = ctx.get("best_policy")
        challenger = ctx.get("challenger")
        if isinstance(best, dict):
            protected.add(best.get("fingerprint"))
        if isinstance(challenger, dict):
            protected.add(challenger.get("fingerprint"))
        records = list(ctx.get("programs", []))
        records.sort(key=lambda rec: (rec.get("fingerprint") in protected, self._record_quality(rec), int(rec.get("last_seen", 0))), reverse=True)
        ctx["programs"] = records[:max(1, int(program_cap))]
        history = list(ctx.get("champion_history", []))
        ctx["champion_history"] = history[-max(1, int(history_cap)):]

    def _context_quality(self, ctx):
        best = ctx.get("best_policy")
        best_score = 0.0
        if isinstance(best, dict):
            best_score = float(best.get("success_floor", 0.0)) * 5.0 + math.log1p(float(best.get("gain_floor", 0.0)))
        return best_score + math.log1p(max(0, int(ctx.get("trials", 0)))) * 0.08 + int(ctx.get("last_used", 0)) * 1e-9

    def _compact_state(self, aggressive=False):
        if not hasattr(self, "state"):
            return
        limits = self._storage_limits()
        program_cap = max(128, limits["programs"] // (2 if aggressive else 1))
        history_cap = max(6, limits["history"] // (2 if aggressive else 1))
        for ctx in self.state.get("contexts", {}).values():
            if isinstance(ctx, dict):
                self._compact_context(ctx, program_cap, history_cap)
        contexts = self.state.get("contexts", {})
        context_cap = max(24, limits["contexts"] // (2 if aggressive else 1))
        if isinstance(contexts, dict) and len(contexts) > context_cap:
            ranked = sorted(contexts.items(), key=lambda pair: self._context_quality(pair[1]), reverse=True)
            self.state["contexts"] = dict(ranked[:context_cap])
        memory = self.state.get("success_memory", [])
        if isinstance(memory, list):
            memory.sort(key=self._memory_quality, reverse=True)
            memory_cap = max(128, limits["memory"] // (2 if aggressive else 1))
            del memory[memory_cap:]

    def _eval_update(self, stats, reward, gain):
        stats["n"] = int(stats.get("n", 0)) + 1
        if reward > 0:
            stats["wins"] = int(stats.get("wins", 0)) + 1
        stats["reward_sum"] = float(stats.get("reward_sum", 0.0)) + float(reward)
        stats["gain_sum"] = float(stats.get("gain_sum", 0.0)) + float(gain)

    def _wilson_lower(self, wins, n, z=1.2815515655446004):
        n = max(0, int(n))
        if n == 0:
            return 0.0
        p = max(0.0, min(1.0, float(wins) / n))
        denom = 1.0 + z * z / n
        center = p + z * z / (2.0 * n)
        margin = z * math.sqrt((p * (1.0 - p) + z * z / (4.0 * n)) / n)
        return max(0.0, (center - margin) / denom)

    def _policy_from_evidence(self, program, fingerprint, evidence):
        n = max(1, int(evidence.get("n", 0)))
        wins = max(0, int(evidence.get("wins", 0)))
        avg_gain = float(evidence.get("gain_sum", 0.0)) / n
        avg_reward = float(evidence.get("reward_sum", 0.0)) / n
        return {
            "fingerprint": fingerprint, "program": json.loads(json.dumps(program)),
            "accepted_trial": int(self.state.get("trials", 0)),
            "success_floor": self._wilson_lower(wins, n),
            "gain_floor": max(0.0, avg_gain * 0.92), "reward_floor": avg_reward - 0.08,
            "evidence": dict(evidence)
        }

    def select_target(self, target):
        chosen = dict(target)
        self.target = chosen
        self.original_target = dict(chosen)
        self.current_value = chosen["value"]
        self.target_identity = {
            "initial_box": list(chosen["box"]),
            "window": None,
            "context": None,
        }

    def _cursor_pos(self):
        pt = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        return (pt.x, pt.y)

    def _window_signature(self, target):
        x0, y0, x1, y1 = target["box"]
        pt = wintypes.POINT(int((x0 + x1) / 2), int((y0 + y1) / 2))
        hwnd = user32.WindowFromPoint(pt)
        if hwnd:
            root_hwnd = user32.GetAncestor(hwnd, GA_ROOT)
            if root_hwnd:
                hwnd = root_hwnd
        if not hwnd:
            hwnd = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(hwnd)
        title_buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
        class_buf = ctypes.create_unicode_buffer(128)
        user32.GetClassNameW(hwnd, class_buf, len(class_buf))
        title = title_buf.value.strip()[:64]
        cls = class_buf.value.strip()[:48]
        return f"{cls}|{title}"

    def _context_key(self, target):
        sw = max(1, user32.GetSystemMetrics(78))
        sh = max(1, user32.GetSystemMetrics(79))
        x0, y0, x1, y1 = target["box"]
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        locx = int(10 * (cx - virtual_origin()[0]) / sw)
        locy = int(10 * (cy - virtual_origin()[1]) / sh)
        signature = self._window_signature(target)
        return f"{signature}|{locx},{locy}|d{len(str(self.original_target.get('text', self.original_target['value'])))}|h{int((y1-y0)/6)}"

    def _context_descriptor(self, image, origin, box):
        x0, y0, x1, y1 = box
        bw = max(6, x1 - x0)
        bh = max(6, y1 - y0)
        margin_x = max(28, int(bw * 3.4))
        margin_y = max(24, int(bh * 2.8))
        ix0 = max(0, int(x0 - margin_x - origin[0]))
        iy0 = max(0, int(y0 - margin_y - origin[1]))
        ix1 = min(image.width, int(x1 + margin_x - origin[0]))
        iy1 = min(image.height, int(y1 + margin_y - origin[1]))
        if ix1 - ix0 < 12 or iy1 - iy0 < 12:
            return None
        gray = np.asarray(image.crop((ix0, iy0, ix1, iy1)).convert("L"), dtype=np.uint8).copy()
        tx0 = max(0, int(x0 - origin[0] - ix0 - bw * 0.25))
        ty0 = max(0, int(y0 - origin[1] - iy0 - bh * 0.25))
        tx1 = min(gray.shape[1], int(x1 - origin[0] - ix0 + bw * 0.25))
        ty1 = min(gray.shape[0], int(y1 - origin[1] - iy0 + bh * 0.25))
        fill = int(np.median(gray))
        gray[ty0:ty1, tx0:tx1] = fill
        small = cv2.resize(gray, (30, 24), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
        mean = float(small.mean())
        std = float(small.std())
        if std > 0.03:
            small = (small - mean) / std
            small = np.clip((small + 3.0) / 6.0, 0.0, 1.0)
        return small.reshape(-1).tolist()

    def _ensure_identity_context(self, image, origin):
        if self.target_identity is None or self.target is None:
            return
        if not self.target_identity.get("window"):
            self.target_identity["window"] = self._window_signature(self.target)
        if self.target_identity.get("context") is None:
            desc = self._context_descriptor(image, origin, self.target["box"])
            if desc is not None:
                self.target_identity["context"] = desc

    def _match_target(self, numbers, image, origin, wide=False):
        if not numbers or self.target is None or self.original_target is None:
            return None
        old_box = self.target["box"]
        ox = (old_box[0] + old_box[2]) / 2.0
        oy = (old_box[1] + old_box[3]) / 2.0
        oh = max(1.0, old_box[3] - old_box[1])
        ident = self.target_identity or {}
        initial_box = ident.get("initial_box", old_box)
        ix = (initial_box[0] + initial_box[2]) / 2.0
        iy = (initial_box[1] + initial_box[3]) / 2.0
        stored_context = ident.get("context")
        stored_window = ident.get("window", "")
        ranked = []
        for n in numbers:
            b = n["box"]
            cx = (b[0] + b[2]) / 2.0
            cy = (b[1] + b[3]) / 2.0
            nh = max(1.0, b[3] - b[1])
            dist = math.hypot(cx - ox, cy - oy) / oh
            overlap = recognizer._iou(b, old_box)
            size_penalty = abs(math.log(nh / oh))
            if wide:
                score = min(dist, 10.0) * 0.22 + size_penalty * 0.9 - overlap * 1.7
                score += math.hypot(cx - ix, cy - iy) / max(oh, 12.0) * 0.018
                if self.current_value is not None and _same_number(n["value"], self.current_value):
                    score -= 0.35
            else:
                score = dist * 0.72 + size_penalty * 1.15 - overlap * 2.6
            if stored_window:
                candidate_window = self._window_signature(n)
                if candidate_window != stored_window:
                    score += 1.8 if wide else 2.8
            if stored_context is None and not _same_number(n["value"], self.original_target["value"]):
                score += 1.35
            if stored_context is not None:
                desc = self._context_descriptor(image, origin, b)
                if desc is None:
                    score += 1.0
                else:
                    a = np.asarray(stored_context, dtype=np.float32)
                    d = np.asarray(desc, dtype=np.float32)
                    mse = float(np.mean((a - d) ** 2))
                    score += mse * (7.0 if wide else 8.5)
            ranked.append((score, n))
        ranked.sort(key=lambda pair: pair[0])
        if not ranked:
            return None
        threshold = 5.2 if wide else 3.5
        return ranked[0][1] if ranked[0][0] <= threshold else None

    def _screen_bounds(self):
        vx, vy = virtual_origin()
        return vx, vy, vx + max(1, user32.GetSystemMetrics(78)) - 1, vy + max(1, user32.GetSystemMetrics(79)) - 1

    def _random_point(self, target):
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        x0, y0, x1, y1 = target["box"]
        cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        h = max(8.0, y1 - y0)
        if random.random() < 0.78:
            spread = random.choice((0.4, 0.8, 1.6, 3.0, 6.0)) * h
            x = int(round(random.gauss(cx, spread)))
            y = int(round(random.gauss(cy, spread)))
        else:
            x = random.randint(vx0, vx1)
            y = random.randint(vy0, vy1)
        return max(vx0, min(vx1, x)), max(vy0, min(vy1, y))

    def _random_vk(self):
        return random.randint(1, 254)

    def _random_duration(self, mean):
        return random.expovariate(1.0 / max(1e-6, float(mean)))

    def _random_count(self, stop_probability=0.68):
        count = 1
        while random.random() > stop_probability:
            count += 1
        return count

    def _random_text(self):
        base = float(self.current_value if self.current_value is not None else self.original_target["value"])
        if random.random() < 0.86:
            magnitude = random.choice((0.01, 0.1, 1, 2, 5, 10, 25, 50, 100, 1000))
            return _format_number(base + magnitude)
        chars = []
        for _ in range(self._random_count(0.72)):
            while True:
                codepoint = random.randint(1, 0x10FFFF)
                if not (0xD800 <= codepoint <= 0xDFFF):
                    chars.append(chr(codepoint))
                    break
        return "".join(chars)

    def _random_key_spec(self):
        if random.random() < 0.58:
            return "vk", self._random_vk(), bool(random.getrandbits(1))
        return "scan", random.randint(1, 0xFFFF), bool(random.getrandbits(1))

    def _random_operation(self, target):
        kind = random.choices(
            ("mouse_abs", "mouse_rel", "mouse_button", "wheel", "key_event", "unicode_event", "unicode_text", "raw_mouse", "raw_keyboard", "wait"),
            weights=(10, 6, 12, 8, 18, 4, 8, 2, 2, 8), k=1
        )[0]
        if kind == "mouse_abs":
            x, y = self._random_point(target)
            return {"op": kind, "x": x, "y": y, "duration": self._random_duration(0.20)}
        if kind == "mouse_rel":
            scale = max(8.0, target["box"][3] - target["box"][1])
            return {"op": kind, "dx": int(round(random.gauss(0, scale * 5.0))), "dy": int(round(random.gauss(0, scale * 5.0))),
                    "duration": self._random_duration(0.16), "no_coalesce": bool(random.getrandbits(1))}
        if kind == "mouse_button":
            return {"op": kind, "button": random.choice(("left", "right", "middle", "x1", "x2")), "down": bool(random.getrandbits(1))}
        if kind == "wheel":
            delta = int(round(random.gauss(0, 960.0)))
            if delta == 0:
                delta = random.choice((-1, 1))
            return {"op": kind, "delta": delta, "horizontal": bool(random.getrandbits(1))}
        if kind == "key_event":
            mode, code, extended = self._random_key_spec()
            return {"op": kind, "mode": mode, "code": code, "down": bool(random.getrandbits(1)), "extended": extended}
        if kind == "unicode_event":
            return {"op": kind, "unit": random.randint(1, 0xFFFF), "down": bool(random.getrandbits(1))}
        if kind == "unicode_text":
            return {"op": kind, "text": self._random_text(), "interval": self._random_duration(0.025)}
        if kind == "raw_mouse":
            return {"op": kind, "dx": int(round(random.gauss(0, 800.0))), "dy": int(round(random.gauss(0, 800.0))), "data": 0,
                    "flags": MOUSEEVENTF_MOVE | (MOUSEEVENTF_MOVE_NOCOALESCE if random.random() < 0.5 else 0)}
        if kind == "raw_keyboard":
            mode, code, extended = self._random_key_spec()
            flags = (KEYEVENTF_EXTENDEDKEY if extended else 0) | (0 if random.getrandbits(1) else KEYEVENTF_KEYUP)
            if mode == "scan":
                flags |= KEYEVENTF_SCANCODE
                return {"op": kind, "vk": 0, "scan": code, "flags": flags}
            return {"op": kind, "vk": code, "scan": 0, "flags": flags}
        return {"op": "wait", "seconds": self._random_duration(0.22)}

    def _random_program(self, target):
        x0, y0, x1, y1 = target["box"]
        h = max(8, y1 - y0)
        focus_x = int(round((x0 + x1) / 2 + random.gauss(0, h * 0.12)))
        focus_y = int(round((y0 + y1) / 2 + random.gauss(0, h * 0.12)))
        if random.random() < 0.26:
            delta = random.choice((0.01, 0.1, 1, 2, 5, 10, 25, 100))
            new_value = _format_number(float(self.current_value) + delta)
            return [
                {"op": "mouse_abs", "x": focus_x, "y": focus_y, "duration": self._random_duration(0.10)},
                {"op": "mouse_button", "button": "left", "down": True},
                {"op": "wait", "seconds": self._random_duration(0.05)},
                {"op": "mouse_button", "button": "left", "down": False},
                {"op": "key_event", "mode": "vk", "code": 0x11, "down": True, "extended": False},
                {"op": "key_event", "mode": "vk", "code": 0x41, "down": True, "extended": False},
                {"op": "key_event", "mode": "vk", "code": 0x41, "down": False, "extended": False},
                {"op": "key_event", "mode": "vk", "code": 0x11, "down": False, "extended": False},
                {"op": "unicode_text", "text": new_value, "interval": self._random_duration(0.02)},
                {"op": "key_event", "mode": "vk", "code": 0x0D, "down": True, "extended": False},
                {"op": "key_event", "mode": "vk", "code": 0x0D, "down": False, "extended": False},
            ]
        length = 1
        while random.random() < 0.70:
            length += 1
        return [self._random_operation(target) for _ in range(length)]

    def _mutate_program(self, program, target):
        mutated = json.loads(json.dumps(program))
        if not mutated:
            return self._random_program(target)
        mode = random.choice(("replace", "insert", "insert", "delete", "tweak", "tweak", "reorder"))
        if mode == "replace":
            mutated[random.randrange(len(mutated))] = self._random_operation(target)
        elif mode == "insert":
            mutated.insert(random.randrange(len(mutated) + 1), self._random_operation(target))
        elif mode == "delete" and len(mutated) > 1:
            del mutated[random.randrange(len(mutated))]
        elif mode == "reorder" and len(mutated) > 1:
            i = random.randrange(len(mutated))
            j = random.randrange(len(mutated))
            mutated[i], mutated[j] = mutated[j], mutated[i]
        else:
            op = mutated[random.randrange(len(mutated))]
            kind = op.get("op")
            factor = math.exp(random.gauss(0.0, 0.55))
            if kind == "mouse_abs":
                vx0, vy0, vx1, vy1 = self._screen_bounds()
                op["x"] = max(vx0, min(vx1, int(op.get("x", 0) + random.gauss(0, 90))))
                op["y"] = max(vy0, min(vy1, int(op.get("y", 0) + random.gauss(0, 90))))
                op["duration"] = max(0.0, float(op.get("duration", 0.0)) * factor)
            elif kind == "mouse_rel":
                op["dx"] = int(op.get("dx", 0) + random.gauss(0, 140))
                op["dy"] = int(op.get("dy", 0) + random.gauss(0, 140))
                op["duration"] = max(0.0, float(op.get("duration", 0.0)) * factor)
                if random.random() < 0.2:
                    op["no_coalesce"] = not bool(op.get("no_coalesce", False))
            elif kind == "mouse_button":
                if random.random() < 0.55:
                    op["button"] = random.choice(("left", "right", "middle", "x1", "x2"))
                if random.random() < 0.45:
                    op["down"] = not bool(op.get("down", True))
            elif kind == "wheel":
                op["delta"] = int(op.get("delta", 0) + random.gauss(0, 1100)) or random.choice((-1, 1))
                if random.random() < 0.35:
                    op["horizontal"] = not bool(op.get("horizontal", False))
            elif kind == "key_event":
                if random.random() < 0.58:
                    mode2, code, extended = self._random_key_spec()
                    op["mode"], op["code"], op["extended"] = mode2, code, extended
                if random.random() < 0.42:
                    op["down"] = not bool(op.get("down", True))
                if random.random() < 0.28:
                    op["extended"] = not bool(op.get("extended", False))
            elif kind == "unicode_event":
                op["unit"] = random.randint(1, 0xFFFF)
                if random.random() < 0.5:
                    op["down"] = not bool(op.get("down", True))
            elif kind == "unicode_text":
                op["text"] = self._random_text()
                op["interval"] = max(0.0, float(op.get("interval", 0.0)) * factor)
            elif kind == "raw_mouse":
                op["dx"] = int(op.get("dx", 0) + random.gauss(0, 600))
                op["dy"] = int(op.get("dy", 0) + random.gauss(0, 600))
                if random.random() < 0.3:
                    op["flags"] = int(op.get("flags", 0)) ^ MOUSEEVENTF_MOVE_NOCOALESCE
            elif kind == "raw_keyboard":
                if random.random() < 0.5:
                    op["vk"] = random.randint(0, 0xFFFF)
                    op["scan"] = random.randint(0, 0xFFFF)
                if random.random() < 0.4:
                    op["flags"] = int(op.get("flags", 0)) ^ KEYEVENTF_KEYUP
                if random.random() < 0.3:
                    op["flags"] = int(op.get("flags", 0)) ^ KEYEVENTF_EXTENDEDKEY
            elif kind == "wait":
                op["seconds"] = max(0.0, float(op.get("seconds", 0.0)) * factor)
        return mutated

    def _ctx(self, key):
        contexts = self.state["contexts"]
        if key not in contexts:
            limits = self._storage_limits()
            if len(contexts) >= limits["contexts"]:
                victim = min(contexts.items(), key=lambda pair: self._context_quality(pair[1]))[0]
                del contexts[victim]
            contexts[key] = {
                "programs": [], "best_policy": None, "challenger": None,
                "champion_history": [], "trials": 0, "last_used": int(self.state.get("trials", 0))
            }
        ctx = contexts[key]
        ctx["last_used"] = int(self.state.get("trials", 0))
        return ctx

    def _record_metrics(self, rec):
        n = max(1, int(rec.get("n", 0)))
        return (
            int(rec.get("wins", 0)) / n,
            float(rec.get("total_gain", 0.0)) / n,
            float(rec.get("total_reward", 0.0)) / n,
        )

    def _find_record(self, ctx, fingerprint):
        for rec in ctx.get("programs", []):
            if rec.get("fingerprint") == fingerprint:
                return rec
        return None

    def _maybe_seed_best_policy(self, ctx, rec):
        if ctx.get("best_policy") is not None:
            return
        n = int(rec.get("n", 0))
        wins = int(rec.get("wins", 0))
        if n < 5 or wins < 2:
            return
        evidence = {
            "n": n, "wins": wins, "reward_sum": float(rec.get("total_reward", 0.0)),
            "gain_sum": float(rec.get("total_gain", 0.0))
        }
        ctx["best_policy"] = self._policy_from_evidence(rec["program"], rec["fingerprint"], evidence)

    def _maybe_nominate_challenger(self, ctx, rec):
        best = ctx.get("best_policy")
        if best is None or ctx.get("challenger") is not None:
            return
        if rec.get("fingerprint") == best.get("fingerprint"):
            return
        if int(rec.get("blocked_until", 0)) > int(ctx.get("trials", 0)):
            return
        n = int(rec.get("n", 0))
        wins = int(rec.get("wins", 0))
        if n < 5 or wins < 2:
            return
        rate, gain, reward = self._record_metrics(rec)
        if rate + 0.08 < float(best.get("success_floor", 0.0)):
            return
        if gain < float(best.get("gain_floor", 0.0)) * 0.80 and reward < float(best.get("reward_floor", -1e9)):
            return
        ctx["challenger"] = {
            "fingerprint": rec["fingerprint"], "program": json.loads(json.dumps(rec["program"])),
            "started_trial": int(ctx.get("trials", 0)),
            "candidate_eval": {"n": 0, "wins": 0, "reward_sum": 0.0, "gain_sum": 0.0},
            "incumbent_eval": {"n": 0, "wins": 0, "reward_sum": 0.0, "gain_sum": 0.0}
        }

    def _resolve_challenger(self, ctx):
        challenger = ctx.get("challenger")
        best = ctx.get("best_policy")
        if challenger is None or best is None:
            return
        cand = challenger["candidate_eval"]
        inc = challenger["incumbent_eval"]
        if int(cand.get("n", 0)) < 8 or int(inc.get("n", 0)) < 8:
            return
        cand_n = max(1, int(cand["n"]))
        inc_n = max(1, int(inc["n"]))
        cand_success = self._wilson_lower(cand["wins"], cand_n)
        inc_success = self._wilson_lower(inc["wins"], inc_n)
        cand_gain = float(cand["gain_sum"]) / cand_n
        inc_gain = float(inc["gain_sum"]) / inc_n
        cand_reward = float(cand["reward_sum"]) / cand_n
        inc_reward = float(inc["reward_sum"]) / inc_n
        historical_success = float(best.get("success_floor", 0.0))
        historical_gain = float(best.get("gain_floor", 0.0))
        historical_reward = float(best.get("reward_floor", -1e9))
        reaches_gate = (
            cand_success >= historical_success - 0.005
            and cand_gain >= historical_gain * 0.98
            and cand_reward >= historical_reward - 0.03
        )
        matches_incumbent = cand_success >= inc_success - 0.01 and cand_gain >= inc_gain * 0.98
        improves = cand_success > inc_success + 0.01 or cand_gain > inc_gain * 1.03 or cand_reward > inc_reward + 0.04
        if reaches_gate and matches_incumbent and improves:
            ctx["champion_history"].append(json.loads(json.dumps(best)))
            ctx["best_policy"] = self._policy_from_evidence(challenger["program"], challenger["fingerprint"], cand)
            ctx["challenger"] = None
            self._compact_context(ctx, self._storage_limits()["programs"], self._storage_limits()["history"])
            return
        clearly_worse = (
            cand_success + 0.04 < max(historical_success, inc_success)
            or cand_gain < max(historical_gain, inc_gain) * 0.78
            or cand_reward + 0.10 < max(historical_reward, inc_reward)
        )
        if clearly_worse or (cand_n >= 24 and inc_n >= 24):
            rec = self._find_record(ctx, challenger["fingerprint"])
            if rec is not None:
                rec["blocked_until"] = int(ctx.get("trials", 0)) + 96
            ctx["challenger"] = None

    def _pick_program(self, key, target):
        ctx = self._ctx(key)
        challenger = ctx.get("challenger")
        best = ctx.get("best_policy")
        if challenger is not None and best is not None:
            cand_n = int(challenger["candidate_eval"].get("n", 0))
            inc_n = int(challenger["incumbent_eval"].get("n", 0))
            if cand_n <= inc_n:
                return json.loads(json.dumps(challenger["program"])), "challenger"
            return json.loads(json.dumps(best["program"])), "incumbent_validation"
        programs = ctx["programs"]
        context_trials = int(ctx.get("trials", 0))
        confidence = 0.0
        if isinstance(best, dict):
            evidence = best.get("evidence", {})
            sample_confidence = 1.0 - math.exp(-max(0, int(evidence.get("n", 0))) / 10.0)
            performance_confidence = max(0.0, min(1.0, float(best.get("success_floor", 0.0)) + 0.25))
            confidence = sample_confidence * performance_confidence
        epsilon = 0.82 * math.exp(-context_trials / 60.0) * (1.0 - 0.70 * confidence)
        epsilon += 0.08 * (1.0 - confidence) * math.exp(-context_trials / 550.0)
        if best is not None and random.random() >= epsilon:
            return json.loads(json.dumps(best["program"])), "best"
        ranked = sorted(programs, key=lambda rec: (self._record_quality(rec), int(rec.get("n", 0))), reverse=True)
        base = None
        if best is not None and random.random() < 0.62:
            base = best["program"]
        elif ranked and random.random() < 0.74:
            pool_size = max(1, int(math.sqrt(len(ranked))))
            base = random.choice(ranked[:pool_size])["program"]
        elif self.state.get("success_memory") and random.random() < 0.62:
            window = self._window_signature(target)
            matches = [item for item in self.state["success_memory"] if item.get("window") == window]
            pool = matches if matches else self.state["success_memory"]
            if pool:
                weighted = sorted(pool, key=self._memory_quality, reverse=True)
                base = random.choice(weighted[:max(1, int(math.sqrt(len(weighted))))])["program"]
        program = self._mutate_program(base, target) if base is not None else self._random_program(target)
        return program, "explore"

    def _learn_program(self, key, program, reward, gain, role="explore"):
        self.state["trials"] = int(self.state.get("trials", 0)) + 1
        if reward > 0:
            self.state["successes"] = int(self.state.get("successes", 0)) + 1
        ctx = self._ctx(key)
        ctx["trials"] = int(ctx.get("trials", 0)) + 1
        ctx["last_used"] = int(self.state["trials"])
        normalized = self._normalize_program(program)
        if not normalized:
            if self.state["trials"] % 5 == 0:
                self._save_state()
            return
        fingerprint = self._policy_fingerprint(normalized, self.target)
        rec = self._find_record(ctx, fingerprint)
        if rec is None:
            rec = {
                "fingerprint": fingerprint, "program": json.loads(json.dumps(normalized)), "n": 0, "q": 0.0,
                "wins": 0, "best_gain": 0.0, "best_reward": -1e9, "total_reward": 0.0, "total_gain": 0.0,
                "last_seen": int(self.state["trials"]), "blocked_until": 0
            }
            ctx["programs"].append(rec)
        rec["n"] = int(rec.get("n", 0)) + 1
        rec["total_reward"] = float(rec.get("total_reward", 0.0)) + float(reward)
        rec["total_gain"] = float(rec.get("total_gain", 0.0)) + float(gain)
        rec["last_seen"] = int(self.state["trials"])
        alpha = 1.0 / math.sqrt(rec["n"])
        rec["q"] = float(rec.get("q", 0.0)) + alpha * (float(reward) - float(rec.get("q", 0.0)))
        if reward > 0:
            rec["wins"] = int(rec.get("wins", 0)) + 1
            rec["best_gain"] = max(float(rec.get("best_gain", 0.0)), float(gain))
        if float(reward) > float(rec.get("best_reward", -1e9)):
            rec["best_reward"] = float(reward)
            rec["program"] = json.loads(json.dumps(normalized))
        if reward > 0:
            window = self._window_signature(self.target)
            memory = self.state.setdefault("success_memory", [])
            remembered = None
            for item in memory:
                if item.get("window") == window and item.get("fingerprint") == fingerprint:
                    remembered = item
                    break
            if remembered is None:
                remembered = {
                    "window": window, "fingerprint": fingerprint, "program": json.loads(json.dumps(normalized)),
                    "n": 0, "reward_sum": 0.0, "gain_sum": 0.0, "best_reward": -1e9, "best_gain": 0.0,
                    "last_seen": int(self.state["trials"])
                }
                memory.append(remembered)
            remembered["n"] = int(remembered.get("n", 0)) + 1
            remembered["reward_sum"] = float(remembered.get("reward_sum", 0.0)) + float(reward)
            remembered["gain_sum"] = float(remembered.get("gain_sum", 0.0)) + float(gain)
            remembered["last_seen"] = int(self.state["trials"])
            if float(reward) > float(remembered.get("best_reward", -1e9)):
                remembered["best_reward"] = float(reward)
                remembered["best_gain"] = max(float(remembered.get("best_gain", 0.0)), float(gain))
                remembered["program"] = json.loads(json.dumps(normalized))
        challenger = ctx.get("challenger")
        best = ctx.get("best_policy")
        if challenger is not None and best is not None:
            if role == "challenger":
                self._eval_update(challenger["candidate_eval"], reward, gain)
            elif role == "incumbent_validation":
                self._eval_update(challenger["incumbent_eval"], reward, gain)
            self._resolve_challenger(ctx)
        self._maybe_seed_best_policy(ctx, rec)
        if role == "explore" and ctx.get("challenger") is None:
            self._maybe_nominate_challenger(ctx, rec)
        limits = self._storage_limits()
        if len(ctx["programs"]) > limits["programs"]:
            self._compact_context(ctx, limits["programs"], limits["history"])
        if len(self.state.get("success_memory", [])) > limits["memory"]:
            self._compact_state()
        if self.state["trials"] % 5 == 0:
            self._save_state()

    def _signed_long(self, value):
        value = int(value)
        if value < -2147483648:
            return -2147483648
        if value > 2147483647:
            return 2147483647
        return value

    def _raw_mouse_packet(self, dx, dy, data, flags):
        packet = INPUT()
        packet.type = INPUT_MOUSE
        packet.mi = MOUSEINPUT(self._signed_long(dx), self._signed_long(dy), int(data) & 0xFFFFFFFF, int(flags) & 0xFFFFFFFF, 0, INPUT_TAG)
        user32.SendInput(1, ctypes.byref(packet), ctypes.sizeof(INPUT))
        self._track_raw_mouse(int(data), int(flags))

    def _track_raw_mouse(self, data, flags):
        mapping = (
            ("left", MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
            ("right", MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
            ("middle", MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP),
        )
        for name, down_flag, up_flag in mapping:
            if flags & down_flag:
                self.held_mouse.add(name)
            if flags & up_flag:
                self.held_mouse.discard(name)
        if flags & MOUSEEVENTF_XDOWN:
            if data & 1:
                self.held_mouse.add("x1")
            if data & 2:
                self.held_mouse.add("x2")
        if flags & MOUSEEVENTF_XUP:
            if data & 1:
                self.held_mouse.discard("x1")
            if data & 2:
                self.held_mouse.discard("x2")

    def _raw_mouse_move_abs(self, x, y):
        vx, vy = virtual_origin()
        vw = max(2, user32.GetSystemMetrics(78))
        vh = max(2, user32.GetSystemMetrics(79))
        nx = max(0, min(65535, int(round((int(x) - vx) * 65535.0 / (vw - 1)))))
        ny = max(0, min(65535, int(round((int(y) - vy) * 65535.0 / (vh - 1)))))
        self._raw_mouse_packet(nx, ny, 0, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK)

    def _raw_mouse_move_rel(self, dx, dy, no_coalesce=False):
        flags = MOUSEEVENTF_MOVE | (MOUSEEVENTF_MOVE_NOCOALESCE if no_coalesce else 0)
        self._raw_mouse_packet(dx, dy, 0, flags)

    def _button_packet(self, button, down):
        mapping = {
            "left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, 0),
            "right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, 0),
            "middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP, 0),
            "x1": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, 1),
            "x2": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, 2),
        }
        down_flag, up_flag, data = mapping.get(button, mapping["left"])
        self._raw_mouse_packet(0, 0, data, down_flag if down else up_flag)

    def _mouse_button(self, button, down, force=False):
        if self.stop_event.is_set() and down and not force:
            return False
        self._button_packet(button, down)
        return True

    def _raw_keyboard_packet(self, vk, scan, flags):
        packet = INPUT()
        packet.type = INPUT_KEYBOARD
        packet.ki = KEYBDINPUT(int(vk) & 0xFFFF, int(scan) & 0xFFFF, int(flags) & 0xFFFFFFFF, 0, INPUT_TAG)
        user32.SendInput(1, ctypes.byref(packet), ctypes.sizeof(INPUT))
        self._track_raw_keyboard(int(vk), int(scan), int(flags))

    def _track_raw_keyboard(self, vk, scan, flags):
        extended = bool(flags & KEYEVENTF_EXTENDEDKEY)
        if flags & KEYEVENTF_UNICODE:
            identity = ("unicode", int(scan) & 0xFFFF, extended)
        elif flags & KEYEVENTF_SCANCODE:
            identity = ("scan", int(scan) & 0xFFFF, extended)
        else:
            identity = ("vk", int(vk) & 0xFFFF, extended)
        if flags & KEYEVENTF_KEYUP:
            self.held_keys.discard(identity)
        else:
            self.held_keys.add(identity)

    def _key_event(self, mode, code, down, extended=False, force=False):
        if self.stop_event.is_set() and down and not force:
            return False
        flags = (KEYEVENTF_EXTENDEDKEY if extended else 0) | (0 if down else KEYEVENTF_KEYUP)
        if mode == "scan":
            flags |= KEYEVENTF_SCANCODE
            self._raw_keyboard_packet(0, code, flags)
        else:
            self._raw_keyboard_packet(code, 0, flags)
        return True

    def _unicode_unit(self, unit, down, force=False):
        if self.stop_event.is_set() and down and not force:
            return False
        flags = KEYEVENTF_UNICODE | (0 if down else KEYEVENTF_KEYUP)
        self._raw_keyboard_packet(0, unit, flags)
        return True

    def _mouse_move_abs(self, x, y, duration=0.0):
        if self.stop_event.is_set():
            return
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        x = max(vx0, min(vx1, int(x)))
        y = max(vy0, min(vy1, int(y)))
        sx, sy = self._cursor_pos()
        dx, dy = x - sx, y - sy
        duration = max(0.0, float(duration))
        if duration == 0.0:
            self._raw_mouse_move_abs(x, y)
            return
        dist = math.hypot(dx, dy)
        steps = max(1, int(math.ceil(duration * 90.0)), int(math.ceil(dist / 18.0)))
        pause = duration / steps
        nx, ny = (-dy / max(dist, 1.0), dx / max(dist, 1.0))
        curve = random.gauss(0.0, 0.045) * min(dist, 220.0)
        for i in range(1, steps + 1):
            if self.stop_event.is_set():
                return
            t = i / steps
            ease = 3 * t * t - 2 * t * t * t
            bend = math.sin(math.pi * t) * curve
            self._raw_mouse_move_abs(int(round(sx + dx * ease + nx * bend)), int(round(sy + dy * ease + ny * bend)))
            if pause > 0 and self.stop_event.wait(pause):
                return

    def _mouse_move_rel(self, dx, dy, duration=0.0, no_coalesce=False):
        if self.stop_event.is_set():
            return
        dx, dy = self._signed_long(dx), self._signed_long(dy)
        duration = max(0.0, float(duration))
        if duration == 0.0:
            self._raw_mouse_move_rel(dx, dy, no_coalesce)
            return
        steps = max(1, int(math.ceil(duration * 90.0)), int(math.ceil(max(abs(dx), abs(dy)) / 18.0)))
        pause = duration / steps
        sent_x = sent_y = 0
        for i in range(1, steps + 1):
            if self.stop_event.is_set():
                return
            target_x = int(round(dx * i / steps))
            target_y = int(round(dy * i / steps))
            self._raw_mouse_move_rel(target_x - sent_x, target_y - sent_y, no_coalesce)
            sent_x, sent_y = target_x, target_y
            if pause > 0 and self.stop_event.wait(pause):
                return

    def _wheel(self, delta, horizontal=False):
        if self.stop_event.is_set():
            return
        self._raw_mouse_packet(0, 0, int(delta), MOUSEEVENTF_HWHEEL if horizontal else MOUSEEVENTF_WHEEL)

    def _type_text(self, text, interval=0.0):
        units = str(text).encode("utf-16-le")
        interval = max(0.0, float(interval))
        for i in range(0, len(units), 2):
            if self.stop_event.is_set():
                return
            unit = units[i] | (units[i + 1] << 8)
            self._unicode_unit(unit, True)
            self._unicode_unit(unit, False, force=True)
            if interval > 0 and self.stop_event.wait(interval):
                return

    def _release_all_inputs(self):
        for button in list(self.held_mouse):
            try:
                self._mouse_button(button, False, force=True)
            except Exception:
                pass
        for mode, code, extended in list(self.held_keys):
            try:
                if mode == "unicode":
                    self._unicode_unit(code, False, force=True)
                else:
                    self._key_event(mode, code, False, extended=extended, force=True)
            except Exception:
                pass
        self.held_mouse.clear()
        self.held_keys.clear()

    def _perform_program(self, program, target):
        for op in program:
            if self.stop_event.is_set():
                return
            kind = op.get("op")
            if kind == "mouse_abs":
                self._mouse_move_abs(op.get("x", 0), op.get("y", 0), op.get("duration", 0.0))
            elif kind == "mouse_rel":
                self._mouse_move_rel(op.get("dx", 0), op.get("dy", 0), op.get("duration", 0.0), bool(op.get("no_coalesce", False)))
            elif kind == "mouse_button":
                self._mouse_button(op.get("button", "left"), bool(op.get("down", True)))
            elif kind == "wheel":
                self._wheel(op.get("delta", 120), bool(op.get("horizontal", False)))
            elif kind == "key_event":
                self._key_event(str(op.get("mode", "vk")), op.get("code", 0), bool(op.get("down", True)), bool(op.get("extended", False)))
            elif kind == "unicode_event":
                self._unicode_unit(op.get("unit", 0), bool(op.get("down", True)))
            elif kind == "unicode_text":
                self._type_text(op.get("text", ""), op.get("interval", 0.0))
            elif kind == "raw_mouse":
                self._raw_mouse_packet(op.get("dx", 0), op.get("dy", 0), op.get("data", 0), op.get("flags", 0))
            elif kind == "raw_keyboard":
                self._raw_keyboard_packet(op.get("vk", 0), op.get("scan", 0), op.get("flags", 0))
            elif kind == "wait":
                self.stop_event.wait(max(0.0, float(op.get("seconds", 0.0))))

    def _reacquire_target(self, bounded_rounds=None):
        rounds = 0
        while app_alive.is_set() and not self.stop_event.is_set() and self.target is not None:
            image, origin = capture_screen()
            numbers = detect_multiscale_image(image, origin, scales=(1.0, 0.84, 1.18))
            observed = self._match_target(numbers, image, origin, wide=True)
            if observed is not None:
                self.target = dict(observed)
                self.current_value = observed["value"]
                self._ensure_identity_context(image, origin)
                return observed
            rounds += 1
            if bounded_rounds is not None and rounds >= bounded_rounds:
                return None
            if self.stop_event.wait(min(0.45, 0.12 + rounds * 0.03)):
                return None
        return None

    def start(self):
        with self.lock:
            if self.running or self.target is None or self.original_target is None:
                return
            self.running = True
            self.interrupting = False
            self.stop_event.clear()
        root.withdraw()
        threading.Thread(target=self._agent_loop, daemon=True).start()

    def stop_for_user(self):
        with self.lock:
            if not self.running or self.interrupting:
                return
            self.interrupting = True
            self.stop_event.set()

    def _reward_for(self, before_value, observed_value):
        baseline = float(self.original_target["value"])
        before_value = float(before_value)
        observed_value = float(observed_value)
        if observed_value > baseline:
            gain = observed_value - baseline
            self.state["best_gain"] = max(float(self.state.get("best_gain", 0.0)), gain)
            if before_value <= baseline:
                reward = 1.0 + min(1.8, math.log1p(max(0.0, gain)) * 0.45)
            elif observed_value > before_value:
                reward = 0.45 + min(1.2, math.log1p(max(0.0, observed_value - before_value)) * 0.35)
            elif _same_number(observed_value, before_value):
                reward = -0.04
            else:
                reward = -0.55
            return reward, gain
        if observed_value > before_value:
            return -0.08, 0.0
        if _same_number(observed_value, before_value):
            return -0.18, 0.0
        deficit = baseline - observed_value
        return -min(1.25, 0.72 + math.log1p(max(0.0, deficit)) * 0.12), 0.0

    def _agent_loop(self):
        user_interrupted = False
        try:
            self.stop_event.wait(0.22)
            while app_alive.is_set() and not self.stop_event.is_set() and self.target is not None:
                image, origin = capture_screen()
                numbers = detect_multiscale_image(image, origin, scales=(1.0,))
                refreshed = self._match_target(numbers, image, origin, wide=False)
                if refreshed is None:
                    refreshed = self._reacquire_target()
                    if refreshed is None:
                        break
                    image, origin = capture_screen()
                self.target = dict(refreshed)
                self._ensure_identity_context(image, origin)
                self.current_value = refreshed["value"]
                target = dict(self.target)
                before_value = self.current_value
                key = self._context_key(target)
                program, role = self._pick_program(key, target)
                self._perform_program(program, target)
                if self.stop_event.is_set() or self.stop_event.wait(random.uniform(0.28, 0.72)):
                    break
                image, origin = capture_screen()
                numbers = detect_multiscale_image(image, origin, scales=(1.0,))
                observed = self._match_target(numbers, image, origin, wide=False)
                if observed is None:
                    observed = self._reacquire_target(bounded_rounds=3)
                if observed is None:
                    self._learn_program(key, program, -0.34, 0, role)
                    observed = self._reacquire_target()
                    if observed is None:
                        break
                    self.target = dict(observed)
                    self.current_value = observed["value"]
                    continue
                self.target = dict(observed)
                observed_value = observed["value"]
                reward, gain = self._reward_for(before_value, observed_value)
                self.current_value = observed_value
                self._learn_program(key, program, reward, gain, role)
        finally:
            self._release_all_inputs()
            with self.lock:
                user_interrupted = self.interrupting
                self.running = False
                self.interrupting = False
            if self.state.get("trials", 0) % 5:
                try:
                    self._save_state()
                except Exception:
                    pass
            if user_interrupted and app_alive.is_set():
                root.after(0, show_main_user_control)

    def _register_user_input(self):
        self.last_user_activity = time.monotonic()
        if self.running:
            self.stop_for_user()

    def _resume_if_still_idle(self):
        if self.target is not None and not self.running and not self.overlay_mode:
            if time.monotonic() - self.last_user_activity >= 60.0:
                self.last_user_activity = time.monotonic()
                self.start()

    def _idle_watchdog(self):
        while app_alive.is_set():
            if self.target is not None and not self.running and not self.overlay_mode:
                if time.monotonic() - self.last_user_activity >= 60.0:
                    root.after(0, self._resume_if_still_idle)
                    time.sleep(0.25)
                    continue
            time.sleep(0.10)

    def monitor_input(self):
        threading.Thread(target=self._idle_watchdog, daemon=True).start()
        self.hook_thread_id = kernel32.GetCurrentThreadId()

        @HOOKPROC
        def mouse_proc(n_code, w_param, l_param):
            if n_code >= 0:
                info = ctypes.cast(l_param, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                if int(info.dwExtraInfo) != INPUT_TAG:
                    self._register_user_input()
            return user32.CallNextHookEx(self.mouse_hook, n_code, w_param, l_param)

        @HOOKPROC
        def keyboard_proc(n_code, w_param, l_param):
            if n_code >= 0:
                info = ctypes.cast(l_param, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                if int(info.dwExtraInfo) != INPUT_TAG:
                    self._register_user_input()
            return user32.CallNextHookEx(self.keyboard_hook, n_code, w_param, l_param)

        self.mouse_proc = mouse_proc
        self.keyboard_proc = keyboard_proc
        module = kernel32.GetModuleHandleW(None)
        self.mouse_hook = user32.SetWindowsHookExW(WH_MOUSE_LL, self.mouse_proc, module, 0)
        self.keyboard_hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL, self.keyboard_proc, module, 0)
        if not self.mouse_hook or not self.keyboard_hook:
            if self.mouse_hook:
                user32.UnhookWindowsHookEx(self.mouse_hook)
            if self.keyboard_hook:
                user32.UnhookWindowsHookEx(self.keyboard_hook)
            self.mouse_hook = None
            self.keyboard_hook = None
            root.after(0, lambda: dependency_failed("无法监听用户输入。"))
            return
        msg = wintypes.MSG()
        try:
            while app_alive.is_set():
                result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if result <= 0:
                    break
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
        finally:
            if self.mouse_hook:
                user32.UnhookWindowsHookEx(self.mouse_hook)
            if self.keyboard_hook:
                user32.UnhookWindowsHookEx(self.keyboard_hook)
            self.mouse_hook = None
            self.keyboard_hook = None


recognizer = None
controller = None
app_alive = threading.Event()
app_alive.set()


def virtual_origin():
    return (user32.GetSystemMetrics(76), user32.GetSystemMetrics(77))


def capture_screen():
    origin = virtual_origin()
    return ImageGrab.grab(all_screens=True), origin


def _merge_number_observations(observations):
    clusters = []
    for item in observations:
        best_cluster = None
        best_iou = 0.0
        for cluster in clusters:
            overlap = recognizer._iou(item["box"], cluster["box"])
            if overlap > best_iou:
                best_iou = overlap
                best_cluster = cluster
        if best_cluster is None or best_iou < 0.46:
            clusters.append({"box": item["box"], "items": [item]})
        else:
            best_cluster["items"].append(item)
            representative = max(best_cluster["items"], key=lambda g: float(g.get("conf", 0.0)))
            best_cluster["box"] = representative["box"]
    merged = []
    for cluster in clusters:
        votes = {}
        values = {}
        for item in cluster["items"]:
            key = _number_key(item["value"])
            values[key] = item["value"]
            votes[key] = votes.get(key, 0.0) + max(0.05, float(item.get("conf", 0.0)))
        key = max(votes.items(), key=lambda kv: kv[1])[0]
        value = values[key]
        matching = [item for item in cluster["items"] if _number_key(item["value"]) == key]
        best = max(matching, key=lambda g: float(g.get("conf", 0.0)))
        result = dict(best)
        result["value"] = value
        result["conf"] = min(1.0, float(best.get("conf", 0.0)) + min(0.18, 0.035 * (len(matching) - 1)))
        merged.append(result)
    merged.sort(key=lambda g: (float(g.get("conf", 0.0)), len(str(g.get("text", g.get("value", ""))))), reverse=True)
    return merged[:48]


def detect_multiscale_image(image, origin, scales=(1.0, 0.86, 1.16)):
    observations = []
    for scale in scales:
        if abs(float(scale) - 1.0) < 0.001:
            scaled = image
        else:
            scaled = image.resize(
                (max(1, int(round(image.width * scale))), max(1, int(round(image.height * scale)))),
                Image.Resampling.BILINEAR
            )
        found = recognizer.detect(scaled, (0, 0))
        inv = 1.0 / float(scale)
        for item in found:
            x0, y0, x1, y1 = item["box"]
            mapped = dict(item)
            mapped["box"] = (
                int(round(x0 * inv + origin[0])), int(round(y0 * inv + origin[1])),
                int(round(x1 * inv + origin[0])), int(round(y1 * inv + origin[1]))
            )
            observations.append(mapped)
    return _merge_number_observations(observations)


def detect_multiframe_screen(frame_count=3, scales=(1.0, 0.84, 1.18), stop_event=None):
    observations = []
    for frame in range(max(1, int(frame_count))):
        if stop_event is not None and stop_event.is_set():
            break
        image, origin = capture_screen()
        observations.extend(detect_multiscale_image(image, origin, scales=scales))
        if frame + 1 < frame_count:
            if stop_event is not None:
                if stop_event.wait(0.075):
                    break
            else:
                time.sleep(0.075)
    return _merge_number_observations(observations)


def build_runtime():
    global recognizer, controller
    try:
        status_var.set("正在生成本机自建数字视觉模型…")
        root.update_idletasks()
        recognizer = LocalDigitRecognizer()
        controller = LearningController()
        threading.Thread(target=controller.monitor_input, daemon=True).start()
        number_button.config(state="normal", command=scan_numbers)
        status_var.set("点击“数”，然后点选屏幕上的一个数字")
    except Exception as exc:
        dependency_failed(f"初始化失败：{exc}")


def scan_numbers():
    if controller is None or controller.running or controller.overlay_mode:
        return
    controller.overlay_mode = True
    root.withdraw()
    root.after(260, lambda: threading.Thread(target=_scan_worker, daemon=True).start())


def _scan_worker():
    while app_alive.is_set() and controller is not None and controller.overlay_mode:
        try:
            numbers = detect_multiframe_screen(frame_count=3, scales=(1.0, 0.82, 1.22))
            if numbers:
                root.after(0, lambda found=numbers: show_number_overlays(found))
                return
        except Exception:
            pass
        time.sleep(0.18)


def show_number_overlays(numbers):
    if not numbers:
        root.after(120, lambda: threading.Thread(target=_scan_worker, daemon=True).start())
        return
    controller.overlays = []
    controller.overlay_targets = list(numbers)
    for idx, item in enumerate(numbers):
        x0, y0, x1, y1 = item["box"]
        pad = max(2, int((y1 - y0) * 0.10))
        x0, y0, x1, y1 = x0 - pad, y0 - pad, x1 + pad, y1 + pad
        w, h = max(6, x1 - x0), max(6, y1 - y0)
        win = tk.Toplevel(root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.attributes("-alpha", 0.36)
        r, g, b = colorsys.hsv_to_rgb((idx * 0.61803398875) % 1.0, 0.70, 1.0)
        win.configure(bg=f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}")
        win.geometry(f"{w}x{h}{x0:+d}{y0:+d}")
        win.bind("<Button-1>", lambda event, i=idx: choose_number(i))
        controller.overlays.append(win)


def choose_number(index):
    if index >= len(controller.overlays) or index >= len(controller.overlay_targets):
        return
    selected_win = controller.overlays[index]
    all_windows = list(controller.overlays)
    controller.select_target(controller.overlay_targets[index])
    for i, win in enumerate(all_windows):
        if i != index:
            win.destroy()
    controller.overlays = [selected_win]
    controller.overlay_targets = [controller.target]
    fade_selected(selected_win, 0)


def fade_selected(win, frame):
    if not win.winfo_exists():
        return
    total = 30
    if frame >= total:
        win.destroy()
        controller.overlays = []
        controller.overlay_targets = []
        controller.overlay_mode = False
        controller.last_user_activity = time.monotonic()
        controller.start()
        return
    alpha = 0.36 * (1.0 - frame / total)
    win.attributes("-alpha", max(0.01, alpha))
    root.after(100, lambda: fade_selected(win, frame + 1))


def show_main_user_control():
    status_var.set("已检测到你的鼠标或键盘输入，AI已停止。60秒无输入后会继续。")
    root.deiconify()
    root.lift()


def shutdown():
    app_alive.clear()
    if controller is not None:
        controller.stop_event.set()
        if controller.hook_thread_id:
            user32.PostThreadMessageW(controller.hook_thread_id, WM_QUIT, 0, 0)
        try:
            controller._save_state()
        except Exception:
            pass
    root.destroy()


threading.Thread(target=bootstrap_dependencies, daemon=True).start()
root.mainloop()
