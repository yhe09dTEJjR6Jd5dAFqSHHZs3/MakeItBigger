import os
import sys
import math
import time
import json
import random
import threading
import subprocess
from pathlib import Path

sys.dont_write_bytecode = True

if os.name != "nt":
    raise SystemExit("MakeItBigger.py requires Windows 11 x64.")

import ctypes
from ctypes import wintypes
import tkinter as tk
from tkinter import filedialog, messagebox

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
try:
    user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
except Exception:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass

SW_HIDE = 0
console = kernel32.GetConsoleWindow()
if console:
    user32.ShowWindow(console, SW_HIDE)

SYSTEM_DRIVE = os.environ.get("SystemDrive", "C:").upper().rstrip("\\/")

root = tk.Tk()
root.withdraw()
root.update_idletasks()

while True:
    chosen = filedialog.askdirectory(title="选择非系统盘文件夹")
    if not chosen:
        root.destroy()
        raise SystemExit
    chosen_path = Path(chosen).resolve()
    drive = chosen_path.drive.upper().rstrip("\\/")
    if drive and drive != SYSTEM_DRIVE:
        break
    messagebox.showerror("请选择非系统盘", f"系统盘是 {SYSTEM_DRIVE}。请选择其他磁盘上的文件夹。")

app_dir = chosen_path / ".makeitbigger"
deps_dir = app_dir / "deps"
temp_dir = app_dir / "temp"
app_dir.mkdir(parents=True, exist_ok=True)
deps_dir.mkdir(parents=True, exist_ok=True)
temp_dir.mkdir(parents=True, exist_ok=True)
for key in ("TMP", "TEMP", "TMPDIR", "PIP_CACHE_DIR"):
    os.environ[key] = str(temp_dir)
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
if str(deps_dir) not in sys.path:
    sys.path.insert(0, str(deps_dir))

root.title("Make It Bigger")
root.geometry("320x170")
root.resizable(False, False)
root.protocol("WM_DELETE_WINDOW", lambda: shutdown())

status_var = tk.StringVar(value="正在准备本地识别器…")
status = tk.Label(root, textvariable=status_var, anchor="center", justify="center", wraplength=280)
status.pack(pady=(24, 14))
number_button = tk.Button(root, text="数", font=("Segoe UI", 22), width=6, state="disabled")
number_button.pack()
root.deiconify()
root.lift()

np = None
cv2 = None
Image = None
ImageGrab = None
ImageDraw = None
ImageFont = None
ImageFilter = None

def ui_status(text):
    if root.winfo_exists():
        root.after(0, lambda: status_var.set(text))


def bootstrap_dependencies():
    global np, cv2, Image, ImageGrab, ImageDraw, ImageFont, ImageFilter
    try:
        import numpy as _np
        import cv2 as _cv2
        from PIL import Image as _Image, ImageGrab as _ImageGrab, ImageDraw as _ImageDraw, ImageFont as _ImageFont, ImageFilter as _ImageFilter
    except Exception:
        ui_status("首次运行：正在把运行依赖安装到所选文件夹…")
        cmd = [
            sys.executable, "-m", "pip", "install", "--no-cache-dir", "--upgrade",
            "--target", str(deps_dir), "numpy>=2.0", "Pillow>=10.4", "opencv-python-headless>=4.10"
        ]
        result = subprocess.run(cmd, cwd=str(app_dir), env=os.environ.copy(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if result.returncode != 0:
            root.after(0, lambda: dependency_failed("无法自动安装本地运行依赖。请检查网络和 Python 的 pip 是否可用。"))
            return
        import importlib
        importlib.invalidate_caches()
        import numpy as _np
        import cv2 as _cv2
        from PIL import Image as _Image, ImageGrab as _ImageGrab, ImageDraw as _ImageDraw, ImageFont as _ImageFont, ImageFilter as _ImageFilter
    np, cv2 = _np, _cv2
    Image, ImageGrab, ImageDraw, ImageFont, ImageFilter = _Image, _ImageGrab, _ImageDraw, _ImageFont, _ImageFilter
    root.after(0, build_runtime)


def dependency_failed(text):
    status_var.set(text)
    number_button.config(state="disabled")


class LocalDigitRecognizer:
    def __init__(self):
        self.templates = self._make_templates()

    def _font_paths(self):
        windir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
        names = [
            "segoeui.ttf", "seguisb.ttf", "arial.ttf", "arialbd.ttf",
            "calibri.ttf", "calibrib.ttf", "consola.ttf", "consolab.ttf",
            "tahoma.ttf", "verdana.ttf", "times.ttf"
        ]
        paths = [windir / name for name in names if (windir / name).exists()]
        if not paths:
            raise RuntimeError("找不到可用的 Windows 字体。")
        return paths

    def _normalize_mask(self, mask):
        ys, xs = np.where(mask > 0)
        if len(xs) == 0:
            return np.zeros((28, 20), dtype=np.float32)
        crop = mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        h, w = crop.shape
        scale = min(16.0 / max(w, 1), 24.0 / max(h, 1))
        nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
        resized = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_AREA)
        out = np.zeros((28, 20), dtype=np.uint8)
        x0 = (20 - nw) // 2
        y0 = (28 - nh) // 2
        out[y0:y0 + nh, x0:x0 + nw] = resized
        return out.astype(np.float32).reshape(-1) / 255.0

    def _make_templates(self):
        rng = random.Random(731921)
        fonts = self._font_paths()
        bank = {d: [] for d in range(10)}
        for d in range(10):
            for _ in range(34):
                font_path = str(rng.choice(fonts))
                font_size = rng.randint(24, 56)
                font = ImageFont.truetype(font_path, font_size)
                canvas = Image.new("L", (80, 80), 0)
                draw = ImageDraw.Draw(canvas)
                bbox = draw.textbbox((0, 0), str(d), font=font, stroke_width=rng.randint(0, 1))
                tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
                x = 40 - tw // 2 - bbox[0] + rng.randint(-3, 3)
                y = 40 - th // 2 - bbox[1] + rng.randint(-3, 3)
                draw.text((x, y), str(d), fill=255, font=font, stroke_width=rng.randint(0, 1), stroke_fill=255)
                angle = rng.uniform(-7.0, 7.0)
                canvas = canvas.rotate(angle, resample=Image.Resampling.BILINEAR, fillcolor=0)
                if rng.random() < 0.45:
                    canvas = canvas.filter(ImageFilter.GaussianBlur(rng.uniform(0.15, 0.65)))
                arr = np.asarray(canvas)
                _, arr = cv2.threshold(arr, 80, 255, cv2.THRESH_BINARY)
                bank[d].append(self._normalize_mask(arr))
        packed = []
        labels = []
        for d in range(10):
            packed.extend(bank[d])
            labels.extend([d] * len(bank[d]))
        return np.stack(packed), np.asarray(labels, dtype=np.int32)

    def _classify_mask(self, crop):
        feat = self._normalize_mask(crop)
        if feat.sum() < 4.0:
            return None
        diffs = self.templates[0] - feat
        dist = np.mean(diffs * diffs, axis=1)
        order = np.argsort(dist)[:8]
        votes = {}
        for idx in order:
            label = int(self.templates[1][idx])
            weight = 1.0 / (float(dist[idx]) + 1e-5)
            votes[label] = votes.get(label, 0.0) + weight
        ranked = sorted(votes.items(), key=lambda kv: kv[1], reverse=True)
        best_label, best_vote = ranked[0]
        second_vote = ranked[1][1] if len(ranked) > 1 else 0.0
        best_dist = float(dist[order[0]])
        confidence = (best_vote - second_vote) / max(best_vote, 1e-6)
        if best_dist > 0.245 or confidence < 0.10:
            return None
        return best_label, max(0.0, min(1.0, 1.0 - best_dist / 0.245))

    def detect(self, pil_image, origin):
        rgb = np.asarray(pil_image.convert("RGB"))
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        h_img, w_img = gray.shape
        block = 31 if min(h_img, w_img) >= 31 else max(3, min(h_img, w_img) | 1)
        masks = [
            cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, block, 9),
            cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block, 9),
        ]
        chars = []
        for mask in masks:
            contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                if h < 9 or h > min(240, h_img * 0.35) or w < 2 or w > min(190, w_img * 0.25):
                    continue
                aspect = w / float(h)
                if aspect < 0.07 or aspect > 1.25:
                    continue
                area = cv2.contourArea(contour)
                if area < 8 or area / float(w * h) < 0.035:
                    continue
                pad = max(1, int(round(h * 0.08)))
                x0, y0 = max(0, x - pad), max(0, y - pad)
                x1, y1 = min(w_img, x + w + pad), min(h_img, y + h + pad)
                crop = mask[y0:y1, x0:x1]
                result = self._classify_mask(crop)
                if result is None:
                    continue
                digit, conf = result
                item = {"digit": digit, "conf": conf, "box": (x, y, x + w, y + h)}
                duplicate = False
                for old in chars:
                    if self._iou(item["box"], old["box"]) > 0.72:
                        duplicate = True
                        if conf > old["conf"]:
                            old.update(item)
                        break
                if not duplicate:
                    chars.append(item)
        chars.sort(key=lambda c: (c["box"][1], c["box"][0]))
        groups = []
        used = set()
        for i, ch in enumerate(chars):
            if i in used:
                continue
            line = [i]
            bx = ch["box"]
            cy = (bx[1] + bx[3]) / 2.0
            hh = bx[3] - bx[1]
            for j in range(i + 1, len(chars)):
                if j in used:
                    continue
                bj = chars[j]["box"]
                hj = bj[3] - bj[1]
                cyj = (bj[1] + bj[3]) / 2.0
                if abs(cyj - cy) <= 0.35 * max(hh, hj) and 0.45 <= hj / max(hh, 1) <= 2.2:
                    line.append(j)
            line.sort(key=lambda idx: chars[idx]["box"][0])
            seq = [line[0]]
            for idx in line[1:]:
                prev = chars[seq[-1]]["box"]
                cur = chars[idx]["box"]
                gap = cur[0] - prev[2]
                maxh = max(prev[3] - prev[1], cur[3] - cur[1])
                if -0.12 * maxh <= gap <= 0.72 * maxh:
                    seq.append(idx)
                elif len(seq) >= 1:
                    break
            for idx in seq:
                used.add(idx)
            selected = [chars[idx] for idx in seq]
            if not selected:
                continue
            value_text = "".join(str(c["digit"]) for c in selected)
            value = int(value_text)
            x0 = min(c["box"][0] for c in selected)
            y0 = min(c["box"][1] for c in selected)
            x1 = max(c["box"][2] for c in selected)
            y1 = max(c["box"][3] for c in selected)
            conf = sum(c["conf"] for c in selected) / len(selected)
            if len(selected) == 1 and conf < 0.82:
                continue
            abs_box = (x0 + origin[0], y0 + origin[1], x1 + origin[0], y1 + origin[1])
            groups.append({"value": value, "text": value_text, "conf": conf, "box": abs_box})
        groups = self._dedupe_groups(groups)
        groups.sort(key=lambda g: (g["conf"] + min(len(g["text"]), 4) * 0.04), reverse=True)
        return groups[:48]

    def _dedupe_groups(self, groups):
        out = []
        for g in sorted(groups, key=lambda x: (len(x["text"]), x["conf"]), reverse=True):
            replaced = False
            for k, old in enumerate(out):
                if self._iou(g["box"], old["box"]) > 0.62:
                    replaced = True
                    if len(g["text"]) > len(old["text"]) or g["conf"] > old["conf"] + 0.08:
                        out[k] = g
                    break
            if not replaced:
                out.append(g)
        return out

    def _iou(self, a, b):
        x0, y0 = max(a[0], b[0]), max(a[1], b[1])
        x1, y1 = min(a[2], b[2]), min(a[3], b[3])
        if x1 <= x0 or y1 <= y0:
            return 0.0
        inter = (x1 - x0) * (y1 - y0)
        aa = max(1, (a[2] - a[0]) * (a[3] - a[1]))
        bb = max(1, (b[2] - b[0]) * (b[3] - b[1]))
        return inter / float(aa + bb - inter)


class LearningController:
    def __init__(self):
        self.state_path = app_dir / "learning.json"
        self.state = self._load_state()
        self.actions = [
            "arrow_up", "wheel_up", "plus_key", "right_then_up",
            "upper_right_click", "right_edge_click", "replace_plus_one"
        ]
        self.ai_acting = False
        self.running = False
        self.stop_event = threading.Event()
        self.overlay_mode = False
        self.last_user_activity = time.time()
        self.target = None
        self.overlays = []
        self.overlay_targets = []
        self.ignore_input_until = 0.0
        self.last_cursor = self._cursor_pos()
        self.lock = threading.Lock()

    def _load_state(self):
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "contexts" in data and "trials" in data:
                return data
        except Exception:
            pass
        return {"trials": 0, "contexts": {}, "global": {}}

    def _save_state(self):
        tmp = app_dir / "learning.tmp"
        tmp.write_text(json.dumps(self.state, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, self.state_path)

    def _cursor_pos(self):
        pt = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        return (pt.x, pt.y)

    def _window_title(self):
        hwnd = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, len(buf))
        return buf.value[:80]

    def _context_key(self, target):
        sw = max(1, user32.GetSystemMetrics(78))
        sh = max(1, user32.GetSystemMetrics(79))
        x0, y0, x1, y1 = target["box"]
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        locx = int(8 * (cx - virtual_origin()[0]) / sw)
        locy = int(8 * (cy - virtual_origin()[1]) / sh)
        title = self._window_title()
        return f"{title}|{locx},{locy}|d{len(str(target['value']))}|h{int((y1-y0)/6)}"

    def _stats_for(self, key, action):
        ctx = self.state["contexts"].setdefault(key, {})
        local = ctx.setdefault(action, {"n": 0, "q": 0.0})
        glob = self.state["global"].setdefault(action, {"n": 0, "q": 0.0})
        return local, glob

    def _pick_action(self, key):
        trials = int(self.state.get("trials", 0))
        epsilon = max(0.06, 0.88 * math.exp(-trials / 90.0))
        if random.random() < epsilon:
            counts = []
            for action in self.actions:
                local, _ = self._stats_for(key, action)
                counts.append((local["n"], random.random(), action))
            counts.sort()
            return counts[0][2]
        scored = []
        for action in self.actions:
            local, glob = self._stats_for(key, action)
            n = local["n"]
            local_q = local["q"] if n else 0.0
            global_q = glob["q"] if glob["n"] else 0.0
            blend = (local_q * n + global_q * 2.0) / (n + 2.0)
            bonus = math.sqrt(math.log(trials + 2.0) / (n + 1.0)) * 0.25
            scored.append((blend + bonus, random.random(), action))
        scored.sort(reverse=True)
        return scored[0][2]

    def _learn(self, key, action, reward):
        self.state["trials"] = int(self.state.get("trials", 0)) + 1
        for stats in self._stats_for(key, action):
            stats["n"] += 1
            alpha = min(0.35, 1.0 / math.sqrt(stats["n"]))
            stats["q"] += alpha * (reward - stats["q"])
        if self.state["trials"] % 5 == 0:
            self._save_state()

    def _mouse_move(self, x, y):
        sx, sy = self._cursor_pos()
        dx, dy = x - sx, y - sy
        dist = math.hypot(dx, dy)
        steps = max(9, min(50, int(dist / 18) + 9))
        nx, ny = (-dy / max(dist, 1.0), dx / max(dist, 1.0))
        curve = random.uniform(-0.12, 0.12) * min(dist, 260.0)
        for i in range(1, steps + 1):
            if self.stop_event.is_set():
                return
            t = i / steps
            ease = 3 * t * t - 2 * t * t * t
            bend = math.sin(math.pi * t) * curve
            px = sx + dx * ease + nx * bend
            py = sy + dy * ease + ny * bend
            user32.SetCursorPos(int(px), int(py))
            time.sleep(random.uniform(0.004, 0.014))

    def _click(self, x, y, count=1):
        self._mouse_move(x, y)
        for _ in range(count):
            user32.mouse_event(0x0002, 0, 0, 0, 0)
            time.sleep(random.uniform(0.035, 0.075))
            user32.mouse_event(0x0004, 0, 0, 0, 0)
            time.sleep(random.uniform(0.055, 0.11))

    def _wheel(self, delta):
        user32.mouse_event(0x0800, 0, 0, ctypes.c_ulong(delta & 0xFFFFFFFF).value, 0)

    def _key(self, vk):
        user32.keybd_event(vk, 0, 0, 0)
        time.sleep(random.uniform(0.025, 0.065))
        user32.keybd_event(vk, 0, 0x0002, 0)

    def _type_text(self, text):
        for ch in text:
            code = user32.VkKeyScanW(ord(ch))
            if code == -1:
                continue
            vk = code & 0xFF
            shift = (code >> 8) & 1
            if shift:
                user32.keybd_event(0x10, 0, 0, 0)
            self._key(vk)
            if shift:
                user32.keybd_event(0x10, 0, 0x0002, 0)

    def _perform(self, action, target):
        x0, y0, x1, y1 = target["box"]
        cx, cy = int((x0 + x1) / 2), int((y0 + y1) / 2)
        h = max(8, y1 - y0)
        if action == "arrow_up":
            self._click(cx, cy)
            self._key(0x26)
        elif action == "wheel_up":
            self._mouse_move(cx, cy)
            self._wheel(120)
        elif action == "plus_key":
            self._click(cx, cy)
            self._key(0x6B)
        elif action == "right_then_up":
            self._click(cx, cy)
            self._key(0x27)
            self._key(0x26)
        elif action == "upper_right_click":
            self._click(int(x1 + min(18, h * 0.35)), int(y0 + h * 0.25))
        elif action == "right_edge_click":
            self._click(int(x1 + min(12, h * 0.28)), cy)
        elif action == "replace_plus_one":
            self._click(cx, cy, 2)
            user32.keybd_event(0x11, 0, 0, 0)
            self._key(0x41)
            user32.keybd_event(0x11, 0, 0x0002, 0)
            self._type_text(str(int(target["value"]) + 1))
            self._key(0x0D)

    def _nearest_number(self, numbers, old_box):
        if not numbers:
            return None
        ox = (old_box[0] + old_box[2]) / 2.0
        oy = (old_box[1] + old_box[3]) / 2.0
        oh = max(1.0, old_box[3] - old_box[1])
        ranked = []
        for n in numbers:
            b = n["box"]
            cx = (b[0] + b[2]) / 2.0
            cy = (b[1] + b[3]) / 2.0
            dist = math.hypot(cx - ox, cy - oy) / oh
            overlap = recognizer._iou(b, old_box)
            score = dist - overlap * 2.2
            ranked.append((score, n))
        ranked.sort(key=lambda x: x[0])
        return ranked[0][1] if ranked[0][0] < 4.0 else None

    def start(self):
        with self.lock:
            if self.running or self.target is None:
                return
            self.running = True
            self.stop_event.clear()
        root.withdraw()
        threading.Thread(target=self._agent_loop, daemon=True).start()

    def stop_for_user(self):
        with self.lock:
            was_running = self.running
            self.stop_event.set()
            self.running = False
        if was_running:
            root.after(0, show_main_user_control)

    def _agent_loop(self):
        try:
            self.stop_event.wait(0.22)
            while not self.stop_event.is_set() and self.target is not None:
                image, origin = capture_screen()
                numbers = recognizer.detect(image, origin)
                refreshed = self._nearest_number(numbers, self.target["box"])
                if refreshed is None:
                    root.after(0, show_main_target_lost)
                    break
                self.target = refreshed
                target = dict(self.target)
                key = self._context_key(target)
                action = self._pick_action(key)
                self.ai_acting = True
                try:
                    self._perform(action, target)
                finally:
                    self.last_cursor = self._cursor_pos()
                    self.ignore_input_until = time.time() + 0.18
                    self.ai_acting = False
                for _ in range(8):
                    if self.stop_event.wait(0.09):
                        break
                if self.stop_event.is_set():
                    break
                image, origin = capture_screen()
                numbers = recognizer.detect(image, origin)
                observed = self._nearest_number(numbers, target["box"])
                if observed is None:
                    reward = -0.24
                elif observed["value"] > target["value"]:
                    gain = observed["value"] - target["value"]
                    reward = 1.0 + min(1.5, math.log1p(gain) * 0.4)
                    self.target = observed
                elif observed["value"] == target["value"]:
                    reward = -0.07
                    self.target["box"] = observed["box"]
                else:
                    reward = -0.95
                    self.target = observed
                self._learn(key, action, reward)
        finally:
            with self.lock:
                self.running = False
            if self.state.get("trials", 0) % 5:
                try:
                    self._save_state()
                except Exception:
                    pass

    def monitor_input(self):
        while app_alive.is_set():
            pos = self._cursor_pos()
            key_activity = False
            for vk in range(1, 255):
                state = user32.GetAsyncKeyState(vk)
                if (state & 0x8000) or (state & 0x0001):
                    key_activity = True
            moved = math.hypot(pos[0] - self.last_cursor[0], pos[1] - self.last_cursor[1]) > 3.0
            if self.ai_acting or self.overlay_mode or time.time() < self.ignore_input_until:
                self.last_cursor = pos
            else:
                if moved or key_activity:
                    self.last_user_activity = time.time()
                    self.last_cursor = pos
                    if self.running:
                        self.stop_for_user()
                elif self.target is not None and not self.running and time.time() - self.last_user_activity >= 60.0:
                    self.last_user_activity = time.time()
                    root.after(0, self.start)
            time.sleep(0.05)


recognizer = None
controller = None
app_alive = threading.Event()
app_alive.set()


def virtual_origin():
    return (user32.GetSystemMetrics(76), user32.GetSystemMetrics(77))


def capture_screen():
    origin = virtual_origin()
    return ImageGrab.grab(all_screens=True), origin


def build_runtime():
    global recognizer, controller
    try:
        status_var.set("正在生成本机数字识别模型…")
        root.update_idletasks()
        recognizer = LocalDigitRecognizer()
        controller = LearningController()
        threading.Thread(target=controller.monitor_input, daemon=True).start()
        number_button.config(state="normal", command=scan_numbers)
        status_var.set("点击“数”，然后点选屏幕上的一个数字")
    except Exception as exc:
        dependency_failed(f"初始化失败：{exc}")


def scan_numbers():
    if controller is None or controller.running:
        return
    controller.overlay_mode = True
    root.withdraw()
    root.after(260, lambda: threading.Thread(target=_scan_worker, daemon=True).start())


def _scan_worker():
    try:
        image, origin = capture_screen()
        numbers = recognizer.detect(image, origin)
        root.after(0, lambda: show_number_overlays(numbers))
    except Exception as exc:
        root.after(0, lambda: scan_failed(str(exc)))


def scan_failed(text):
    controller.overlay_mode = False
    status_var.set(f"识别失败：{text}")
    root.deiconify()
    root.lift()


def show_number_overlays(numbers):
    if not numbers:
        controller.overlay_mode = False
        status_var.set("没找到足够可信的数字。可调整画面后再次点击“数”。")
        root.deiconify()
        root.lift()
        return
    palette = ["#ff4d4d", "#4da6ff", "#4dff88", "#ffd24d", "#c44dff", "#4dfff6", "#ff8c4d", "#ff4dc4"]
    controller.overlays = []
    controller.overlay_targets = list(numbers)
    for idx, item in enumerate(numbers):
        x0, y0, x1, y1 = item["box"]
        pad = max(2, int((y1 - y0) * 0.10))
        x0, y0, x1, y1 = x0 - pad, y0 - pad, x1 + pad, y1 + pad
        w, h = max(6, x1 - x0), max(6, y1 - y0)
        win = tk.Toplevel(root)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.attributes("-alpha", 0.36)
        win.configure(bg=palette[idx % len(palette)])
        win.geometry(f"{w}x{h}{x0:+d}{y0:+d}")
        win.bind("<Button-1>", lambda event, i=idx: choose_number(i))
        controller.overlays.append(win)


def choose_number(index):
    if index >= len(controller.overlays) or index >= len(controller.overlay_targets):
        return
    selected_win = controller.overlays[index]
    all_windows = list(controller.overlays)
    controller.target = dict(controller.overlay_targets[index])
    for i, win in enumerate(all_windows):
        if i != index:
            win.destroy()
    controller.overlays = [selected_win]
    controller.overlay_targets = [controller.target]
    fade_selected(selected_win, 0)


def fade_selected(win, frame):
    if not win.winfo_exists():
        return
    total = 30
    if frame >= total:
        win.destroy()
        controller.overlays = []
        controller.overlay_targets = []
        controller.overlay_mode = False
        controller.last_user_activity = time.time()
        controller.last_cursor = controller._cursor_pos()
        controller.start()
        return
    alpha = 0.36 * (1.0 - frame / total)
    win.attributes("-alpha", max(0.01, alpha))
    root.after(100, lambda: fade_selected(win, frame + 1))


def show_main_user_control():
    status_var.set("已检测到你的鼠标或键盘输入，AI已停止。60秒无输入后会继续。")
    root.deiconify()
    root.lift()
    root.focus_force()


def show_main_target_lost():
    if controller is not None:
        controller.stop_event.set()
    status_var.set("目标数字已不在原位置。请再次点击“数”重新选择。")
    root.deiconify()
    root.lift()


def shutdown():
    app_alive.clear()
    if controller is not None:
        controller.stop_event.set()
        try:
            controller._save_state()
        except Exception:
            pass
    root.destroy()


threading.Thread(target=bootstrap_dependencies, daemon=True).start()
root.mainloop()
