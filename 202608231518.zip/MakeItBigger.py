import sys
sys.dont_write_bytecode = True
import ctypes
import hashlib
from collections import deque
from decimal import Decimal, InvalidOperation, MAX_EMAX, MIN_EMIN, getcontext
from importlib import metadata
import json
import math
import os
import queue
import random
import re
import shutil
import subprocess
import threading
import time
import unicodedata
try:
    import winreg
except ImportError:
    winreg = None
from ctypes import wintypes
from pathlib import Path
from statistics import median
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
APP_NAME = "屏幕数值 AI"
DATA_DIR_NAME = "屏幕数值AI数据"
REGISTRY_PATH = r"Software\屏幕数值AI"
REGISTRY_VALUE = "DataPath"
LEARNING_NAME = "学习.json"
RUNTIME_DIR_NAME = "runtime"
AI_INPUT_MAGIC = 0
UI_POLL_MS = 16
SAMPLE_CAPACITY = 32
TRANSITION_CAPACITY = 16
ACTION_CAPACITY = 128
STATE_CAPACITY = 256
TARGET_CAPACITY = 8
VK_ESCAPE = 0x1B
WM_QUIT = 0x0012
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WM_MOUSEMOVE = 0x0200
WM_LBUTTONDOWN = 0x0201
WM_LBUTTONUP = 0x0202
WM_RBUTTONDOWN = 0x0204
WM_RBUTTONUP = 0x0205
WM_MBUTTONDOWN = 0x0207
WM_MBUTTONUP = 0x0208
WM_MOUSEWHEEL = 0x020A
WM_XBUTTONDOWN = 0x020B
WM_XBUTTONUP = 0x020C
WM_MOUSEHWHEEL = 0x020E
WH_KEYBOARD_LL = 13
WH_MOUSE_LL = 14
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_VIRTUALDESK = 0x4000
MOUSEEVENTF_ABSOLUTE = 0x8000
MAPVK_VK_TO_VSC = 0
MAPVK_VK_TO_VSC_EX = 4
WHEEL_DELTA = 120
GA_ROOT = 2
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79
user32 = None
kernel32 = None
dwmapi = None
def decimal_value(value):
    if isinstance(value, Decimal):
        result = value
    else:
        result = Decimal(str(value))
    if not result.is_finite():
        raise InvalidOperation
    context = getcontext()
    digits = len(result.as_tuple().digits)
    if digits + 16 > context.prec:
        context.prec = digits + 16
    adjusted = result.adjusted() if result else 0
    if adjusted + 16 > context.Emax:
        context.Emax = min(MAX_EMAX, adjusted + 16)
    if adjusted - 16 < context.Emin:
        context.Emin = max(MIN_EMIN, adjusted - 16)
    return result
def decimal_log_magnitude(value):
    value = decimal_value(value).copy_abs()
    if not value:
        return -math.inf
    digits = value.as_tuple().digits
    prefix = digits[:min(16, len(digits))]
    lead = 0
    for digit in prefix:
        lead = lead * 10 + digit
    mantissa = lead / (10 ** (len(prefix) - 1))
    return value.adjusted() + math.log10(mantissa)
def decimal_log_distance(first, second):
    first = decimal_value(first)
    second = decimal_value(second)
    if first == second:
        return 0.0
    if not first or not second:
        return math.inf
    if (first < 0) != (second < 0):
        return 1.0 + abs(decimal_log_magnitude(first) - decimal_log_magnitude(second))
    return abs(decimal_log_magnitude(first) - decimal_log_magnitude(second))
def decimal_json(value):
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, dict):
        return {str(key): decimal_json(item) for key, item in value.items()}
    if isinstance(value, list):
        return [decimal_json(item) for item in value]
    if isinstance(value, tuple):
        return [decimal_json(item) for item in value]
    return value
def visual_hash_side(size):
    width, height = size
    scale = math.sqrt(max(1, width * height)) / max(1, math.sqrt(1920 * 1080))
    return max(8, min(16, int(round(8 * math.sqrt(max(1.0, scale))))))
def confidence_threshold(values):
    values = [float(value) for value in values if math.isfinite(float(value)) and float(value) > 0]
    if len(values) < 2:
        return None
    center = median(values)
    spread = median(abs(value - center) for value in values)
    return max(0.0, min(1.0, center - spread))
def confirmation_threshold(values):
    values = [float(value) for value in values if math.isfinite(float(value)) and float(value) > 0]
    if len(values) < 2:
        return None
    center = median(values)
    spread = median(abs(value - center) for value in values)
    return max(0.0, min(1.0, center - spread / max(1.0, math.sqrt(len(values)))))
def anomaly_magnitude_limit(values):
    parsed = []
    for value in values:
        try:
            parsed.append(abs(decimal_value(value)))
        except Exception:
            pass
    if not parsed:
        return Decimal(0)
    center = median(parsed)
    spread = median(abs(value - center) for value in parsed)
    divisor = Decimal(max(1, int(math.sqrt(len(parsed)))))
    return center + max(spread, center / divisor)
def exploration_budget(total_trials):
    return max(1, int(math.log2(max(2, int(total_trials) + 2))))
def expand_relative(rect):
    x1, y1, x2, y2 = map(float, rect)
    diagonal = math.hypot(x2 - x1, y2 - y1)
    return max(0.0, x1 - diagonal), max(0.0, y1 - diagonal), min(1.0, x2 + diagonal), min(1.0, y2 + diagonal)
def relative_center(rect):
    x1, y1, x2, y2 = rect
    return (x1 + x2) / 2, (y1 + y2) / 2
def relative_union(first, second):
    return min(first[0], second[0]), min(first[1], second[1]), max(first[2], second[2]), max(first[3], second[3])
def nvidia_gpu_present():
    executable = shutil.which("nvidia-smi")
    if not executable:
        return False
    try:
        result = subprocess.run([executable, "-L"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=max(1.0, time.get_clock_info("monotonic").resolution * 1000), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return result.returncode == 0
    except Exception:
        return False
ULONG_PTR = wintypes.WPARAM
def renew_input_magic():
    global AI_INPUT_MAGIC
    size = ctypes.sizeof(ULONG_PTR)
    AI_INPUT_MAGIC = int.from_bytes(os.urandom(size), "little") or 1
class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]
class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]
class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("pt", POINT), ("mouseData", wintypes.DWORD), ("flags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]
class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]
class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]
class INPUT(ctypes.Structure):
    _anonymous_ = ("union",)
    _fields_ = [("type", wintypes.DWORD), ("union", INPUTUNION)]
def configure_windows():
    global user32, kernel32, dwmapi
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    renew_input_magic()
    try:
        dwmapi = ctypes.windll.dwmapi
        dwmapi.DwmFlush.restype = ctypes.c_long
    except Exception:
        dwmapi = None
    try:
        user32.SetProcessDpiAwarenessContext.argtypes = [ctypes.c_void_p]
        user32.SetProcessDpiAwarenessContext.restype = wintypes.BOOL
        if not user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            raise OSError
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass
    user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = wintypes.SHORT
    user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
    user32.MapVirtualKeyW.restype = wintypes.UINT
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.restype = ctypes.c_int
    user32.EnumChildWindows.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.IsWindow.argtypes = [wintypes.HWND]
    user32.IsWindow.restype = wintypes.BOOL
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsWindowVisible.restype = wintypes.BOOL
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.IsIconic.restype = wintypes.BOOL
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetWindowRect.restype = wintypes.BOOL
    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.restype = wintypes.BOOL
    user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    user32.ClientToScreen.restype = wintypes.BOOL
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.SetWindowsHookExW.restype = wintypes.HHOOK
    user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    user32.CallNextHookEx.restype = wintypes.LPARAM
    user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
    user32.UnhookWindowsHookEx.restype = wintypes.BOOL
    user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.PostThreadMessageW.restype = wintypes.BOOL
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    kernel32.GetCurrentThreadId.restype = wintypes.DWORD
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
def measure_key_hold():
    if dwmapi is None:
        return 0.0
    try:
        dwmapi.DwmFlush()
        started = time.monotonic()
        dwmapi.DwmFlush()
        elapsed = time.monotonic() - started
        return max(time.get_clock_info("monotonic").resolution, elapsed) if elapsed > 0 else 0.0
    except Exception:
        return 0.0
def virtual_screen_rect():
    left = int(user32.GetSystemMetrics(SM_XVIRTUALSCREEN))
    top = int(user32.GetSystemMetrics(SM_YVIRTUALSCREEN))
    width = int(user32.GetSystemMetrics(SM_CXVIRTUALSCREEN))
    height = int(user32.GetSystemMetrics(SM_CYVIRTUALSCREEN))
    return left, top, left + width, top + height
def window_screen_rect(hwnd):
    if not hwnd or not user32.IsWindow(hwnd):
        return None
    rect = RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(rect)) or rect.right <= rect.left or rect.bottom <= rect.top:
        return None
    return int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)
def client_screen_rect(hwnd):
    if not hwnd or not user32.IsWindow(hwnd):
        return None
    rect = RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
        return None
    p1 = POINT(rect.left, rect.top)
    p2 = POINT(rect.right, rect.bottom)
    if not user32.ClientToScreen(hwnd, ctypes.byref(p1)) or not user32.ClientToScreen(hwnd, ctypes.byref(p2)):
        return None
    if p2.x <= p1.x or p2.y <= p1.y:
        return None
    return int(p1.x), int(p1.y), int(p2.x), int(p2.y)
def top_level_window_at(x, y):
    hwnd = user32.WindowFromPoint(POINT(int(x), int(y)))
    if not hwnd:
        return 0
    root = user32.GetAncestor(hwnd, GA_ROOT)
    return int(root or hwnd)
def foreground_root():
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return 0
    root = user32.GetAncestor(hwnd, GA_ROOT)
    return int(root or hwnd)
def window_class(hwnd):
    size = int(user32.GetWindowTextLengthW(hwnd) or 0) + 1
    buf = ctypes.create_unicode_buffer(max(size, 1))
    title = ""
    try:
        user32.GetWindowTextW(hwnd, buf, len(buf))
        title = buf.value
    except Exception:
        pass
    cls = ctypes.create_unicode_buffer(512)
    try:
        user32.GetClassNameW(hwnd, cls, len(cls))
    except Exception:
        pass
    return cls.value, title
def child_ui_elements(hwnd):
    client = client_screen_rect(hwnd)
    if client is None:
        return []
    left, top, right, bottom = client
    width = right - left
    height = bottom - top
    if width <= 0 or height <= 0:
        return []
    raw = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def visit(child, _data):
        try:
            if not user32.IsWindowVisible(child):
                return True
            rect = window_screen_rect(child)
            if rect is None:
                return True
            x1 = max(left, rect[0])
            y1 = max(top, rect[1])
            x2 = min(right, rect[2])
            y2 = min(bottom, rect[3])
            if x2 <= x1 or y2 <= y1:
                return True
            cls, title = window_class(child)
            raw.append((((x1 + x2) / 2 - left) / width, ((y1 + y2) / 2 - top) / height, (x2 - x1) / width, (y2 - y1) / height, identity_text(title), identity_text(cls)))
        except Exception:
            pass
        return True
    callback = callback_type(visit)
    try:
        user32.EnumChildWindows(hwnd, callback, 0)
    except Exception:
        return []
    counts = {}
    result = []
    for rx, ry, w, h, title, cls in raw:
        key = (cls, title)
        ordinal = counts.get(key, 0)
        counts[key] = ordinal + 1
        locator = {"mode": "win32", "class": cls, "text": title, "ordinal": ordinal}
        result.append((rx, ry, w, h, title or cls, locator))
    return result
def process_path(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not pid.value:
        return ""
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
    if not handle:
        return ""
    try:
        size = wintypes.DWORD(32768)
        buf = ctypes.create_unicode_buffer(size.value)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return buf.value
    except Exception:
        pass
    finally:
        kernel32.CloseHandle(handle)
    return ""
def identity_text(text):
    text = unicodedata.normalize("NFKC", str(text)).strip().lower()
    text = re.sub(r"[-+]?\d[\d\s,'’._]*(?:[eE][-+]?\d+)?", "#", text)
    return re.sub(r"\s+", " ", text)
def target_identity(hwnd, relative=None, context=""):
    cls, title = window_class(hwnd)
    path = process_path(hwnd)
    app_raw = "\n".join((path.lower(), cls.lower(), identity_text(title)))
    app_key = hashlib.sha256(app_raw.encode("utf-8", "ignore")).hexdigest()
    if relative is None:
        return app_key
    region = ",".join(f"{max(0.0, min(1.0, float(value))):.3f}" for value in relative)
    raw = "\n".join((app_key, region, identity_text(context)))
    return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()
def system_drive():
    return os.path.splitdrive(os.environ.get("SystemRoot", "C:\\Windows"))[0].upper()
def storage_environment(data_dir):
    temp_dir = data_dir / "临时文件"
    cache_dir = data_dir / "缓存"
    temp_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TMP"] = str(temp_dir)
    os.environ["TEMP"] = str(temp_dir)
    os.environ["PIP_CACHE_DIR"] = str(cache_dir / "pip")
    os.environ["RAPIDOCR_HOME"] = str(cache_dir / "rapidocr")
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["PIP_NO_INPUT"] = "1"
def storage_writable(data_dir):
    probe = None
    moved = None
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
        probe = data_dir / f".write-{os.getpid()}-{time.time_ns()}"
        moved = probe.with_suffix(".ok")
        with probe.open("xb") as stream:
            stream.write(b"1")
            stream.flush()
            os.fsync(stream.fileno())
        probe.replace(moved)
        moved.unlink()
        return True
    except OSError:
        try:
            if probe is not None:
                probe.unlink(missing_ok=True)
            if moved is not None:
                moved.unlink(missing_ok=True)
        except Exception:
            pass
        return False
def discover_storage():
    if winreg is None:
        return None
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REGISTRY_PATH) as key:
            value, _ = winreg.QueryValueEx(key, REGISTRY_VALUE)
        data_dir = Path(str(value))
        if data_dir.drive.upper() == system_drive() or not data_dir.is_dir() or not storage_writable(data_dir):
            return None
        return data_dir
    except OSError:
        return None
def remember_storage(data_dir):
    if winreg is None:
        return
    try:
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, REGISTRY_PATH, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, REGISTRY_VALUE, 0, winreg.REG_SZ, str(data_dir))
    except OSError:
        pass
def choose_storage(parent):
    existing = discover_storage()
    if existing is not None:
        return existing
    while True:
        selected = filedialog.askdirectory(parent=parent, title="请选择非系统盘文件夹")
        if not selected:
            return None
        path = Path(selected)
        if path.drive.upper() == system_drive():
            messagebox.showerror(APP_NAME, "请选择非系统盘文件夹。", parent=parent)
            continue
        data_dir = path if path.name == DATA_DIR_NAME else path / DATA_DIR_NAME
        if storage_writable(data_dir):
            remember_storage(data_dir)
            return data_dir
        messagebox.showerror(APP_NAME, "无法在该文件夹创建、写入并替换文件。", parent=parent)
def version_numbers(value):
    numbers = [int(part) for part in re.findall(r"\d+", str(value))[:3]]
    return tuple(numbers + [0] * (3 - len(numbers)))
def version_compatible(value, minimum, maximum_major):
    version = version_numbers(value)
    return version >= minimum and version[0] < maximum_major
def distribution_version(name, path=None):
    try:
        if path is None:
            return metadata.version(name)
        normalized = re.sub(r"[-_.]+", "-", name).lower()
        for dist in metadata.distributions(path=[str(path)]):
            dist_name = re.sub(r"[-_.]+", "-", str(dist.metadata.get("Name", ""))).lower()
            if dist_name == normalized:
                return dist.version
    except Exception:
        pass
    return None
def runtime_metadata_compatible(path=None):
    required = (("rapidocr", (3, 9, 2), 4), ("pillow", (11, 2, 1), 13), ("numpy", (1, 24, 0), 3))
    for name, minimum, maximum in required:
        value = distribution_version(name, path)
        if value is None or not version_compatible(value, minimum, maximum):
            return False
    ort_versions = [distribution_version(name, path) for name in ("onnxruntime-gpu", "onnxruntime")]
    return any(value is not None and version_compatible(value, (1, 18, 0), 2) for value in ort_versions)
def runtime_subprocess_ready(path=None, require_cuda=False):
    code = "import numpy,PIL,onnxruntime,rapidocr; assert hasattr(rapidocr,'RapidOCR'); print(','.join(onnxruntime.get_available_providers()))"
    env = os.environ.copy()
    if path is not None:
        env["PYTHONPATH"] = str(path) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    try:
        result = subprocess.run([sys.executable, "-c", code], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), text=True)
        return result.returncode == 0 and (not require_cuda or "CUDAExecutionProvider" in result.stdout)
    except Exception:
        return False
def runtime_subprocess_models_ready(path=None):
    code = """import numpy as np
from PIL import Image,ImageDraw,ImageFont
import pathlib,rapidocr
models=pathlib.Path(rapidocr.__file__).resolve().parent/'models'
if sum(1 for item in models.rglob('*.onnx') if item.is_file()) < 2:
 print(0)
 raise SystemExit
image=Image.new('L',(96,24),255)
draw=ImageDraw.Draw(image)
draw.text((2,2),'12345',fill=0,font=ImageFont.load_default())
image=image.resize((384,96))
engine=rapidocr.RapidOCR()
try:
 result=engine(np.asarray(image.convert('RGB')),use_det=True,use_cls=False,use_rec=True)
except TypeError:
 result=engine(np.asarray(image.convert('RGB')))
txts=result.get('txts') if isinstance(result,dict) else getattr(result,'txts',None)
if txts is None and isinstance(result,(tuple,list)):
 body=result[0] if len(result)==2 else result
 txts=[row[1] for row in body if isinstance(row,(tuple,list)) and len(row)>1] if isinstance(body,(tuple,list)) else []
items=[] if txts is None else list(txts)
print(1 if any(any(ch.isdigit() for ch in str(text)) for text in items) else 0)"""
    env = os.environ.copy()
    if path is not None:
        env["PYTHONPATH"] = str(path) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    try:
        result = subprocess.run([sys.executable, "-c", code], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), text=True)
        return result.returncode == 0 and bool(result.stdout.strip().splitlines()) and result.stdout.strip().splitlines()[-1] == "1"
    except Exception:
        return False
def import_runtime(data_dir=None):
    from PIL import ImageGrab, ImageTk
    import numpy as np
    import onnxruntime as ort
    import rapidocr
    providers = []
    try:
        providers = list(ort.get_available_providers())
    except Exception:
        pass
    params = {}
    if data_dir is not None:
        model_dir = Path(data_dir) / "模型"
        model_dir.mkdir(parents=True, exist_ok=True)
        params["Global.model_root_dir"] = str(model_dir)
    cuda = "CUDAExecutionProvider" in providers
    if cuda:
        params["EngineConfig.onnxruntime.use_cuda"] = True
    try:
        engine = rapidocr.RapidOCR(params=params) if params else rapidocr.RapidOCR()
    except Exception:
        if params.get("EngineConfig.onnxruntime.use_cuda"):
            params.pop("EngineConfig.onnxruntime.use_cuda", None)
            cuda = False
            engine = rapidocr.RapidOCR(params=params) if params else rapidocr.RapidOCR()
        else:
            raise
    return ImageGrab, ImageTk, np, engine, cuda
def initialize_runtime(data_dir, event_queue):
    try:
        if data_dir is not None:
            storage_environment(data_dir)
        event_queue.put(("runtime_ready", import_runtime(data_dir)))
    except Exception as exc:
        event_queue.put(("runtime_error", f"OCR 初始化失败：{type(exc).__name__}: {exc}"))
def probe_runtime(event_queue):
    event_queue.put(("runtime_status", "正在检测当前 Python 环境……"))
    if not runtime_metadata_compatible() or not runtime_subprocess_ready():
        event_queue.put(("runtime_needs_storage",))
        return
    cuda = runtime_subprocess_ready(require_cuda=True)
    models_ready = runtime_subprocess_models_ready()
    event_queue.put(("runtime_probe_ready", cuda, models_ready, nvidia_gpu_present()))
def pip_install(runtime_dir, requirements, env, process_holder):
    command = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-input", "--upgrade", "--target", str(runtime_dir), *requirements]
    process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    process_holder["process"] = process
    code = process.wait()
    process_holder["process"] = None
    return code == 0
def install_runtime_stage(stage, env, process_holder, gpu):
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True, exist_ok=True)
    base = ["rapidocr>=3.9.2,<4", "pillow>=11.2.1,<13", "numpy>=1.24,<3"]
    if not pip_install(stage, base, env, process_holder):
        return False
    package = "onnxruntime-gpu>=1.18,<2" if gpu else "onnxruntime>=1.18,<2"
    if not pip_install(stage, [package], env, process_holder):
        return False
    return runtime_metadata_compatible(stage) and runtime_subprocess_ready(stage, gpu)
def activate_runtime_stage(runtime_dir, stage):
    backup = runtime_dir.with_name(runtime_dir.name + ".old")
    shutil.rmtree(backup, ignore_errors=True)
    moved_old = False
    try:
        if runtime_dir.exists():
            runtime_dir.replace(backup)
            moved_old = True
        stage.replace(runtime_dir)
    except Exception:
        if moved_old and backup.exists() and not runtime_dir.exists():
            try:
                backup.replace(runtime_dir)
            except Exception:
                pass
        raise
    shutil.rmtree(backup, ignore_errors=True)
def cleanup_install_files(data_dir):
    shutil.rmtree(data_dir / "缓存" / "pip", ignore_errors=True)
    shutil.rmtree(data_dir / "临时文件", ignore_errors=True)
def ensure_runtime(data_dir, event_queue, process_holder):
    runtime_dir = data_dir / RUNTIME_DIR_NAME
    stage = data_dir / (RUNTIME_DIR_NAME + ".new")
    try:
        gpu = nvidia_gpu_present()
        if runtime_dir.is_dir() and runtime_metadata_compatible(runtime_dir) and runtime_subprocess_ready(runtime_dir, gpu):
            storage_environment(data_dir)
            if str(runtime_dir) not in sys.path:
                sys.path.insert(0, str(runtime_dir))
            event_queue.put(("runtime_ready", import_runtime(data_dir)))
            return
        env = os.environ.copy()
        event_queue.put(("runtime_status", "缺少合适的运行依赖，正在安装到所选非系统盘目录……"))
        ready = False
        if gpu:
            event_queue.put(("runtime_status", "检测到 NVIDIA 显卡，正在 staging GPU 推理运行时……"))
            ready = install_runtime_stage(stage, env, process_holder, True)
        if not ready:
            shutil.rmtree(stage, ignore_errors=True)
            event_queue.put(("runtime_status", "正在 staging CPU 推理运行时……"))
            ready = install_runtime_stage(stage, env, process_holder, False)
        if not ready:
            raise RuntimeError("运行依赖安装或验证失败")
        activate_runtime_stage(runtime_dir, stage)
        cleanup_install_files(data_dir)
        storage_environment(data_dir)
        if str(runtime_dir) not in sys.path:
            sys.path.insert(0, str(runtime_dir))
        event_queue.put(("runtime_ready", import_runtime(data_dir)))
    except Exception as exc:
        process_holder["process"] = None
        shutil.rmtree(stage, ignore_errors=True)
        event_queue.put(("runtime_error", f"运行依赖准备失败：{type(exc).__name__}: {exc}"))
def _format_family(kind):
    if "group" in kind:
        return "group"
    if "decimal" in kind:
        return "decimal"
    return kind
def _numeric_options(text, expected=None, format_history=()):
    text = unicodedata.normalize("NFKC", str(text)).replace("−", "-").replace("＋", "+")
    pattern = re.compile(r"[-+]?(?:\d[\d\s,'’._]*\d|\d|[.,]\d+)(?:[eE][-+]?\d+)?\s*(?:[kKmMbBtT]|万|亿)?")
    expected_value = None
    try:
        expected_value = decimal_value(expected) if expected is not None else None
    except Exception:
        pass
    history = [str(value) for value in format_history]
    exact_counts = {kind: history.count(kind) for kind in set(history)}
    family_counts = {}
    for kind in history:
        family = _format_family(kind)
        family_counts[family] = family_counts.get(family, 0) + 1
    values = []
    for match in pattern.finditer(text):
        original = match.group(0).strip()
        token = original
        suffix = ""
        if token and token[-1] in "kKmMbBtT万亿":
            suffix = token[-1]
            token = token[:-1].strip()
        scale = {"k": 3, "m": 6, "b": 9, "t": 12, "万": 4, "亿": 8}.get(suffix.lower(), 0)
        raw = token.replace(" ", "").replace("'", "").replace("’", "").replace("_", "")
        exponent = ""
        base = raw
        split = re.split(r"([eE][-+]?\d+)$", raw)
        if len(split) >= 3:
            base = split[0]
            exponent = split[1]
        forms = []
        if "." in base and "," in base:
            last_dot = base.rfind(".")
            last_comma = base.rfind(",")
            decimal_mark = "." if last_dot > last_comma else ","
            thousands = "," if decimal_mark == "." else "."
            kind = f"mixed_{'dot' if decimal_mark == '.' else 'comma'}_decimal"
            forms.append((base.replace(thousands, "").replace(decimal_mark, ".") + exponent, kind, 0))
        elif "," in base:
            pieces = base.split(",")
            grouped = len(pieces) > 1 and pieces[0].lstrip("+-").isdigit() and all(len(piece) == 3 and piece.isdigit() for piece in pieces[1:])
            if grouped:
                forms.extend(((base.replace(",", "") + exponent, "comma_group", 0), (base.replace(",", ".") + exponent, "comma_decimal", 1)))
            else:
                forms.append((base.replace(",", ".") + exponent, "comma_decimal", 0))
        elif "." in base:
            pieces = base.split(".")
            grouped = len(pieces) > 1 and pieces[0].lstrip("+-").isdigit() and all(len(piece) == 3 and piece.isdigit() for piece in pieces[1:])
            forms.append((base + exponent, "dot_decimal", 0))
            if grouped:
                forms.append((base.replace(".", "") + exponent, "dot_group", 1))
        else:
            forms.append((base + exponent, "plain", 0))
        parsed = []
        seen = set()
        for form, kind, prior in forms:
            try:
                value = decimal_value(Decimal(form))
                if scale:
                    parts = value.as_tuple()
                    value = decimal_value(Decimal((parts.sign, parts.digits, parts.exponent + scale)))
                if value in seen:
                    continue
                seen.add(value)
                distance = abs(value - expected_value) if expected_value is not None else Decimal(0)
                score = (-exact_counts.get(kind, 0), -family_counts.get(_format_family(kind), 0), prior, distance)
                parsed.append((score, value, original, kind))
            except Exception:
                pass
        parsed.sort(key=lambda item: item[0])
        values.extend((value, token_text, kind) for _, value, token_text, kind in parsed)
    return values
def numeric_candidates(text, expected=None, format_history=()):
    return [(value, token) for value, token, _ in _numeric_options(text, expected, format_history)]
class OCRReader:
    def __init__(self, ImageGrab, np, engine):
        self.ImageGrab = ImageGrab
        self.np = np
        self.engine = engine
        self.lock = threading.RLock()
        self.latencies = deque(maxlen=256)
        self.confidences = deque(maxlen=256)
        self.number_formats = deque(maxlen=64)
        self.visual_clusters = {}
    @staticmethod
    def _float(value, default=0.0):
        try:
            if isinstance(value, (list, tuple)):
                value = value[0] if value else default
            value = float(value)
            return min(1.0, max(0.0, value)) if math.isfinite(value) else default
        except Exception:
            return default
    def capture_client(self, hwnd):
        if not hwnd or not user32.IsWindow(hwnd) or not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
            return None
        window = window_screen_rect(hwnd)
        client = client_screen_rect(hwnd)
        if window is None or client is None:
            return None
        try:
            image = self.ImageGrab.grab(window=int(hwnd))
        except Exception:
            return None
        if image is None or image.width <= 0 or image.height <= 0:
            return None
        ww, wh = window[2] - window[0], window[3] - window[1]
        cw, ch = client[2] - client[0], client[3] - client[1]
        if ww <= 0 or wh <= 0 or cw <= 0 or ch <= 0:
            return None
        client_error = abs(image.width - cw) / cw + abs(image.height - ch) / ch
        window_error = abs(image.width - ww) / ww + abs(image.height - wh) / wh
        if client_error <= window_error:
            return image
        sx = image.width / ww
        sy = image.height / wh
        x1 = int(round((client[0] - window[0]) * sx))
        y1 = int(round((client[1] - window[1]) * sy))
        x2 = int(round((client[2] - window[0]) * sx))
        y2 = int(round((client[3] - window[1]) * sy))
        x1 = max(0, min(image.width, x1))
        y1 = max(0, min(image.height, y1))
        x2 = max(0, min(image.width, x2))
        y2 = max(0, min(image.height, y2))
        return image.crop((x1, y1, x2, y2)) if x2 > x1 and y2 > y1 else None
    @staticmethod
    def _relative_pixels(image, relative):
        x1, y1, x2, y2 = map(float, relative)
        left = max(0, min(image.width, int(math.floor(x1 * image.width))))
        top = max(0, min(image.height, int(math.floor(y1 * image.height))))
        right = max(0, min(image.width, int(math.ceil(x2 * image.width))))
        bottom = max(0, min(image.height, int(math.ceil(y2 * image.height))))
        return (left, top, right, bottom) if right > left and bottom > top else None
    def _run(self, image, detect):
        arr = self.np.asarray(image.convert("RGB"))
        started = time.monotonic()
        with self.lock:
            try:
                result = self.engine(arr, use_det=bool(detect), use_cls=False, use_rec=True)
            except TypeError:
                result = self.engine(arr)
        latency = time.monotonic() - started
        if latency > 0:
            self.latencies.append(latency)
        return result, latency
    def _texts(self, result):
        txts = result.get("txts") if isinstance(result, dict) else getattr(result, "txts", None)
        scores = result.get("scores") if isinstance(result, dict) else getattr(result, "scores", None)
        rows = []
        if txts is not None:
            try:
                texts = list(txts)
            except TypeError:
                texts = [txts]
            try:
                score_list = list(scores) if scores is not None and not isinstance(scores, (str, bytes, int, float)) else []
            except TypeError:
                score_list = []
            for index, raw in enumerate(texts):
                score = score_list[index] if index < len(score_list) else scores
                if isinstance(raw, dict):
                    text = raw.get("text") or raw.get("txt") or ""
                    score = raw.get("score", score)
                elif isinstance(raw, (tuple, list)):
                    text = raw[0] if raw else ""
                    if len(raw) > 1 and score is None:
                        score = raw[1]
                else:
                    text = raw
                text = unicodedata.normalize("NFKC", str(text)).strip()
                if text:
                    rows.append((text, self._float(score)))
            if rows:
                return rows
        body = result[0] if isinstance(result, (tuple, list)) and len(result) == 2 else result
        if isinstance(body, (tuple, list)):
            for item in body:
                if isinstance(item, (tuple, list)) and len(item) >= 2:
                    rows.append((str(item[1]), self._float(item[2] if len(item) > 2 else 0.0)))
        return rows
    def _format_score(self, kind):
        exact = sum(value == kind for value in self.number_formats)
        family = _format_family(kind)
        related = sum(_format_family(value) == family for value in self.number_formats)
        return exact, related
    def _remember_format(self, kind):
        if kind:
            self.number_formats.append(str(kind))
    def measure_image(self, image, expected=None):
        candidates = []
        total_latency = 0.0
        for detect in (False, True):
            try:
                result, latency = self._run(image, detect)
                total_latency += latency
                for text, confidence in self._texts(result):
                    for rank, (value, token, kind) in enumerate(_numeric_options(text, expected, self.number_formats)):
                        exact, related = self._format_score(kind)
                        candidates.append((-exact, -related, -float(confidence), -sum(ch.isdigit() for ch in token), rank, value, token, kind))
                if candidates:
                    break
            except Exception:
                continue
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[:5])
        chosen = candidates[0]
        confidence = -float(chosen[2])
        return {"value": chosen[5], "confidence": confidence, "text": chosen[6], "latency": total_latency, "format": chosen[7]}
    def measure_relative(self, client_image, relative, expected=None):
        rect = self._relative_pixels(client_image, relative)
        return self.measure_image(client_image.crop(rect), expected) if rect is not None else None
    @staticmethod
    def _number_format(text):
        text = unicodedata.normalize("NFKC", str(text)).strip().lower()
        return re.sub(r"\d+", "#", text)
    def direct_trusted(self, measurement, previous_text=None):
        floor = self.confidence_floor()
        if measurement is None or floor is None or measurement.get("confidence", 0.0) < floor:
            return False
        if previous_text and self._number_format(measurement.get("text", "")) != self._number_format(previous_text):
            return False
        return True
    def locate_number_image(self, client_image, relative, expected=None, preferred=None, expected_text=None):
        rect = self._relative_pixels(client_image, relative)
        if rect is None:
            return None
        image = client_image.crop(rect)
        width, height = image.size
        if width <= 0 or height <= 0:
            return None
        try:
            result, latency = self._run(image, True)
            rows = self._detected_rows(result, width, height)
        except Exception:
            return None
        rx1, ry1, rx2, ry2 = map(float, relative)
        span = max(math.hypot(rx2 - rx1, ry2 - ry1), 1.0 / max(client_image.width, client_image.height))
        expected_format = self._number_format(expected_text) if expected_text else None
        candidates = []
        for row in rows:
            for rank, (value, token, kind) in enumerate(_numeric_options(row["text"], expected, self.number_formats)):
                cx = rx1 + row["x"] * (rx2 - rx1)
                cy = ry1 + row["y"] * (ry2 - ry1)
                location_distance = math.hypot(cx - preferred[0], cy - preferred[1]) / span if preferred is not None else 0.0
                format_distance = 0 if expected_format is None or self._number_format(token) == expected_format else 1
                value_distance = 0.0 if expected is None else decimal_log_distance(value, expected)
                confidence = float(row["confidence"])
                digits = sum(ch.isdigit() for ch in token)
                exact, related = self._format_score(kind)
                x1 = rx1 + (row["x"] - row["w"] / 2) * (rx2 - rx1)
                y1 = ry1 + (row["y"] - row["h"] / 2) * (ry2 - ry1)
                x2 = rx1 + (row["x"] + row["w"] / 2) * (rx2 - rx1)
                y2 = ry1 + (row["y"] + row["h"] / 2) * (ry2 - ry1)
                candidates.append((-exact, -related, format_distance, -confidence, location_distance, value_distance, -digits, rank, value, token, kind, confidence, (x1, y1, x2, y2)))
        if not candidates:
            return None
        candidates.sort(key=lambda item: item[:8])
        chosen = candidates[0]
        return {"value": chosen[8], "confidence": chosen[11], "text": chosen[9], "latency": latency, "box": chosen[12], "format": chosen[10]}
    def accept_measurement(self, measurement):
        if measurement is None:
            return
        confidence = self._float(measurement.get("confidence"), 0.0)
        if confidence > 0:
            self.confidences.append(confidence)
        self._remember_format(measurement.get("format"))
    def confidence_floor(self):
        return confidence_threshold(self.confidences)
    def confirmation_floor(self):
        return confirmation_threshold(self.confidences)
    @staticmethod
    def _normalized_text(text):
        text = unicodedata.normalize("NFKC", str(text)).strip().lower()
        text = re.sub(r"[-+]?\d[\d\s,'’._]*(?:[eE][-+]?\d+)?", "#", text)
        return re.sub(r"\s+", " ", text)
    def _detected_rows(self, result, width, height):
        txts = result.get("txts") if isinstance(result, dict) else getattr(result, "txts", None)
        boxes = result.get("boxes") if isinstance(result, dict) else getattr(result, "boxes", None)
        scores = result.get("scores") if isinstance(result, dict) else getattr(result, "scores", None)
        if txts is None or boxes is None or width <= 0 or height <= 0:
            return []
        try:
            texts = list(txts)
            boxes = list(boxes)
            score_list = list(scores) if scores is not None and not isinstance(scores, (str, bytes, int, float)) else []
        except TypeError:
            return []
        rows = []
        for index, raw in enumerate(texts):
            if index >= len(boxes):
                break
            try:
                points = self.np.asarray(boxes[index], dtype="float64").reshape(-1, 2)
                if len(points) < 2:
                    continue
                x1 = max(0.0, min(float(width), float(points[:, 0].min())))
                y1 = max(0.0, min(float(height), float(points[:, 1].min())))
                x2 = max(0.0, min(float(width), float(points[:, 0].max())))
                y2 = max(0.0, min(float(height), float(points[:, 1].max())))
                if x2 <= x1 or y2 <= y1:
                    continue
            except Exception:
                continue
            if isinstance(raw, dict):
                text = raw.get("text") or raw.get("txt") or ""
                score = raw.get("score", score_list[index] if index < len(score_list) else 0.0)
            elif isinstance(raw, (tuple, list)):
                text = raw[0] if raw else ""
                score = raw[1] if len(raw) > 1 else (score_list[index] if index < len(score_list) else 0.0)
            else:
                text = raw
                score = score_list[index] if index < len(score_list) else 0.0
            rows.append({"x": ((x1 + x2) / 2) / width, "y": ((y1 + y2) / 2) / height, "w": (x2 - x1) / width, "h": (y2 - y1) / height, "text": unicodedata.normalize("NFKC", str(text)).strip(), "confidence": self._float(score)})
        rows.sort(key=lambda row: (row["y"], row["x"]))
        return rows
    def _visual_signature(self, image, ignore_relative=None):
        side = visual_hash_side(image.size)
        gray = image.convert("L").resize((side + 1, side))
        values = self.np.asarray(gray, dtype="float64").copy()
        if ignore_relative is not None:
            rx1, ry1, rx2, ry2 = ignore_relative
            x1 = max(0, min(values.shape[1], int(math.floor(rx1 * values.shape[1]))))
            y1 = max(0, min(values.shape[0], int(math.floor(ry1 * values.shape[0]))))
            x2 = max(0, min(values.shape[1], int(math.ceil(rx2 * values.shape[1]))))
            y2 = max(0, min(values.shape[0], int(math.ceil(ry2 * values.shape[0]))))
            if x2 > x1 and y2 > y1:
                mask = self.np.ones(values.shape, dtype=bool)
                mask[y1:y2, x1:x2] = False
                fill = float(self.np.median(values[mask])) if mask.any() else float(self.np.median(values))
                values[y1:y2, x1:x2] = fill
        bits = values[:, 1:] >= values[:, :-1]
        packed = 0
        for bit in bits.reshape(-1):
            packed = (packed << 1) | int(bool(bit))
        return f"{packed:0{max(1, (bits.size + 3) // 4)}x}"
    @staticmethod
    def _visual_distance(first, second):
        if not first or not second or len(first) != len(second):
            return math.inf
        try:
            return bin(int(first, 16) ^ int(second, 16)).count("1")
        except Exception:
            return math.inf
    def _visual_cluster(self, structure, visual):
        clusters = self.visual_clusters.setdefault(structure, [])
        bits = max(1, len(visual) * 4)
        threshold = max(2, int(round(math.sqrt(bits))))
        if clusters:
            distances = [(self._visual_distance(visual, item["visual"]), index) for index, item in enumerate(clusters)]
            distance, index = min(distances)
            if distance <= threshold:
                clusters[index]["seen"] += 1
                return index
        limit = max(2, int(round(math.sqrt(STATE_CAPACITY))))
        if len(clusters) < limit:
            clusters.append({"visual": visual, "seen": 1})
            return len(clusters) - 1
        return min(range(len(clusters)), key=lambda index: self._visual_distance(visual, clusters[index]["visual"]))
    def observe_state_image(self, image, ignore_relative=None):
        width, height = image.size
        visual = self._visual_signature(image, ignore_relative)
        rows = []
        try:
            result, _ = self._run(image, True)
            rows = self._detected_rows(result, width, height)
        except Exception:
            pass
        if ignore_relative is not None:
            rx1, ry1, rx2, ry2 = ignore_relative
            rows = [row for row in rows if not (rx1 <= row["x"] <= rx2 and ry1 <= row["y"] <= ry2)]
        def clusters(axis, extent):
            order = sorted(range(len(rows)), key=lambda index: rows[index][axis])
            result = {}
            group = 0
            previous = None
            for index in order:
                row = rows[index]
                if previous is not None:
                    gap = row[axis] - previous[axis]
                    tolerance = max(row[extent], previous[extent]) / 2
                    if gap > tolerance:
                        group += 1
                result[index] = group
                previous = row
            return result
        x_groups = clusters("x", "w")
        y_groups = clusters("y", "h")
        target = relative_center(ignore_relative) if ignore_relative is not None else None
        layout = []
        for index, row in enumerate(rows):
            relation = (0, 0)
            if target is not None:
                tx, ty = target
                tw = ignore_relative[2] - ignore_relative[0]
                th = ignore_relative[3] - ignore_relative[1]
                dx = row["x"] - tx
                dy = row["y"] - ty
                x_tolerance = (tw + row["w"]) / 2
                y_tolerance = (th + row["h"]) / 2
                relation = (-1 if dx < -x_tolerance else 1 if dx > x_tolerance else 0, -1 if dy < -y_tolerance else 1 if dy > y_tolerance else 0)
            layout.append((self._normalized_text(row["text"]), x_groups[index], y_groups[index], relation[0], relation[1]))
        structure = hashlib.sha256(json.dumps(layout, ensure_ascii=False, separators=(",", ":")).encode("utf-8", "ignore")).hexdigest()
        cluster = self._visual_cluster(structure, visual)
        state_id = hashlib.sha256(f"{structure}:{cluster}".encode("ascii")).hexdigest()
        boxes = [(row["x"], row["y"], row["w"], row["h"], self._normalized_text(row["text"])) for row in rows]
        return {"id": state_id, "coarse": structure, "fine": cluster, "visual": visual, "structure": structure, "boxes": boxes}
    def visual_state_image(self, image, ignore_relative=None):
        return self._visual_signature(image, ignore_relative)
    def typical_latency(self):
        values = [value for value in self.latencies if value > 0 and math.isfinite(value)]
        return median(values) if values else 0.0
class SelectionOverlay:
    def __init__(self, root, ImageTk, screenshot, screen_rect, callback):
        self.root = root
        self.ImageTk = ImageTk
        self.screenshot = screenshot
        self.screen_rect = screen_rect
        self.callback = callback
        self.start = None
        self.rect_id = None
        left, top, right, bottom = screen_rect
        self.window = tk.Toplevel(root)
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        self.window.geometry(f"{right-left}x{bottom-top}{left:+d}{top:+d}")
        self.canvas = tk.Canvas(self.window, highlightthickness=0, cursor="crosshair")
        self.canvas.pack(fill="both", expand=True)
        self.photo = ImageTk.PhotoImage(screenshot)
        self.canvas.create_image(0, 0, image=self.photo, anchor="nw")
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.window.bind("<Escape>", lambda _event: self.finish(None))
        self.window.focus_force()
    def _press(self, event):
        self.start = (event.x, event.y)
        if self.rect_id is not None:
            self.canvas.delete(self.rect_id)
        self.rect_id = self.canvas.create_rectangle(event.x, event.y, event.x, event.y, outline="red", width=2)
    def _drag(self, event):
        if self.start is None or self.rect_id is None:
            return
        self.canvas.coords(self.rect_id, self.start[0], self.start[1], event.x, event.y)
    def _release(self, event):
        if self.start is None:
            self.finish(None)
            return
        x1, y1 = self.start
        x2, y2 = event.x, event.y
        if x1 == x2 or y1 == y2:
            self.finish(None)
            return
        left, top, _, _ = self.screen_rect
        self.finish((left + min(x1, x2), top + min(y1, y2), left + max(x1, x2), top + max(y1, y2)))
    def finish(self, rect):
        try:
            self.window.destroy()
        except tk.TclError:
            pass
        self.callback(rect)
class ControlStop:
    MESSAGES = {
        "user_keyboard": "检测到用户键盘操作，AI 已停止控制并继续学习",
        "user_mouse": "检测到用户鼠标操作，AI 已停止控制并继续学习",
        "esc": "检测到 ESC，AI 已停止控制并继续学习",
        "input_hook_lost": "用户接管监控失效，AI 已停止控制并继续学习",
        "target_changed": "目标窗口已变化，AI 已停止控制并继续学习",
        "target_read_failed": "无法可靠读取目标数值，AI 已停止控制并继续尝试学习",
        "input_failed": "输入控制失败，AI 已停止控制并继续学习",
        "no_safe_action": "暂无可靠增益动作，AI 已停止控制并继续学习",
        "internal_error": "AI 内部运行异常，已停止控制",
        "closed": "程序已关闭",
        "requested": "AI 已停止控制",
    }
    def __init__(self):
        self.event = threading.Event()
        self.lock = threading.RLock()
        self.reason = ""
        self.generation = 0
        self.guard = None
    def set_guard(self, guard):
        with self.lock:
            self.guard = guard
    def clear(self):
        with self.lock:
            self.generation += 1
            self.reason = ""
            self.event.clear()
            return self.generation
    def set(self, reason):
        with self.lock:
            first = not self.event.is_set()
            if first:
                self.generation += 1
                self.reason = str(reason)
                self.event.set()
            return first
    def is_set(self):
        return self.event.is_set()
    def message(self):
        with self.lock:
            return self.MESSAGES.get(self.reason or "requested", "AI 已停止")
    def send(self, generation, sender, cleanup=False, kind="other", point=None):
        with self.lock:
            if not cleanup:
                if self.event.is_set() or generation != self.generation:
                    return False
                if self.guard is not None and not self.guard(kind, point):
                    return False
            return bool(sender())
_PRESSED_KEYS = set()
_PRESSED_MOUSE = set()
_INPUT_LOCK = threading.RLock()
def key_capability(vk):
    if vk in {VK_ESCAPE, 0x08, 0x10, 0x11, 0x12, 0x14, 0x2C, 0x2D, 0x2E, 0x5B, 0x5C, 0x5D, 0x90, 0x91, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5}:
        return None
    if 0x70 <= vk <= 0x87 or 0xA6 <= vk <= 0xB7:
        return None
    scan_ex = int(user32.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC_EX) or 0)
    scan = scan_ex & 0xFF
    if not scan:
        scan = int(user32.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC) or 0) & 0xFF
    if not scan:
        return None
    return scan, bool(scan_ex & 0xFF00)
def keyboard_actions():
    groups = ((1, (0x26, 0x6B), 3.0), (2, (0x21,), 4.0))
    actions = []
    for tier, keys, priority in groups:
        for offset, vk in enumerate(keys):
            if key_capability(vk) is not None:
                actions.append(Action(f"key:{vk}", "key", vk, tier, priority + offset / max(1, len(keys))))
    return actions
def send_key(vk, up, stop, generation):
    capability = key_capability(vk)
    if capability is None:
        return False
    scan, extended = capability
    flags = KEYEVENTF_SCANCODE | (KEYEVENTF_EXTENDEDKEY if extended else 0) | (KEYEVENTF_KEYUP if up else 0)
    inp = INPUT(type=INPUT_KEYBOARD)
    inp.ki = KEYBDINPUT(0, scan, flags, 0, AI_INPUT_MAGIC)
    def do_send():
        ok = int(user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))) == 1
        if ok:
            with _INPUT_LOCK:
                if up:
                    _PRESSED_KEYS.discard(vk)
                else:
                    _PRESSED_KEYS.add(vk)
        return ok
    return stop.send(generation, do_send, cleanup=up, kind="keyboard")
def press_key(vk, stop, generation, hold):
    if not send_key(vk, False, stop, generation):
        return False
    interrupted = False
    if hold > 0:
        interrupted = stop.event.wait(hold)
    released = send_key(vk, True, stop, generation)
    return bool(released and not interrupted)
def send_mouse(flags, stop, generation, dx=0, dy=0, data=0, point=None, cleanup=False):
    inp = INPUT(type=INPUT_MOUSE)
    inp.mi = MOUSEINPUT(int(dx), int(dy), int(data) & 0xFFFFFFFF, int(flags), 0, AI_INPUT_MAGIC)
    def do_send():
        ok = int(user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))) == 1
        if ok:
            with _INPUT_LOCK:
                if flags & MOUSEEVENTF_LEFTDOWN:
                    _PRESSED_MOUSE.add("left")
                if flags & MOUSEEVENTF_LEFTUP:
                    _PRESSED_MOUSE.discard("left")
        return ok
    return stop.send(generation, do_send, cleanup=cleanup, kind="pointer", point=point)
def move_pointer(x, y, stop, generation):
    left, top, right, bottom = virtual_screen_rect()
    width = right - left
    height = bottom - top
    if width <= 1 or height <= 1:
        return False
    px = min(right - 1, max(left, int(round(x))))
    py = min(bottom - 1, max(top, int(round(y))))
    dx = int(round((px - left) * 65535 / (width - 1)))
    dy = int(round((py - top) * 65535 / (height - 1)))
    return send_mouse(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK, stop, generation, dx=dx, dy=dy, point=(px, py))
def click_point(x, y, stop, generation):
    if not move_pointer(x, y, stop, generation):
        return False
    if not send_mouse(MOUSEEVENTF_LEFTDOWN, stop, generation, point=(x, y)):
        return False
    return send_mouse(MOUSEEVENTF_LEFTUP, stop, generation, point=(x, y), cleanup=True)
def scroll_point(x, y, amount, stop, generation):
    if not move_pointer(x, y, stop, generation):
        return False
    return send_mouse(MOUSEEVENTF_WHEEL, stop, generation, data=amount, point=(x, y))
def release_all_inputs():
    cleanup = ControlStop()
    generation = cleanup.clear()
    with _INPUT_LOCK:
        keys = list(_PRESSED_KEYS)
        mouse = set(_PRESSED_MOUSE)
    for vk in keys:
        try:
            send_key(vk, True, cleanup, generation)
        except Exception:
            pass
    if "left" in mouse:
        try:
            send_mouse(MOUSEEVENTF_LEFTUP, cleanup, generation, cleanup=True)
        except Exception:
            pass
class UserInputStopHook:
    KEY_MESSAGES = {WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP}
    MOUSE_MESSAGES = {WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP, WM_RBUTTONDOWN, WM_RBUTTONUP, WM_MBUTTONDOWN, WM_MBUTTONUP, WM_XBUTTONDOWN, WM_XBUTTONUP, WM_MOUSEWHEEL, WM_MOUSEHWHEEL}
    def __init__(self, stop, events, session_id=None, target_hwnd=0):
        self.stop = stop
        self.events = events
        self.session_id = session_id
        self.target_hwnd = int(target_hwnd or 0)
        self.demonstrations = queue.Queue()
        self.ready = threading.Event()
        self.armed = threading.Event()
        self.takeover_phase = threading.Event()
        self.shutdown = threading.Event()
        self.emergency = threading.Event()
        self.hooked = False
        self.thread_id = 0
        self.thread = None
        self.release_thread = None
        self.keyboard_hook = None
        self.mouse_hook = None
        self.keyboard_callback = None
        self.mouse_callback = None
        self.last_physical = time.monotonic()
    def quiet_seconds(self):
        try:
            return max(time.get_clock_info("monotonic").resolution, float(user32.GetDoubleClickTime()) / 1000.0)
        except Exception:
            return time.get_clock_info("monotonic").resolution
    def _physical_released(self):
        try:
            return not any(user32.GetAsyncKeyState(vk) & 0x8000 for vk in range(1, 256))
        except Exception:
            return False
    def discard_demonstrations(self):
        try:
            while True:
                self.demonstrations.get_nowait()
        except queue.Empty:
            pass
    def begin_takeover_phase(self):
        self.discard_demonstrations()
        self.armed.clear()
        self.takeover_phase.set()
    def begin_passive_phase(self):
        self.takeover_phase.clear()
        self.armed.set()
    def try_arm(self):
        if self.armed.is_set():
            return True
        if self._physical_released() and time.monotonic() - self.last_physical >= self.quiet_seconds():
            self.armed.set()
            return True
        return False
    def _takeover(self, reason):
        if self.takeover_phase.is_set() and self.stop.set(reason):
            self.emergency.set()
    def _record(self, kind, payload):
        if not self.armed.is_set() or not self.target_hwnd:
            return
        try:
            on_target = foreground_root() == self.target_hwnd
            if not on_target and kind in {"click", "scroll"} and isinstance(payload, (tuple, list)) and len(payload) >= 2:
                on_target = top_level_window_at(float(payload[0]), float(payload[1])) == self.target_hwnd
            if not on_target:
                return
        except Exception:
            return
        self.demonstrations.put((time.monotonic(), str(kind), payload))
    def next_demonstration(self, timeout=0.0):
        try:
            return self.demonstrations.get(timeout=max(0.0, float(timeout)))
        except queue.Empty:
            return None
    def _release_worker(self):
        while not self.shutdown.is_set():
            self.emergency.wait()
            if self.shutdown.is_set():
                break
            self.emergency.clear()
            release_all_inputs()
            quiet = self.quiet_seconds()
            while not self.shutdown.is_set() and (not self._physical_released() or time.monotonic() - self.last_physical < quiet):
                self.shutdown.wait(max(time.get_clock_info("monotonic").resolution, quiet / max(2.0, math.sqrt(SAMPLE_CAPACITY))))
            if not self.shutdown.is_set():
                self.events.put(("user_takeover", self.session_id, self.stop.message()))
    def start(self):
        self.release_thread = threading.Thread(target=self._release_worker, name="input-release", daemon=True)
        self.release_thread.start()
        self.thread = threading.Thread(target=self._run, name="input-hook", daemon=True)
        self.thread.start()
        self.ready.wait(self.quiet_seconds())
        return self.is_healthy()
    def is_healthy(self):
        return bool(self.hooked and self.thread and self.thread.is_alive() and self.keyboard_hook and self.mouse_hook)
    def _run(self):
        self.thread_id = int(kernel32.GetCurrentThreadId())
        proc_type = ctypes.WINFUNCTYPE(wintypes.LPARAM, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
        def keyboard_proc(code, message, data):
            if code >= 0 and int(message) in self.KEY_MESSAGES:
                try:
                    info = ctypes.cast(data, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                    if int(info.dwExtraInfo or 0) != AI_INPUT_MAGIC:
                        self.last_physical = time.monotonic()
                        vk = int(info.vkCode)
                        self._takeover("esc" if vk == VK_ESCAPE else "user_keyboard")
                        if int(message) in {WM_KEYDOWN, WM_SYSKEYDOWN} and vk != VK_ESCAPE and key_capability(vk) is not None:
                            self._record("key", vk)
                except Exception:
                    self._takeover("input_hook_lost")
            return user32.CallNextHookEx(self.keyboard_hook, code, message, data)
        def mouse_proc(code, message, data):
            if code >= 0 and int(message) in self.MOUSE_MESSAGES:
                try:
                    info = ctypes.cast(data, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                    if int(info.dwExtraInfo or 0) != AI_INPUT_MAGIC:
                        self.last_physical = time.monotonic()
                        self._takeover("user_mouse")
                        if int(message) == WM_LBUTTONUP:
                            self._record("click", (int(info.pt.x), int(info.pt.y)))
                        elif int(message) == WM_MOUSEWHEEL:
                            amount = ctypes.c_short((int(info.mouseData) >> 16) & 0xFFFF).value
                            if amount:
                                self._record("scroll", (int(info.pt.x), int(info.pt.y), int(amount)))
                except Exception:
                    self._takeover("input_hook_lost")
            return user32.CallNextHookEx(self.mouse_hook, code, message, data)
        self.keyboard_callback = proc_type(keyboard_proc)
        self.mouse_callback = proc_type(mouse_proc)
        module = kernel32.GetModuleHandleW(None)
        self.keyboard_hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL, ctypes.cast(self.keyboard_callback, ctypes.c_void_p), module, 0)
        self.mouse_hook = user32.SetWindowsHookExW(WH_MOUSE_LL, ctypes.cast(self.mouse_callback, ctypes.c_void_p), module, 0)
        self.hooked = bool(self.keyboard_hook and self.mouse_hook)
        self.last_physical = time.monotonic()
        self.ready.set()
        if not self.hooked:
            if self.keyboard_hook:
                user32.UnhookWindowsHookEx(self.keyboard_hook)
            if self.mouse_hook:
                user32.UnhookWindowsHookEx(self.mouse_hook)
            self.keyboard_hook = None
            self.mouse_hook = None
            return
        msg = wintypes.MSG()
        while not self.shutdown.is_set() and user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        if self.keyboard_hook:
            user32.UnhookWindowsHookEx(self.keyboard_hook)
        if self.mouse_hook:
            user32.UnhookWindowsHookEx(self.mouse_hook)
        self.keyboard_hook = None
        self.mouse_hook = None
        self.hooked = False
    def close(self):
        self.shutdown.set()
        self.emergency.set()
        if self.thread_id:
            try:
                user32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)
            except Exception:
                pass
        timeout = self.quiet_seconds()
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=timeout)
        if self.release_thread and self.release_thread is not threading.current_thread():
            self.release_thread.join(timeout=timeout)
        self.hooked = False
class Action:
    __slots__ = ("id", "kind", "payload", "tier", "priority", "locator")
    def __init__(self, action_id, kind, payload, tier=3, priority=0.0, locator=None):
        self.id = str(action_id)
        self.kind = str(kind)
        self.payload = payload
        self.tier = max(1, int(tier))
        self.priority = float(priority)
        self.locator = locator
class OnlineLearner:
    FILE_LOCK = threading.RLock()
    def __init__(self, path, target_key):
        self.path = Path(path) if path is not None else None
        self.target_key = target_key
        self.states = {}
        self.dirty = False
        self.dirty_events = 0
        self.last_save = time.monotonic()
        self.rng = random.SystemRandom()
        self.lock = threading.RLock()
        self._load()
    def _load(self):
        if self.path is None:
            return
        try:
            with self.FILE_LOCK:
                data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.is_file() else {}
            target = data.get("targets", {}).get(self.target_key, {})
            states = target.get("states", {})
            if not isinstance(states, dict):
                return
            for state_id, state_data in states.items():
                if not isinstance(state_data, dict):
                    continue
                actions = {}
                for action_id, action_data in state_data.get("actions", {}).items():
                    if not isinstance(action_data, dict):
                        continue
                    samples = []
                    for row in action_data.get("samples", []):
                        if not isinstance(row, list) or len(row) != 5:
                            continue
                        before, delta, weight, next_state, source = row
                        try:
                            before = decimal_value(before)
                            delta = decimal_value(delta)
                            weight = float(weight)
                        except Exception:
                            continue
                        if math.isfinite(weight) and weight > 0:
                            samples.append([before, delta, weight, str(next_state), str(source)])
                    samples = samples[-SAMPLE_CAPACITY:]
                    transitions = {}
                    for next_state, value in action_data.get("transitions", {}).items():
                        try:
                            value = float(value)
                        except Exception:
                            continue
                        if math.isfinite(value) and value > 0:
                            transitions[str(next_state)] = value
                    if len(transitions) > TRANSITION_CAPACITY:
                        transitions = dict(sorted(transitions.items(), key=lambda item: item[1], reverse=True)[:TRANSITION_CAPACITY])
                    try:
                        trials = max(0, int(action_data.get("trials", 0)))
                    except Exception:
                        trials = 0
                    try:
                        seen = max(len(samples), int(action_data.get("seen", len(samples))))
                    except Exception:
                        seen = len(samples)
                    definition = action_data.get("definition") if isinstance(action_data.get("definition"), dict) else None
                    actions[str(action_id)] = {"trials": trials, "seen": seen, "samples": samples, "transitions": transitions, "definition": definition}
                if len(actions) > ACTION_CAPACITY:
                    actions = dict(sorted(actions.items(), key=lambda item: self._action_evidence(item[1]), reverse=True)[:ACTION_CAPACITY])
                passive_data = state_data.get("passive", {}) if isinstance(state_data.get("passive", {}), dict) else {}
                passive_values = []
                for row in passive_data.get("values", []):
                    if not isinstance(row, list) or len(row) != 2:
                        continue
                    try:
                        value = decimal_value(row[0])
                        weight = float(row[1])
                    except Exception:
                        continue
                    if math.isfinite(weight) and weight > 0:
                        passive_values.append([value, weight])
                passive_values = passive_values[-SAMPLE_CAPACITY:]
                try:
                    passive_seen = max(len(passive_values), int(passive_data.get("seen", len(passive_values))))
                except Exception:
                    passive_seen = len(passive_values)
                try:
                    best = decimal_value(passive_data.get("best")) if passive_data.get("best") is not None else None
                except Exception:
                    best = None
                self.states[str(state_id)] = {"actions": actions, "passive": {"seen": passive_seen, "values": passive_values, "best": best}}
            self.consolidate()
        except Exception:
            self.states = {}
    @staticmethod
    def _action_evidence(data):
        positive = any(row[1] > 0 for row in data.get("samples", ()))
        return (1 if positive else 0, int(data.get("trials", 0)) + int(data.get("seen", 0)))
    def _mark_dirty(self, count=1):
        self.dirty = True
        self.dirty_events += max(1, int(count))
    def _state_data(self, state_id, create=False):
        state = self.states.get(state_id)
        if state is None and create:
            state = self.states.setdefault(state_id, {"actions": {}, "passive": {"seen": 0, "values": [], "best": None}})
            self._mark_dirty()
        return state
    def _action_data(self, state_id, action_id, create=False):
        state = self._state_data(state_id, create)
        if state is None:
            return None
        action = state["actions"].get(action_id)
        if action is None and create:
            actions = state["actions"]
            if len(actions) >= ACTION_CAPACITY:
                victim = min(actions.items(), key=lambda item: self._action_evidence(item[1]))[0]
                actions.pop(victim, None)
            action = actions.setdefault(action_id, {"trials": 0, "seen": 0, "samples": [], "transitions": {}, "definition": None})
            self._mark_dirty()
        return action
    def _reservoir_append(self, data, key, row):
        seen_key = "seen" if key == "samples" else key + "_seen"
        data[seen_key] = int(data.get(seen_key, 0)) + 1
        values = data.setdefault(key, [])
        capacity = SAMPLE_CAPACITY
        if len(values) < capacity:
            values.append(row)
            return
        index = self.rng.randrange(data[seen_key])
        if index < capacity:
            values[index] = row
    def count(self, state_id, action_id):
        data = self._action_data(state_id, action_id)
        return int(data.get("trials", 0)) if data else 0
    def _weighted_rows(self, state_id, action_id, current, source=None):
        data = self._action_data(state_id, action_id)
        rows = data.get("samples", ()) if data else ()
        if source is not None:
            sources = {str(value) for value in source} if isinstance(source, (tuple, list, set)) else {str(source)}
            rows = [row for row in rows if row[4] in sources]
        if not rows:
            return []
        current = decimal_value(current)
        distances = [abs(row[0] - current) for row in rows]
        positive = [value for value in distances if value > 0]
        scale = median(positive) if positive else None
        weighted = []
        for row, distance in zip(rows, distances):
            weight = float(row[2])
            if scale is not None:
                ratio = scale / (scale + distance)
                weight *= float(ratio)
            if weight > 0 and math.isfinite(weight):
                weighted.append((row[1], weight))
        return weighted
    @staticmethod
    def _weighted_median(weighted):
        if not weighted:
            return Decimal(0)
        total = sum(weight for _, weight in weighted)
        if total <= 0:
            return median(value for value, _ in weighted)
        ordered = sorted(weighted, key=lambda item: item[0])
        midpoint = total / 2
        running = 0.0
        for value, weight in ordered:
            running += weight
            if running >= midpoint:
                return value
        return ordered[-1][0]
    def _transition_hint(self, state_id, action_id, current):
        data = self._action_data(state_id, action_id)
        if not data or not data.get("transitions"):
            return Decimal(0)
        current = decimal_value(current)
        weighted = []
        for next_state, weight in data["transitions"].items():
            state = self._state_data(next_state)
            if not state:
                continue
            best = state.get("passive", {}).get("best")
            if best is not None and weight > 0:
                weighted.append((best - current, float(weight)))
        return self._weighted_median(weighted)
    def predict_delta(self, state_id, action_id, current):
        return self._weighted_median(self._weighted_rows(state_id, action_id, current, ("direct", "human")))
    def predict_future_gain(self, state_id, action_id, current):
        direct = self.predict_delta(state_id, action_id, current)
        credit = self._weighted_median(self._weighted_rows(state_id, action_id, current, "credit"))
        transition = self._transition_hint(state_id, action_id, current)
        return max(direct, credit, transition)
    def negative_exploration_budget(self, state_id, actions):
        tried = [action for action in actions if self.count(state_id, action.id) > 0]
        total = sum(self.count(state_id, action.id) for action in actions)
        base = exploration_budget(total)
        if not tried:
            return base
        recovered = 0
        for action in tried:
            data = self._action_data(state_id, action.id) or {}
            if any(row[4] == "credit" and row[1] > 0 for row in data.get("samples", ())):
                recovered += 1
        return base + int(round(base * recovered / max(1, len(tried))))
    @staticmethod
    def _action_distance(first, second):
        if first.kind != second.kind:
            return math.inf
        if first.kind == "key":
            return abs(int(first.payload) - int(second.payload))
        if first.kind == "click":
            return math.hypot(float(first.payload[0]) - float(second.payload[0]), float(first.payload[1]) - float(second.payload[1]))
        if first.kind == "scroll":
            return abs(float(first.payload[2]) - float(second.payload[2]))
        return 0.0 if first.id == second.id else math.inf
    def _pick(self, actions):
        if not actions:
            return None
        tier = min(action.tier for action in actions)
        actions = [action for action in actions if action.tier == tier]
        priority = min(action.priority for action in actions)
        actions = [action for action in actions if action.priority == priority]
        return self.rng.choice(actions)
    def choose(self, actions, state_id, current, last_effective=None, best=None, allow_explore=True):
        if not actions:
            return None
        tried = [action for action in actions if self.count(state_id, action.id) > 0]
        promising = []
        for action in tried:
            prediction = self.predict_future_gain(state_id, action.id, current)
            if prediction > 0:
                promising.append((prediction, -self.count(state_id, action.id), -action.priority, action))
        if promising:
            value = max(item[0] for item in promising)
            candidates = [item for item in promising if item[0] == value]
            least = max(item[1] for item in candidates)
            candidates = [item for item in candidates if item[1] == least]
            priority = max(item[2] for item in candidates)
            return self.rng.choice([item[3] for item in candidates if item[2] == priority])
        if not allow_explore:
            return None
        untried = [action for action in actions if self.count(state_id, action.id) == 0]
        if last_effective is not None:
            nearby = [(self._action_distance(action, last_effective), action.tier, action.priority, action) for action in untried]
            nearby = [item for item in nearby if math.isfinite(item[0])]
            if nearby:
                nearest = min((item[0], item[1], item[2]) for item in nearby)
                return self.rng.choice([item[3] for item in nearby if item[:3] == nearest])
        safe = [action for action in untried if action.tier <= 2]
        if safe:
            return self._pick(safe)
        total = sum(self.count(state_id, action.id) for action in actions)
        risky = [action for action in untried if action.tier > 2]
        explored_risky = sum(1 for action in actions if action.tier > 2 and self.count(state_id, action.id) > 0)
        if risky and explored_risky < exploration_budget(total):
            return self._pick(risky)
        return None
    def successful_definitions(self, state_id):
        with self.lock:
            ordered = []
            if state_id in self.states:
                ordered.append(self.states[state_id])
            ordered.extend(state for key, state in self.states.items() if key != state_id)
            result = []
            seen = set()
            for state in ordered:
                for action_id, data in state.get("actions", {}).items():
                    if action_id in seen:
                        continue
                    if not any(row[1] > 0 or row[4] == "credit" and row[1] > 0 for row in data.get("samples", ())):
                        continue
                    definition = data.get("definition")
                    if not isinstance(definition, dict):
                        continue
                    result.append((action_id, dict(definition)))
                    seen.add(action_id)
                    if len(result) >= ACTION_CAPACITY:
                        return result
            return result
    def observe_transition(self, state_id, action_id, before, after, next_state, weight, source="direct", action=None):
        with self.lock:
            try:
                before = decimal_value(before)
                after = decimal_value(after)
                delta = after - before
                weight = float(weight)
            except Exception:
                return
            if not math.isfinite(weight) or weight <= 0:
                return
            data = self._action_data(state_id, action_id, True)
            if action is not None:
                definition = {"kind": action.kind}
                if action.kind == "key":
                    definition["payload"] = int(action.payload)
                elif action.locator is not None:
                    definition["locator"] = decimal_json(action.locator)
                    if action.kind == "scroll":
                        definition["amount"] = int(action.payload[2])
                data["definition"] = definition
            data["trials"] += 1
            self._reservoir_append(data, "samples", [before, delta, weight, str(next_state), str(source)])
            transitions = data["transitions"]
            transitions[str(next_state)] = transitions.get(str(next_state), 0.0) + weight
            if len(transitions) > TRANSITION_CAPACITY:
                keep = dict(sorted(transitions.items(), key=lambda item: item[1], reverse=True)[:TRANSITION_CAPACITY])
                transitions.clear()
                transitions.update(keep)
            self._mark_dirty()
    def assign_credit(self, path, reward, weight):
        with self.lock:
            try:
                reward = decimal_value(reward)
                weight = float(weight)
            except Exception:
                return
            if not path or reward == 0 or not math.isfinite(weight) or weight <= 0:
                return
            for distance, step in enumerate(reversed(path), 1):
                state_id, action_id, before, next_state, step_weight = step
                credit_weight = min(weight, float(step_weight)) / distance
                if credit_weight <= 0:
                    continue
                data = self._action_data(state_id, action_id, True)
                self._reservoir_append(data, "samples", [decimal_value(before), reward / Decimal(distance), credit_weight, str(next_state), "credit"])
                self._mark_dirty()
    def observe_passive(self, state_id, value, weight):
        with self.lock:
            try:
                value = decimal_value(value)
                weight = float(weight)
            except Exception:
                return
            if not math.isfinite(weight) or weight <= 0:
                return
            state = self._state_data(state_id, True)
            passive = state.setdefault("passive", {"seen": 0, "values": [], "best": None})
            passive["seen"] = int(passive.get("seen", 0)) + 1
            values = passive.setdefault("values", [])
            row = [value, weight]
            capacity = SAMPLE_CAPACITY
            if len(values) < capacity:
                values.append(row)
            else:
                index = self.rng.randrange(passive["seen"])
                if index < capacity:
                    values[index] = row
            best = passive.get("best")
            passive["best"] = value if best is None else max(best, value)
            self._mark_dirty()
    def requires_confirmation(self, state_id, delta, confidence=None, minimum_confidence=None):
        if confidence is not None and minimum_confidence is not None and float(confidence) < float(minimum_confidence):
            return True
        try:
            delta = decimal_value(delta)
        except Exception:
            return True
        state = self._state_data(state_id) or {}
        magnitudes = []
        for data in state.get("actions", {}).values():
            for row in data.get("samples", ()):
                if row[4] in {"direct", "human"}:
                    magnitudes.append(abs(row[1]))
        if delta != 0 and not magnitudes:
            return True
        return bool(magnitudes) and abs(delta) > anomaly_magnitude_limit(magnitudes)
    def consolidate(self):
        with self.lock:
            capacity = SAMPLE_CAPACITY
            transition_limit = TRANSITION_CAPACITY
            for state in self.states.values():
                passive = state.get("passive", {})
                if len(passive.get("values", [])) > capacity:
                    passive["values"] = passive["values"][-capacity:]
                    self._mark_dirty()
                actions = state.get("actions", {})
                for data in actions.values():
                    if len(data.get("samples", [])) > capacity:
                        data["samples"] = data["samples"][-capacity:]
                        self._mark_dirty()
                    transitions = data.get("transitions", {})
                    if len(transitions) > transition_limit:
                        data["transitions"] = dict(sorted(transitions.items(), key=lambda item: item[1], reverse=True)[:transition_limit])
                        self._mark_dirty()
                if len(actions) > ACTION_CAPACITY:
                    keep = dict(sorted(actions.items(), key=lambda item: self._action_evidence(item[1]), reverse=True)[:ACTION_CAPACITY])
                    actions.clear()
                    actions.update(keep)
                    self._mark_dirty()
            if len(self.states) > STATE_CAPACITY:
                def evidence(item):
                    state = item[1]
                    trials = sum(int(data.get("trials", 0)) for data in state.get("actions", {}).values())
                    passive = int(state.get("passive", {}).get("seen", 0))
                    return trials + passive
                self.states = dict(sorted(self.states.items(), key=evidence, reverse=True)[:STATE_CAPACITY])
                self._mark_dirty()
    def maybe_save(self, force=False):
        with self.lock:
            if self.path is None or not self.dirty:
                return
            batch = max(32, SAMPLE_CAPACITY)
            interval = float(batch)
            if not force and self.dirty_events < batch and time.monotonic() - self.last_save < interval:
                return
        self.consolidate()
        self.save()
    def save(self):
        with self.lock:
            if self.path is None or not self.dirty:
                return
            with self.FILE_LOCK:
                try:
                    data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.is_file() else {}
                except Exception:
                    data = {}
                targets = data.setdefault("targets", {})
                targets.pop(self.target_key, None)
                targets[self.target_key] = {"states": decimal_json(self.states)}
                while len(targets) > TARGET_CAPACITY:
                    targets.pop(next(iter(targets)))
                self.path.parent.mkdir(parents=True, exist_ok=True)
                temp = self.path.with_suffix(self.path.suffix + ".tmp")
                temp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
                temp.replace(self.path)
            self.dirty = False
            self.dirty_events = 0
            self.last_save = time.monotonic()
class DecisionEngine:
    def __init__(self, app, session_id=None, shutdown=None):
        self.app = app
        self.session_id = session_id
        self.shutdown = shutdown or threading.Event()
        self.revision = app.target_revision
        self.learner = app.learner
        self.response_lags = deque(maxlen=128)
        self.last_text = None
    def snapshot(self):
        return self.app.target_snapshot(self.revision)
    def measure(self, expected=None):
        snapshot = self.snapshot()
        if snapshot is None:
            return None
        image = self.app.reader.capture_client(snapshot["hwnd"])
        if image is None:
            return None
        direct = None
        try:
            direct = self.app.reader.measure_relative(image, snapshot["relative"], expected)
        except Exception as exc:
            self.app.remember_error(exc)
        if direct is not None:
            direct_text = direct.get("text")
            if self.app.reader.direct_trusted(direct, self.last_text):
                self.last_text = direct_text or self.last_text
                self.app.update_target_tracking(self.revision, snapshot["relative"])
                return direct
        locate_expected = direct["value"] if direct is not None else expected
        locate_text = direct.get("text") if direct is not None else self.last_text
        search = snapshot["search"]
        while not self.shutdown.is_set():
            preferred = snapshot["center"]
            try:
                measurement = self.app.reader.locate_number_image(image, search, locate_expected, preferred, locate_text)
            except Exception as exc:
                self.app.remember_error(exc)
                measurement = None
            if measurement is not None:
                relative = measurement.get("box")
                if relative is not None:
                    relative = tuple(max(0.0, min(1.0, float(value))) for value in relative)
                    if relative[2] > relative[0] and relative[3] > relative[1]:
                        self.app.update_target_tracking(self.revision, relative)
                self.last_text = measurement.get("text") or self.last_text
                return measurement
            if direct is not None:
                return direct
            expanded = expand_relative(search)
            if expanded == search:
                break
            if not self.app.update_target_search(self.revision, expanded):
                break
            search = expanded
            snapshot = self.snapshot() or snapshot
        return direct
    def sample_interval(self):
        latency = self.app.reader.typical_latency()
        return max(time.get_clock_info("monotonic").resolution, latency if latency > 0 else time.get_clock_info("monotonic").resolution)
    def stability_span(self):
        values = [value for value in self.response_lags if value > 0 and math.isfinite(value)]
        return max(self.sample_interval(), median(values) if values else 0.0)
    def observation_window(self):
        window = float(user32.GetDoubleClickTime()) / 1000.0
        latency = self.app.reader.typical_latency()
        if latency > 0:
            window += latency
        if self.response_lags:
            window = max(window, max(self.response_lags) + latency)
        return max(self.sample_interval(), window)
    def stable_measure(self, expected=None, deadline=None, track_change_from=None, screen_stable=False, cancellable=True, track_visual_from=None):
        started = time.monotonic()
        if deadline is None:
            deadline = started + self.observation_window()
        last_value = None
        last_format = None
        last_visual = None
        stable_since = None
        consecutive = 0
        first_change = None
        have_sample = False
        while not self.shutdown.is_set() and (not cancellable or not self.app.control_stop.is_set()) and time.monotonic() <= deadline:
            snapshot = self.snapshot()
            if snapshot is None or not user32.IsWindow(snapshot["hwnd"]):
                return None
            measurement = self.measure(expected)
            now = time.monotonic()
            visual = None
            if measurement is not None and screen_stable:
                image = self.app.reader.capture_client(snapshot["hwnd"])
                if image is None:
                    return None
                try:
                    visual = self.app.reader.visual_state_image(image, snapshot["relative"])
                except Exception as exc:
                    self.app.remember_error(exc)
                    visual = None
            if measurement is not None:
                if not have_sample:
                    have_sample = True
                    deadline = max(deadline, now + self.stability_span())
                if track_change_from is not None and first_change is None and measurement["value"] != track_change_from:
                    first_change = now - started
                if track_visual_from is not None and first_change is None and visual is not None and visual != track_visual_from:
                    first_change = now - started
                current_format = (measurement.get("format"), self.app.reader._number_format(measurement.get("text", "")))
                same = last_value is not None and measurement["value"] == last_value and current_format == last_format
                if screen_stable:
                    same = same and visual is not None and last_visual is not None and visual == last_visual
                if same:
                    consecutive += 1
                else:
                    consecutive = 1
                    stable_since = now
                last_value = measurement["value"]
                last_format = current_format
                if screen_stable:
                    last_visual = visual
                floor = self.app.reader.confidence_floor()
                confidence = float(measurement.get("confidence", 0.0))
                confidence_ok = confidence > 0 and (floor is None or confidence >= floor)
                history_ready = floor is not None
                consensus_ok = consecutive >= 2 if not history_ready else stable_since is not None and now - stable_since >= self.stability_span()
                if confidence_ok and consensus_ok:
                    measurement["trusted"] = True
                    measurement["stable_for"] = 0.0 if stable_since is None else now - stable_since
                    self.app.reader.accept_measurement(measurement)
                    if first_change is not None and first_change > 0:
                        self.response_lags.append(first_change)
                    return measurement
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            interval = min(self.sample_interval(), remaining)
            if cancellable:
                self.app.control_stop.event.wait(interval)
            else:
                self.shutdown.wait(interval)
        return None
    def observe_state(self):
        snapshot = self.snapshot()
        if snapshot is None:
            return None
        image = self.app.reader.capture_client(snapshot["hwnd"])
        if image is None:
            return None
        try:
            return self.app.reader.observe_state_image(image, snapshot["relative"])
        except Exception as exc:
            self.app.remember_error(exc)
            return None
    def mouse_action(self, rx, ry, locator, tier=3, priority=0.0, clicks=1):
        digest = hashlib.sha256(json.dumps(locator, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8", "ignore")).hexdigest()
        kind = "double_click" if int(clicks) > 1 else "click"
        return Action(f"{kind}:{digest}", kind, (float(rx), float(ry)), tier, priority, locator)
    @staticmethod
    def semantic_action(label, distance):
        text = unicodedata.normalize("NFKC", str(label)).lower()
        words = set(re.findall(r"[a-z]+", text))
        positive_words = {"add", "plus", "increase", "increment", "upgrade", "up"}
        positive = any(symbol in text for symbol in ("+", "↑", "▲", "△", "增加", "升级", "提升")) or bool(words & positive_words)
        return (1, distance) if positive else (3, 1.0 + distance)
    def box_locator(self, state, index):
        boxes = state.get("boxes", ()) if state is not None else ()
        if index < 0 or index >= len(boxes):
            return None
        rx, ry, width, height, label = boxes[index]
        ordinal = sum(1 for prior in boxes[:index] if str(prior[4]) == str(label))
        snapshot = self.snapshot()
        relation = [0, 0]
        if snapshot is not None:
            tx, ty = snapshot["center"]
            relation = [-1 if float(rx) < tx else 1 if float(rx) > tx else 0, -1 if float(ry) < ty else 1 if float(ry) > ty else 0]
        return {"mode": "ocr", "label": str(label), "ordinal": ordinal, "relation": relation}
    def resolve_locator(self, locator, state):
        snapshot = self.snapshot()
        if snapshot is None or not isinstance(locator, dict):
            return None
        mode = str(locator.get("mode", ""))
        if mode == "target":
            return snapshot["center"]
        if mode == "ocr" and state is not None:
            label = str(locator.get("label", ""))
            try:
                ordinal = max(0, int(locator.get("ordinal", 0)))
            except Exception:
                ordinal = 0
            matches = [(index, box) for index, box in enumerate(state.get("boxes", ())) if str(box[4]) == label]
            if ordinal < len(matches):
                box = matches[ordinal][1]
                return float(box[0]), float(box[1])
        return None
    def learned_actions(self, state):
        if state is None or self.learner is None:
            return []
        result = []
        for action_id, definition in self.learner.successful_definitions(state["id"]):
            kind = str(definition.get("kind", ""))
            if kind == "key":
                try:
                    vk = int(definition.get("payload"))
                except Exception:
                    continue
                if key_capability(vk) is not None:
                    result.append(Action(action_id, "key", vk, 1, 0.0))
                continue
            locator = definition.get("locator")
            point = self.resolve_locator(locator, state)
            if point is None:
                continue
            if kind in {"click", "double_click"}:
                result.append(Action(action_id, kind, point, 1, 0.0, locator))
            elif kind == "scroll":
                amount = WHEEL_DELTA if int(definition.get("amount", WHEEL_DELTA)) > 0 else -WHEEL_DELTA
                result.append(Action(action_id, "scroll", (point[0], point[1], amount), 1, 0.0, locator))
        return result
    def discover_actions(self, state=None):
        snapshot = self.snapshot()
        if snapshot is None:
            return []
        actions = self.learned_actions(state)
        actions.extend(keyboard_actions())
        tx, ty = snapshot["center"]
        target_locator = {"mode": "target"}
        actions.append(self.mouse_action(tx, ty, target_locator, 2, 0.0))
        actions.append(self.mouse_action(tx, ty, target_locator, 4, 1.0, 2))
        boxes = state.get("boxes", ()) if state is not None else ()
        target_scale = max(math.hypot(snapshot["relative"][2] - snapshot["relative"][0], snapshot["relative"][3] - snapshot["relative"][1]), 1e-6)
        for index, (rx, ry, width, height, label) in enumerate(boxes):
            distance = math.hypot(float(rx) - tx, float(ry) - ty) / target_scale
            tier, priority = self.semantic_action(label, distance)
            locator = self.box_locator(state, index)
            if locator is None:
                continue
            actions.append(self.mouse_action(float(rx), float(ry), locator, tier, priority))
            actions.append(self.mouse_action(float(rx), float(ry), locator, max(3, tier + 1), priority + 1.0, 2))
        for rx, ry, width, height, label, locator in child_ui_elements(snapshot["hwnd"]):
            distance = math.hypot(float(rx) - tx, float(ry) - ty) / target_scale
            tier, priority = self.semantic_action(label, distance)
            tier = max(2, tier)
            actions.append(self.mouse_action(float(rx), float(ry), locator, tier, priority))
            actions.append(self.mouse_action(float(rx), float(ry), locator, max(4, tier + 1), priority + 1.0, 2))
        actions.append(Action("scroll:+", "scroll", (tx, ty, WHEEL_DELTA), 2, 2.0, target_locator))
        unique = {}
        for action in sorted(actions, key=lambda item: (item.tier, item.priority, item.id)):
            unique.setdefault(action.id, action)
        return list(unique.values())[:ACTION_CAPACITY]
    def execute(self, action, generation):
        snapshot = self.snapshot()
        if snapshot is None:
            return False
        if action.kind == "key":
            return press_key(int(action.payload), self.app.control_stop, generation, self.app.key_hold)
        client = client_screen_rect(snapshot["hwnd"])
        if client is None:
            return False
        left, top, right, bottom = client
        width = right - left
        height = bottom - top
        if action.kind in {"click", "double_click"}:
            rx, ry = action.payload
            x, y = left + rx * width, top + ry * height
            if action.kind == "click":
                return click_point(x, y, self.app.control_stop, generation)
            if not click_point(x, y, self.app.control_stop, generation):
                return False
            delay = max(time.get_clock_info("monotonic").resolution, float(user32.GetDoubleClickTime()) / 2000.0)
            if self.app.control_stop.event.wait(delay):
                return False
            return click_point(x, y, self.app.control_stop, generation)
        if action.kind == "scroll":
            rx, ry, amount = action.payload
            return scroll_point(left + rx * width, top + ry * height, amount, self.app.control_stop, generation)
        return False
    def observe_after(self, before, before_state):
        deadline = time.monotonic() + self.observation_window()
        return self.stable_measure(before["value"], deadline, before["value"], True, True, before_state.get("visual"))
    @staticmethod
    def append_pending(path, step):
        state_id = step[0]
        for index in range(len(path) - 1, -1, -1):
            if path[index][0] == state_id:
                del path[:index + 1]
                break
        path.append(step)
    def demonstration_action(self, event, state):
        if event is None:
            return None
        _, kind, payload = event
        if kind == "key":
            vk = int(payload)
            return Action(f"key:{vk}", "key", vk, 2, 0.5) if key_capability(vk) is not None else None
        snapshot = self.snapshot()
        client = client_screen_rect(snapshot["hwnd"]) if snapshot is not None else None
        if snapshot is None or client is None:
            return None
        left, top, right, bottom = client
        width = right - left
        height = bottom - top
        if width <= 0 or height <= 0:
            return None
        x, y = float(payload[0]), float(payload[1])
        if not (left <= x < right and top <= y < bottom):
            return None
        rx, ry = (x - left) / width, (y - top) / height
        if kind == "scroll":
            amount = WHEEL_DELTA if int(payload[2]) > 0 else -WHEEL_DELTA
            tx, ty = snapshot["center"]
            locator = {"mode": "target"}
            if math.hypot(rx - tx, ry - ty) <= max(math.hypot(snapshot["relative"][2] - snapshot["relative"][0], snapshot["relative"][3] - snapshot["relative"][1]), 1e-6):
                return Action("scroll:+" if amount > 0 else "scroll:-", "scroll", (tx, ty, amount), 2, 0.5, locator)
            return None
        if kind not in {"click", "double_click"}:
            return None
        tx1, ty1, tx2, ty2 = snapshot["relative"]
        clicks = 2 if kind == "double_click" else 1
        if tx1 <= rx <= tx2 and ty1 <= ry <= ty2:
            return self.mouse_action(rx, ry, {"mode": "target"}, 2, 0.5, clicks)
        best = None
        for index, (bx, by, bw, bh, label) in enumerate(state.get("boxes", ()) if state is not None else ()):
            dx = abs(rx - float(bx)) / max(float(bw), 1.0 / width)
            dy = abs(ry - float(by)) / max(float(bh), 1.0 / height)
            score = dx + dy
            if dx <= 0.75 and dy <= 0.75 and (best is None or score < best[0]):
                best = (score, index, bx, by)
        if best is None:
            return None
        _, index, bx, by = best
        locator = self.box_locator(state, index)
        return self.mouse_action(float(bx), float(by), locator, 2, 0.5, clicks) if locator is not None else None
    def passive_learning(self, current=None, state=None):
        learner = self.learner
        if learner is None:
            return
        generation = -1
        last_visual = None
        interval = self.sample_interval()
        max_interval = max(interval, self.observation_window() * max(2.0, math.sqrt(SAMPLE_CAPACITY)))
        while not self.shutdown.is_set() and not self.app.closing:
            passive_generation, seed = self.app.passive_snapshot()
            if passive_generation != generation:
                generation = passive_generation
                current, state = seed
                last_visual = state.get("visual") if state is not None else None
                interval = self.sample_interval()
            if not self.app.passive_enabled.is_set():
                self.shutdown.wait(self.sample_interval())
                continue
            snapshot = self.snapshot()
            if snapshot is None or not user32.IsWindow(snapshot["hwnd"]):
                break
            if current is None or state is None:
                current = self.stable_measure(cancellable=False)
                state = self.observe_state() if current is not None else None
                if current is not None and state is not None:
                    learner.observe_passive(state["id"], current["value"], current["confidence"])
                    last_visual = state.get("visual")
                self.shutdown.wait(interval)
                continue
            hook = self.app.hook
            demonstration = hook.next_demonstration(0.0) if hook is not None and hook.is_healthy() else None
            if demonstration is not None:
                action = self.demonstration_action(demonstration, state)
                if action is not None:
                    after = self.stable_measure(current["value"], cancellable=False)
                    next_state = self.observe_state() if after is not None else None
                    if after is not None and next_state is not None:
                        weight = min(float(current.get("confidence", 0.0)), float(after.get("confidence", 0.0)))
                        learner.observe_transition(state["id"], action.id, current["value"], after["value"], next_state["id"], weight, "human", action)
                        learner.observe_passive(next_state["id"], after["value"], after["confidence"])
                        current, state = after, next_state
                        last_visual = next_state.get("visual")
                interval = self.sample_interval()
            else:
                image = self.app.reader.capture_client(snapshot["hwnd"])
                visual = None
                if image is not None:
                    try:
                        visual = self.app.reader.visual_state_image(image, snapshot["relative"])
                    except Exception as exc:
                        self.app.remember_error(exc)
                if visual is not None and visual != last_visual:
                    measurement = self.stable_measure(current["value"], cancellable=False)
                    observed = self.observe_state() if measurement is not None else None
                    if measurement is not None and observed is not None:
                        learner.observe_passive(observed["id"], measurement["value"], measurement["confidence"])
                        current, state = measurement, observed
                        last_visual = observed.get("visual")
                    interval = self.sample_interval()
                else:
                    interval = min(max_interval, max(self.sample_interval(), interval * 2))
            try:
                learner.maybe_save()
            except Exception as exc:
                self.app.remember_error(exc)
            self.shutdown.wait(interval)
    def run(self):
        learner = self.learner
        generation = self.app.control_stop.generation
        best = None
        pending = []
        last_effective = None
        negative_streak = 0
        current = None
        state = None
        try:
            current = self.stable_measure()
            state = self.observe_state() if current is not None else None
            if current is None or state is None:
                self.app.control_stop.set("target_read_failed")
            else:
                best = current["value"]
                learner.observe_passive(state["id"], current["value"], current["confidence"])
            while current is not None and state is not None and not self.shutdown.is_set() and not self.app.control_stop.is_set():
                if generation != self.app.control_stop.generation or not self.app.input_ready():
                    break
                state_id = state["id"]
                actions = self.discover_actions(state)
                if not actions:
                    self.app.control_stop.set("input_failed")
                    break
                trials = sum(learner.count(state_id, item.id) for item in actions)
                allow_explore = negative_streak < learner.negative_exploration_budget(state_id, actions)
                action = learner.choose(actions, state_id, current["value"], last_effective, best, allow_explore)
                if action is None:
                    self.app.control_stop.set("no_safe_action")
                    break
                before = current
                before_state = state
                previous_best = best
                if not self.execute(action, generation):
                    if not self.app.control_stop.is_set():
                        self.app.control_stop.set("input_failed")
                    break
                after = self.observe_after(before, before_state)
                if after is None:
                    if not self.app.control_stop.is_set():
                        self.app.control_stop.set("target_read_failed")
                    break
                candidate_delta = after["value"] - before["value"]
                floor = self.app.reader.confirmation_floor()
                if learner.requires_confirmation(before_state["id"], candidate_delta, after.get("confidence"), floor):
                    confirmed = self.stable_measure(after["value"], screen_stable=True)
                    if confirmed is None:
                        if not self.app.control_stop.is_set():
                            self.app.control_stop.set("target_read_failed")
                        break
                    after = confirmed
                next_state = self.observe_state()
                if next_state is None:
                    if not self.app.control_stop.is_set():
                        self.app.control_stop.set("target_read_failed")
                    break
                weight = min(float(before.get("confidence", 0.0)), float(after.get("confidence", 0.0)))
                learner.observe_transition(before_state["id"], action.id, before["value"], after["value"], next_state["id"], weight, action=action)
                learner.observe_passive(next_state["id"], after["value"], weight)
                delta = after["value"] - before["value"]
                best = after["value"] if best is None else max(best, after["value"])
                if previous_best is not None and after["value"] > previous_best:
                    learner.assign_credit(pending, after["value"] - previous_best, weight)
                    pending.clear()
                    last_effective = action
                    negative_streak = 0
                elif delta <= 0 or previous_best is not None and after["value"] <= previous_best:
                    self.append_pending(pending, (before_state["id"], action.id, before["value"], next_state["id"], weight))
                    if delta < 0:
                        negative_streak += 1
                else:
                    negative_streak = 0
                try:
                    learner.maybe_save()
                except Exception as exc:
                    self.app.remember_error(exc)
                current = after
                state = next_state
        except Exception as exc:
            self.app.remember_error(exc)
            if not self.app.control_stop.is_set():
                self.app.control_stop.set("internal_error")
        finally:
            release_all_inputs()
            self.app.set_passive_seed(current, state)
            summary = self.app.stop_summary(best)
            if self.session_id is not None and not self.shutdown.is_set() and not self.app.closing:
                self.app.events.put(("control_stopped", self.session_id, summary))
            try:
                if learner is not None:
                    learner.maybe_save(True)
            except Exception as exc:
                self.app.remember_error(exc)
            release_all_inputs()
            if self.session_id is not None:
                self.app.events.put(("session_finished", self.session_id, summary))
class App:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.data_dir = discover_storage()
        self.runtime_process = {"process": None}
        self.runtime_ready = False
        self.runtime_cuda = False
        self.ImageGrab = None
        self.ImageTk = None
        self.np = None
        self.reader = None
        self.overlay = None
        self.target_lock = threading.RLock()
        self.target_hwnd = 0
        self.target_relative = None
        self.target_center_relative = None
        self.target_search_relative = None
        self.target_revision = 0
        self.target_key = ""
        self.learner = None
        self.key_hold = 0.0
        self.control_stop = ControlStop()
        self.control_stop.set_guard(self.input_guard)
        self.hook = None
        self.worker = None
        self.session_id = 0
        self.session_shutdown = threading.Event()
        self.passive_enabled = threading.Event()
        self.passive_lock = threading.RLock()
        self.passive_generation = 0
        self.passive_seed = (None, None)
        self.passive_thread = None
        self.last_error = ""
        self.closing = False
        self._build_ui()
        self.root.after_idle(self.initialize)
        self.root.after(UI_POLL_MS, self.poll)
    def remember_error(self, exc):
        if exc is None:
            return
        self.last_error = f"{type(exc).__name__}: {exc}".strip()
    def stop_summary(self, best=None):
        message = self.control_stop.message()
        if self.control_stop.reason in {"target_read_failed", "internal_error"} and self.last_error:
            message += f"；{self.last_error}"
        if best is not None:
            message += f"；本次最高值 {best:g}"
        return message
    def show_main(self):
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after_idle(lambda: self.root.attributes("-topmost", False))
    def set_passive_seed(self, current, state):
        with self.passive_lock:
            self.passive_seed = (current, state)
            self.passive_generation += 1
    def set_passive(self, enabled, current=None, state=None):
        with self.passive_lock:
            if current is not None or state is not None:
                self.passive_seed = (current, state)
            self.passive_generation += 1
            if enabled:
                self.passive_enabled.set()
            else:
                self.passive_enabled.clear()
    def passive_snapshot(self):
        with self.passive_lock:
            return self.passive_generation, self.passive_seed
    def start_learning_session(self, measurement, state):
        self.session_shutdown = threading.Event()
        path = self.data_dir / LEARNING_NAME if self.data_dir is not None else None
        self.learner = OnlineLearner(path, self.target_key)
        self.set_passive(True, measurement, state)
        if self.hook:
            self.hook.close()
        self.hook = UserInputStopHook(self.control_stop, self.events, self.session_id, self.target_hwnd)
        if self.hook.start():
            self.hook.begin_passive_phase()
        else:
            self.hook.close()
            self.hook = None
        engine = DecisionEngine(self, None, self.session_shutdown)
        self.passive_thread = threading.Thread(target=engine.passive_learning, args=(measurement, state), name="learning", daemon=True)
        self.passive_thread.start()
    def _build_ui(self):
        self.root.title(APP_NAME)
        self.root.resizable(False, False)
        frame = ttk.Frame(self.root, padding=16)
        frame.grid(row=0, column=0, sticky="nsew")
        self.status = tk.StringVar(value="正在初始化……")
        ttk.Label(frame, textvariable=self.status, width=48, anchor="center").grid(row=0, column=0, columnspan=2, pady=(0, 12))
        self.value_button = ttk.Button(frame, text="数值", command=self.select_value, state="disabled")
        self.value_button.grid(row=1, column=0, padx=(0, 8), sticky="ew")
        self.confirm_button = ttk.Button(frame, text="确认", command=self.start_ai, state="disabled")
        self.confirm_button.grid(row=1, column=1, padx=(8, 0), sticky="ew")
        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
    def initialize(self):
        self.value_button.configure(state="disabled")
        self.status.set("正在检测运行环境……")
        threading.Thread(target=probe_runtime, args=(self.events,), name="runtime-probe", daemon=True).start()
    def ensure_data_dir(self):
        if self.data_dir is not None and storage_writable(self.data_dir):
            return self.data_dir
        self.data_dir = None
        data_dir = choose_storage(self.root)
        if data_dir is None:
            return None
        try:
            storage_environment(data_dir)
        except OSError:
            return None
        self.data_dir = data_dir
        remember_storage(data_dir)
        return data_dir
    def set_target(self, hwnd, relative):
        with self.target_lock:
            self.target_hwnd = int(hwnd)
            self.target_relative = tuple(map(float, relative))
            self.target_center_relative = relative_center(self.target_relative)
            self.target_search_relative = expand_relative(self.target_relative)
            self.target_revision += 1
            return self.target_revision
    def target_snapshot(self, revision=None):
        with self.target_lock:
            if revision is not None and revision != self.target_revision:
                return None
            if not self.target_hwnd or self.target_relative is None or self.target_center_relative is None or self.target_search_relative is None:
                return None
            return {"hwnd": int(self.target_hwnd), "relative": tuple(self.target_relative), "center": tuple(self.target_center_relative), "search": tuple(self.target_search_relative), "revision": self.target_revision}
    def update_target_tracking(self, revision, relative):
        with self.target_lock:
            if revision != self.target_revision:
                return False
            relative = tuple(map(float, relative))
            self.target_relative = relative
            self.target_center_relative = relative_center(relative)
            self.target_search_relative = expand_relative(relative)
            return True
    def update_target_search(self, revision, search):
        with self.target_lock:
            if revision != self.target_revision or self.target_search_relative is None:
                return False
            self.target_search_relative = relative_union(self.target_search_relative, tuple(map(float, search)))
            return True
    def end_learning_session(self):
        self.set_passive(False)
        self.session_shutdown.set()
        if self.learner is not None:
            try:
                self.learner.maybe_save(True)
            except Exception as exc:
                self.remember_error(exc)
        if self.hook:
            self.hook.close()
            self.hook = None
        release_all_inputs()
    def select_value(self):
        if not self.runtime_ready:
            self.initialize()
            return
        if self.worker and self.worker.is_alive():
            return
        self.end_learning_session()
        self.confirm_button.configure(state="disabled")
        self.status.set("请在屏幕上拖框选中目标数值")
        self.root.withdraw()
        try:
            screen = virtual_screen_rect()
            screenshot = self.ImageGrab.grab(all_screens=True)
            self.overlay = SelectionOverlay(self.root, self.ImageTk, screenshot, screen, self.selection_done)
        except Exception as exc:
            self.show_main()
            self.remember_error(exc)
            self.status.set(f"无法截取屏幕：{exc}")
    def selection_done(self, rect):
        self.overlay = None
        if rect is None:
            self.show_main()
            self.status.set("未选择数值")
            return
        center_x = (rect[0] + rect[2]) / 2
        center_y = (rect[1] + rect[3]) / 2
        hwnd = top_level_window_at(center_x, center_y)
        client = client_screen_rect(hwnd)
        if not hwnd or client is None:
            self.show_main()
            self.status.set("未找到目标窗口，请重新选择")
            return
        left, top, right, bottom = client
        x1 = max(left, rect[0])
        y1 = max(top, rect[1])
        x2 = min(right, rect[2])
        y2 = min(bottom, rect[3])
        if x2 <= x1 or y2 <= y1:
            self.show_main()
            self.status.set("选择区域不在目标窗口内，请重新选择")
            return
        width = right - left
        height = bottom - top
        relative = ((x1 - left) / width, (y1 - top) / height, (x2 - left) / width, (y2 - top) / height)
        self.set_target(hwnd, relative)
        self.target_key = ""
        self.show_main()
        self.status.set("正在读取所选数值……")
        threading.Thread(target=self.recognize_selection, daemon=True).start()
    def recognize_selection(self):
        engine = DecisionEngine(self)
        measurement = engine.stable_measure(cancellable=False)
        if measurement is None:
            self.events.put(("selection_error", "无法识别所选区域中的数值，请重新选择"))
            return
        snapshot = self.target_snapshot()
        observed = engine.observe_state()
        context = observed.get("structure", "") if observed is not None else measurement.get("text", "")
        target_key = target_identity(snapshot["hwnd"], snapshot["relative"], context) if snapshot is not None else ""
        self.events.put(("selection_ready", measurement, target_key, observed))
    def start_ai(self):
        snapshot = self.target_snapshot()
        if not self.runtime_ready or snapshot is None:
            return
        if self.worker and self.worker.is_alive():
            return
        if self.learner is None or self.learner.target_key != self.target_key:
            path = self.data_dir / LEARNING_NAME if self.data_dir is not None else None
            self.learner = OnlineLearner(path, self.target_key)
        self.session_id += 1
        self.last_error = ""
        self.set_passive(False)
        renew_input_magic()
        release_all_inputs()
        self.control_stop.clear()
        self.control_stop.set_guard(self.input_guard)
        if self.hook is None or not self.hook.is_healthy():
            if self.hook:
                self.hook.close()
            self.hook = UserInputStopHook(self.control_stop, self.events, self.session_id, self.target_hwnd)
            if not self.hook.start():
                self.hook.close()
                self.hook = None
                self.set_passive(True)
                messagebox.showerror(APP_NAME, "无法启用键盘/鼠标用户接管监控，因此未启动 AI。", parent=self.root)
                return
        self.hook.session_id = self.session_id
        self.hook.target_hwnd = int(self.target_hwnd)
        self.value_button.configure(state="disabled")
        self.confirm_button.configure(state="disabled")
        self.status.set("正在等待当前物理键鼠完全释放……")
        self.hook.begin_takeover_phase()
        self.root.withdraw()
        self.wait_for_arm()
    def wait_for_arm(self):
        if self.closing or self.session_shutdown.is_set() or self.control_stop.is_set():
            return
        if self.hook is None or not self.hook.is_healthy():
            self.control_stop.set("input_hook_lost")
            self.finish_ai_start_failure(self.control_stop.message())
            return
        if not self.hook.try_arm():
            delay = max(1, int(round(self.hook.quiet_seconds() * 1000)))
            self.root.after(delay, self.wait_for_arm)
            return
        try:
            user32.SetForegroundWindow(self.target_hwnd)
        except Exception:
            pass
        if not self.target_ready():
            self.control_stop.set("target_changed")
            self.finish_ai_start_failure("目标窗口不可用，请重新选择数值")
            return
        self.key_hold = measure_key_hold()
        self.status.set("AI 已开启")
        engine = DecisionEngine(self, self.session_id, self.session_shutdown)
        self.worker = threading.Thread(target=engine.run, name="decision", daemon=True)
        self.worker.start()
    def finish_ai_start_failure(self, message):
        release_all_inputs()
        if self.hook and self.hook.is_healthy():
            self.hook.begin_passive_phase()
        self.set_passive(True)
        self.show_main()
        self.status.set(message)
        self.value_button.configure(state="normal")
        self.confirm_button.configure(state="normal" if self.target_hwnd else "disabled")
    def target_ready(self):
        if not self.target_hwnd or not user32.IsWindow(self.target_hwnd):
            return False
        return foreground_root() == int(self.target_hwnd)
    def input_ready(self):
        if self.control_stop.is_set() or self.session_shutdown.is_set():
            return False
        if self.hook is None or not self.hook.is_healthy():
            self.control_stop.set("input_hook_lost")
            return False
        if not self.target_ready():
            self.control_stop.set("target_changed")
            return False
        return True
    def input_guard(self, kind, point):
        if not self.input_ready():
            return False
        if kind == "pointer":
            rect = client_screen_rect(self.target_hwnd)
            if rect is None or point is None:
                self.control_stop.set("target_changed")
                return False
            x, y = point
            if not (rect[0] <= x < rect[2] and rect[1] <= y < rect[3]):
                self.control_stop.set("target_changed")
                return False
        return True
    def show_control_stopped(self, message):
        if self.hook and not self.hook.is_healthy():
            self.hook.close()
            self.hook = None
        elif self.hook:
            self.hook.begin_passive_phase()
        if self.worker is None or not self.worker.is_alive():
            self.set_passive(True)
        self.show_main()
        self.status.set(message)
        self.value_button.configure(state="normal")
        self.confirm_button.configure(state="disabled" if self.worker and self.worker.is_alive() else "normal" if self.target_hwnd else "disabled")
    def poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "runtime_status":
                    self.status.set(event[1])
                elif kind == "runtime_needs_storage":
                    data_dir = self.ensure_data_dir()
                    if data_dir is None:
                        self.status.set("缺少运行依赖，需要非系统盘数据目录才能安装；点击“数值”可重试")
                        self.value_button.configure(state="normal")
                    else:
                        threading.Thread(target=ensure_runtime, args=(data_dir, self.events, self.runtime_process), name="runtime", daemon=True).start()
                elif kind == "runtime_probe_ready":
                    cuda, models_ready, nvidia = bool(event[1]), bool(event[2]), bool(event[3])
                    if models_ready:
                        threading.Thread(target=initialize_runtime, args=(None, self.events), name="ocr-init", daemon=True).start()
                    else:
                        data_dir = self.ensure_data_dir()
                        if data_dir is None:
                            self.status.set("OCR 模型需要写入文件，请选择非系统盘目录后重试")
                            self.value_button.configure(state="normal")
                        elif nvidia and not cuda:
                            threading.Thread(target=ensure_runtime, args=(data_dir, self.events, self.runtime_process), name="runtime", daemon=True).start()
                        else:
                            threading.Thread(target=initialize_runtime, args=(data_dir, self.events), name="ocr-init", daemon=True).start()
                elif kind == "runtime_ready":
                    self.ImageGrab, self.ImageTk, self.np, engine, self.runtime_cuda = event[1]
                    try:
                        self.reader = OCRReader(self.ImageGrab, self.np, engine)
                        self.runtime_ready = True
                        self.status.set("请选择数值")
                        self.value_button.configure(state="normal")
                    except Exception as exc:
                        self.runtime_ready = False
                        self.status.set(f"OCR 初始化失败：{exc}；点击“数值”可重试")
                        self.value_button.configure(state="normal")
                elif kind == "runtime_error":
                    self.runtime_ready = False
                    self.status.set(event[1] + "；点击“数值”可重试")
                    self.value_button.configure(state="normal")
                    messagebox.showerror(APP_NAME, event[1], parent=self.root)
                elif kind == "selection_ready":
                    measurement = event[1]
                    self.target_key = event[2]
                    observed = event[3] if len(event) > 3 else None
                    self.start_learning_session(measurement, observed)
                    self.status.set(f"已选择：{measurement['value']:g}")
                    self.confirm_button.configure(state="normal")
                    self.value_button.configure(state="normal")
                elif kind == "selection_error":
                    self.status.set(event[1])
                    self.value_button.configure(state="normal")
                    self.confirm_button.configure(state="disabled")
                elif kind == "user_takeover":
                    session_id = event[1]
                    if session_id == self.session_id and not self.closing:
                        self.show_control_stopped(event[2])
                elif kind == "control_stopped":
                    session_id = event[1]
                    if session_id == self.session_id and not self.closing:
                        self.show_control_stopped(event[2])
                elif kind == "session_finished":
                    session_id = event[1]
                    if session_id == self.session_id:
                        self.worker = None
                        if self.hook and self.hook.is_healthy():
                            self.hook.begin_passive_phase()
                        self.set_passive(True)
                        self.confirm_button.configure(state="normal" if self.target_hwnd else "disabled")
        except queue.Empty:
            pass
        if not self.closing:
            self.root.after(UI_POLL_MS, self.poll)
    def close(self):
        if self.closing:
            return
        self.closing = True
        self.session_shutdown.set()
        self.control_stop.set("closed")
        release_all_inputs()
        if self.learner:
            try:
                self.learner.maybe_save(True)
            except Exception as exc:
                self.remember_error(exc)
        if self.hook:
            self.hook.close()
            self.hook = None
        process = self.runtime_process.get("process")
        if process is not None and process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
        try:
            self.root.destroy()
        except tk.TclError:
            pass
def main():
    if os.name != "nt" or sys.maxsize <= 2 ** 32:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, "本程序需要 64 位 Windows。")
        root.destroy()
        return
    configure_windows()
    root = tk.Tk()
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    App(root)
    root.mainloop()
if __name__ == "__main__":
    main()
