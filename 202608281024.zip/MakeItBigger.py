import sys
sys.dont_write_bytecode = True

import os
import math
import time
import json
import random
import re
import threading
import subprocess
import queue
import locale
from collections import deque
import colorsys
import hashlib
import shutil
import logging
from logging.handlers import RotatingFileHandler
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path


import ctypes
from ctypes import wintypes
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

ULONG_PTR = ctypes.c_size_t
LRESULT = ctypes.c_ssize_t
INPUT_TAG = 0x4D4942472026
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_XDOWN = 0x0080
MOUSEEVENTF_XUP = 0x0100
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_HWHEEL = 0x01000
MOUSEEVENTF_VIRTUALDESK = 0x4000
MOUSEEVENTF_ABSOLUTE = 0x8000
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
KEYEVENTF_SCANCODE = 0x0008
MOUSEEVENTF_MOVE_NOCOALESCE = 0x2000
WH_KEYBOARD_LL = 13
WH_MOUSE_LL = 14
WM_QUIT = 0x0012
GA_ROOT = 2

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", INPUTUNION)]

class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("pt", wintypes.POINT), ("mouseData", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class GUITHREADINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
        ("hwndActive", wintypes.HWND), ("hwndFocus", wintypes.HWND),
        ("hwndCapture", wintypes.HWND), ("hwndMenuOwner", wintypes.HWND),
        ("hwndMoveSize", wintypes.HWND), ("hwndCaret", wintypes.HWND),
        ("rcCaret", wintypes.RECT),
    ]

HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
kernel32.GetModuleHandleW.argtypes = (wintypes.LPCWSTR,)
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
user32.SendInput.argtypes = (wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int)
user32.SendInput.restype = wintypes.UINT
user32.GetForegroundWindow.restype = wintypes.HWND
user32.WindowFromPoint.argtypes = (wintypes.POINT,)
user32.WindowFromPoint.restype = wintypes.HWND
user32.GetAncestor.argtypes = (wintypes.HWND, wintypes.UINT)
user32.GetAncestor.restype = wintypes.HWND
user32.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
user32.GetClassNameW.restype = ctypes.c_int
user32.GetWindowTextLengthW.argtypes = (wintypes.HWND,)
user32.GetWindowTextLengthW.restype = ctypes.c_int
user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
user32.GetWindowTextW.restype = ctypes.c_int
user32.SetWindowsHookExW.argtypes = (ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD)
user32.SetWindowsHookExW.restype = wintypes.HHOOK
user32.CallNextHookEx.argtypes = (wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
user32.CallNextHookEx.restype = LRESULT
user32.UnhookWindowsHookEx.argtypes = (wintypes.HHOOK,)
user32.UnhookWindowsHookEx.restype = wintypes.BOOL
user32.PostThreadMessageW.argtypes = (wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
user32.PostThreadMessageW.restype = wintypes.BOOL
user32.SetWindowPos.argtypes = (wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT)
user32.SetWindowPos.restype = wintypes.BOOL
user32.GetWindowRect.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
user32.GetWindowRect.restype = wintypes.BOOL
user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
user32.GetWindowThreadProcessId.restype = wintypes.DWORD
user32.GetGUIThreadInfo.argtypes = (wintypes.DWORD, ctypes.POINTER(GUITHREADINFO))
user32.GetGUIThreadInfo.restype = wintypes.BOOL
user32.ClientToScreen.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.POINT))
user32.ClientToScreen.restype = wintypes.BOOL
try:
    user32.GetDpiForWindow.argtypes = (wintypes.HWND,)
    user32.GetDpiForWindow.restype = wintypes.UINT
except Exception:
    pass

class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]

kernel32.GlobalMemoryStatusEx.argtypes = (ctypes.POINTER(MEMORYSTATUSEX),)
kernel32.GlobalMemoryStatusEx.restype = wintypes.BOOL

class FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", wintypes.DWORD), ("dwHighDateTime", wintypes.DWORD)]

kernel32.GetSystemTimes.argtypes = (ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME))
kernel32.GetSystemTimes.restype = wintypes.BOOL
try:
    kernel32.GetActiveProcessorCount.argtypes = (wintypes.WORD,)
    kernel32.GetActiveProcessorCount.restype = wintypes.DWORD
except Exception:
    pass
try:
    user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
except Exception:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass

SW_HIDE = 0
HWND_TOPMOST = wintypes.HWND(-1)
SWP_NOACTIVATE = 0x0010
SWP_SHOWWINDOW = 0x0040
SYSTEM_DRIVE = os.environ.get("SystemDrive", "C:").upper().rstrip("\\/")

root = None
chosen_path = None
app_dir = None
deps_dir = None
temp_dir = None
phase_var = None
status_var = None
detail_var = None
progress_var = None
status = None
detail_label = None
progress = None
number_button = None
free_button = None
hardware_var = None
learning_var = None
hardware_profile = None
runtime_logger = None
ui_queue = queue.Queue()
_cpu_sample_lock = threading.Lock()
_cpu_times_sample = None

app_alive = threading.Event()
app_alive.set()
shutdown_event = threading.Event()
shutdown_started = False
shutdown_lock = threading.Lock()
bootstrap_thread = None
hardware_thread = None
hook_thread = None
scan_thread = None

child_processes = set()
child_process_lock = threading.Lock()
child_job_lock = threading.Lock()
child_job = None
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS = 9


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_longlong),
        ("PerJobUserTimeLimit", ctypes.c_longlong),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ULONG_PTR),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_ulonglong),
        ("WriteOperationCount", ctypes.c_ulonglong),
        ("OtherOperationCount", ctypes.c_ulonglong),
        ("ReadTransferCount", ctypes.c_ulonglong),
        ("WriteTransferCount", ctypes.c_ulonglong),
        ("OtherTransferCount", ctypes.c_ulonglong),
    ]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


try:
    kernel32.CreateJobObjectW.argtypes = (ctypes.c_void_p, wintypes.LPCWSTR)
    kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    kernel32.SetInformationJobObject.argtypes = (wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD)
    kernel32.SetInformationJobObject.restype = wintypes.BOOL
    kernel32.AssignProcessToJobObject.argtypes = (wintypes.HANDLE, wintypes.HANDLE)
    kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
except Exception:
    pass


def _shutdown_requested():
    return shutdown_event.is_set() or not app_alive.is_set()


def _ensure_child_job():
    global child_job
    if shutdown_event.is_set():
        return None
    if child_job is not None:
        return child_job
    with child_job_lock:
        if child_job is not None:
            return child_job
        try:
            job = kernel32.CreateJobObjectW(None, None)
            if not job:
                return None
            info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
            info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            if not kernel32.SetInformationJobObject(
                job, JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS, ctypes.byref(info), ctypes.sizeof(info)
            ):
                kernel32.CloseHandle(job)
                return None
            child_job = job
        except Exception:
            child_job = None
        return child_job


def _assign_child_to_job(proc):
    job = _ensure_child_job()
    if job is None:
        return
    try:
        handle = getattr(proc, "_handle", None)
        if handle:
            kernel32.AssignProcessToJobObject(job, wintypes.HANDLE(handle))
    except Exception:
        pass


def _terminate_process(proc):
    if proc is None or proc.poll() is not None:
        return
    try:
        proc.terminate()
    except Exception:
        pass
    try:
        proc.wait(timeout=0.8)
        return
    except Exception:
        pass
    try:
        proc.kill()
    except Exception:
        pass
    try:
        proc.wait(timeout=0.5)
    except Exception:
        pass


def terminate_child_processes():
    global child_job
    with child_job_lock:
        job = child_job
        child_job = None
    if job is not None:
        try:
            kernel32.CloseHandle(job)
        except Exception:
            pass
    with child_process_lock:
        processes = list(child_processes)
    for proc in processes:
        _terminate_process(proc)


def run_child(cmd, timeout=None, **kwargs):
    if _shutdown_requested():
        return None
    proc = subprocess.Popen(cmd, **kwargs)
    with child_process_lock:
        child_processes.add(proc)
    if shutdown_event.is_set():
        _terminate_process(proc)
        with child_process_lock:
            child_processes.discard(proc)
        return None
    _assign_child_to_job(proc)
    started = time.monotonic()
    try:
        while proc.poll() is None:
            if shutdown_event.wait(0.10):
                _terminate_process(proc)
                return None
            if timeout is not None and time.monotonic() - started >= float(timeout):
                _terminate_process(proc)
                return None
        stdout, stderr = proc.communicate()
        return subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)
    finally:
        with child_process_lock:
            child_processes.discard(proc)


def _clamp(value, low, high):
    return max(low, min(high, value))


def _filetime_value(value):
    return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)


def _sample_cpu_utilization():
    global _cpu_times_sample
    idle = FILETIME(); kernel = FILETIME(); user = FILETIME()
    if not kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
        return 0.0
    sample = (_filetime_value(idle), _filetime_value(kernel), _filetime_value(user))
    with _cpu_sample_lock:
        previous = _cpu_times_sample
        _cpu_times_sample = sample
    if previous is None:
        return 0.0
    idle_delta = max(0, sample[0] - previous[0])
    total_delta = max(1, (sample[1] - previous[1]) + (sample[2] - previous[2]))
    busy = max(0, total_delta - idle_delta)
    return _clamp(busy * 100.0 / total_delta, 0.0, 100.0)


def _detect_hardware_profile():
    cpu_count = max(1, int(os.cpu_count() or 1))
    try:
        cpu_count = max(cpu_count, int(kernel32.GetActiveProcessorCount(0xFFFF)))
    except Exception:
        pass
    cpu_util = _sample_cpu_utilization()
    memory = MEMORYSTATUSEX()
    memory.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
    if kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
        ram_total = max(1, int(memory.ullTotalPhys))
        ram_free = max(0, int(memory.ullAvailPhys))
    else:
        ram_total = 8 << 30
        ram_free = ram_total // 2
    usage = shutil.disk_usage(chosen_path)
    screen_pixels = max(1, int(user32.GetSystemMetrics(78))) * max(1, int(user32.GetSystemMetrics(79)))

    gpu_total_mib = 0.0
    gpu_free_mib = 0.0
    gpu_util = 0.0
    gpu_name = "NVIDIA"
    candidates = []
    discovered = shutil.which("nvidia-smi")
    if discovered:
        candidates.append(discovered)
    program_files = os.environ.get("ProgramFiles")
    if program_files:
        candidates.append(str(Path(program_files) / "NVIDIA Corporation" / "NVSMI" / "nvidia-smi.exe"))
    for executable in candidates:
        try:
            if not Path(executable).exists():
                continue
            result = run_child(
                [executable, "--query-gpu=name,memory.total,memory.free,utilization.gpu", "--format=csv,noheader,nounits"],
                cwd=str(app_dir), env=os.environ.copy(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                timeout=max(2.0, math.log2(cpu_count + 1.0)),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if result is None or result.returncode != 0:
                continue
            rows = [row.strip() for row in result.stdout.splitlines() if row.strip()]
            parsed = []
            for row in rows:
                parts = [part.strip() for part in row.split(",")]
                if len(parts) < 4:
                    continue
                parsed.append((parts[0], float(parts[1]), float(parts[2]), float(parts[3])))
            if parsed:
                gpu_name, gpu_total_mib, gpu_free_mib, gpu_util = max(parsed, key=lambda item: item[1])
                break
        except Exception:
            continue

    ram_gib = ram_total / float(1 << 30)
    cpu_factor = math.log2(cpu_count + 1.0)
    ram_factor = math.log2(ram_gib + 2.0)
    ram_headroom = _clamp(ram_free / float(max(1, ram_total)), 0.05, 1.0)
    disk_headroom = _clamp(usage.free / float(max(1, usage.total)), 0.01, 1.0)
    cpu_headroom = 1.0 - _clamp(cpu_util / 100.0, 0.0, 0.95)
    gpu_headroom = (gpu_free_mib / gpu_total_mib) if gpu_total_mib > 0 else 0.5
    gpu_headroom = _clamp(gpu_headroom, 0.05, 1.0)
    gpu_idle = 1.0 - _clamp(gpu_util / 100.0, 0.0, 0.95)
    base_capacity = math.sqrt(cpu_factor * ram_factor)
    pressure_factor = _clamp(0.52 + 0.48 * math.sqrt(cpu_headroom * ram_headroom), 0.52, 1.0)
    display_factor = _clamp(0.86 + 0.14 * math.sqrt(gpu_headroom * gpu_idle), 0.86, 1.0)
    capacity = base_capacity * pressure_factor
    cv_fraction = _clamp((0.24 + 0.12 * capacity) * (0.65 + 0.35 * cpu_headroom), 1.0 / cpu_count, 0.92)
    cv_threads = int(round(_clamp(cpu_count * cv_fraction, 1.0, float(cpu_count))))
    coarse_ratio = _clamp(0.20 + 0.085 * capacity * display_factor + 0.12 * ram_headroom, 0.26, 0.80)
    coarse_pixel_budget = max(640 * 360, int(screen_pixels * coarse_ratio))
    tile_pixel_budget = max(900 * 600, int(coarse_pixel_budget * _clamp(0.50 + 0.09 * cpu_factor * pressure_factor, 0.60, 1.20)))
    scan_frames = int(_clamp(round(1.0 + capacity * 0.60 * display_factor), 2, 4))
    scale_spread = _clamp(0.11 + 0.03 * capacity * pressure_factor, 0.13, 0.25)
    scan_scales = (1.0, 1.0 - scale_spread, 1.0 + scale_spread)
    scan_deadline = _clamp(5.0 + math.sqrt(screen_pixels / max(1.0, coarse_pixel_budget)) * (4.0 + 2.5 / max(0.52, pressure_factor)), 7.0, 22.0)
    training_epochs = int(_clamp(round(17 + capacity * 4.5), 20, 44))
    training_batch = int(_clamp(round(28 * max(2.0, cpu_factor) * _clamp((ram_gib * ram_headroom) / 6.0, 0.65, 3.0)), 48, 384))
    save_interval = _clamp(28.0 + (1.0 - disk_headroom) * 38.0 + (1.0 - ram_headroom) * 12.0, 28.0, 78.0)
    recent_window = int(_clamp(round(22 + capacity * (7.0 + 5.0 * ram_headroom)), 28, 112))
    return {
        "cpu_count": cpu_count, "cpu_util": cpu_util, "cpu_headroom": cpu_headroom,
        "ram_total": ram_total, "ram_free": ram_free, "ram_headroom": ram_headroom,
        "disk_total": usage.total, "disk_free": usage.free, "disk_headroom": disk_headroom,
        "gpu_name": gpu_name, "gpu_total_mib": gpu_total_mib, "gpu_free_mib": gpu_free_mib,
        "gpu_util": gpu_util, "gpu_headroom": gpu_headroom,
        "screen_pixels": screen_pixels, "capacity": capacity, "cv_threads": cv_threads,
        "coarse_pixel_budget": coarse_pixel_budget, "tile_pixel_budget": tile_pixel_budget,
        "scan_frames": scan_frames, "scan_scales": scan_scales, "scan_deadline": scan_deadline,
        "training_epochs": training_epochs, "training_batch": training_batch,
        "save_interval": save_interval, "recent_window": recent_window,
    }


def _format_gain(value):
    try:
        number = float(value)
        if abs(number - round(number)) < 1e-9:
            return f"+{int(round(number))}"
        return f"+{number:.2f}".rstrip("0").rstrip(".")
    except Exception:
        return "+0"


def _refresh_info_vars():
    if hardware_var is not None:
        profile = hardware_profile or {}
        gpu_name = str(profile.get("gpu_name") or "NVIDIA")
        gpu_util = float(profile.get("gpu_util", 0.0) or 0.0)
        hook_state = "正常" if controller is not None and controller.input_hooks_ready.is_set() else "准备中"
        monitor_state = "监控暂不可用" if profile.get("monitor_unavailable") else f"利用率 {gpu_util:.0f}%"
        hardware_var.set(f"硬件监控 GPU  {gpu_name}  ·  {monitor_state}  ·  输入监听 {hook_state}")
    if learning_var is not None:
        state = getattr(controller, "state", None) if controller is not None else None
        if not isinstance(state, dict):
            state = {}
        trials = max(0, int(state.get("trials", 0) or 0))
        successes = max(0, int(state.get("successes", 0) or 0))
        unknowns = max(0, int(state.get("unknowns", 0) or 0))
        best_gain = _format_gain(state.get("best_gain", 0.0))
        learning_var.set(f"学习 {trials} 次  ·  成功 {successes} 次  ·  待确认 {unknowns} 次  ·  最佳提升 {best_gain}")


def _apply_progress(payload):
    if not isinstance(payload, dict):
        return
    if phase_var is not None and "phase" in payload:
        phase_var.set(str(payload.get("phase") or ""))
    if status_var is not None and "text" in payload:
        status_var.set(str(payload.get("text") or ""))
    if detail_var is not None and "detail" in payload:
        detail_var.set(str(payload.get("detail") or ""))
    if progress is None or progress_var is None:
        return
    mode = str(payload.get("mode") or "determinate")
    try:
        progress.stop()
    except Exception:
        pass
    if mode == "indeterminate":
        progress.configure(mode="indeterminate")
        progress.start(12)
    else:
        progress.configure(mode="determinate", maximum=100)
        progress_var.set(float(payload.get("value", progress_var.get())))


def set_progress(value, text, detail="", phase="正在准备", mode="determinate"):
    post_ui("progress", {
        "value": float(value),
        "text": str(text),
        "detail": str(detail),
        "phase": str(phase),
        "mode": str(mode),
    })


def _hardware_monitor_loop():
    global hardware_profile
    while app_alive.is_set() and not shutdown_event.is_set():
        if shutdown_event.wait(45.0):
            return
        if not app_alive.is_set():
            return
        try:
            profile = _detect_hardware_profile()
            if _shutdown_requested():
                return
            hardware_profile = profile
            post_ui("metrics")
        except Exception as exc:
            if _shutdown_requested():
                return
            profile = dict(hardware_profile or {})
            profile["monitor_unavailable"] = True
            hardware_profile = profile
            _log_runtime("warning", f"hardware monitor unavailable: {exc}")
            post_ui("metrics")
            continue


def _init_runtime_logging():
    global runtime_logger
    if app_dir is None:
        return
    logger = logging.getLogger("MakeItBigger")
    logger.setLevel(logging.INFO)
    logger.propagate = False
    for handler in list(logger.handlers):
        try:
            handler.close()
        except Exception:
            pass
        logger.removeHandler(handler)
    try:
        handler = RotatingFileHandler(
            app_dir / "runtime.log", maxBytes=2 * 1024 * 1024, backupCount=1, encoding="utf-8"
        )
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        runtime_logger = logger
        logger.info("MakeItBigger started; runtime data directory initialized")
    except Exception:
        runtime_logger = None


def _log_runtime(level, message):
    logger = runtime_logger
    if logger is None:
        return
    try:
        getattr(logger, str(level), logger.info)(str(message))
    except Exception:
        pass


def post_ui(kind, payload=None):
    if shutdown_event.is_set():
        return
    ui_queue.put((str(kind), payload))


def drain_ui_queue():
    if root is None or shutdown_event.is_set():
        return
    try:
        while True:
            try:
                kind, payload = ui_queue.get_nowait()
            except queue.Empty:
                break
            if kind == "status":
                if status_var is not None:
                    status_var.set(str(payload))
            elif kind == "progress":
                _apply_progress(payload)
            elif kind == "metrics":
                _refresh_info_vars()
            elif kind == "dependency_failed":
                dependency_failed(str(payload))
            elif kind == "enable_controls":
                enable_main_controls()
            elif kind == "show_overlays":
                show_number_overlays(payload)
            elif kind == "show_user_control":
                show_main_user_control()
            elif kind == "show_agent_stopped":
                show_main_agent_stopped(str(payload))
            elif kind == "runtime_error":
                _clear_overlays_and_show_error(str(payload))
    finally:
        if root is not None and not shutdown_event.is_set():
            try:
                root.after(40, drain_ui_queue)
            except tk.TclError:
                pass


def build_main_ui(initial_phase="正在准备", initial_status="正在初始化本地 AI…", initial_detail="所有运行数据均保存在所选文件夹"):
    global root, phase_var, status_var, detail_var, progress_var, status, detail_label, progress
    global number_button, free_button, hardware_var, learning_var
    if root is None:
        root = tk.Tk()
    root.withdraw()
    for child in list(root.winfo_children()):
        try:
            child.destroy()
        except Exception:
            pass

    root.title("Make It Bigger")
    root.geometry("720x520")
    root.minsize(580, 420)
    root.resizable(True, True)
    root.protocol("WM_DELETE_WINDOW", shutdown)
    root.rowconfigure(0, weight=1)
    root.columnconfigure(0, weight=1)

    style = ttk.Style(root)
    if "vista" in style.theme_names():
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
    style.configure("Title.TLabel", font=("Segoe UI", 22, "bold"))
    style.configure("Subtitle.TLabel", font=("Segoe UI", 10))
    style.configure("Phase.TLabel", font=("Segoe UI", 12, "bold"))
    style.configure("Status.TLabel", font=("Segoe UI", 11))
    style.configure("Detail.TLabel", font=("Segoe UI", 9))
    style.configure("Primary.TButton", font=("Segoe UI", 12, "bold"), padding=(18, 14))
    style.configure("Secondary.TButton", font=("Segoe UI", 11), padding=(16, 10))
    style.configure("Footer.TLabel", font=("Segoe UI", 9))

    phase_var = tk.StringVar(value=initial_phase)
    status_var = tk.StringVar(value=initial_status)
    detail_var = tk.StringVar(value=initial_detail)
    progress_var = tk.DoubleVar(value=10.0)
    hardware_var = tk.StringVar(value="硬件监控 GPU  NVIDIA  ·  输入监听 准备中")
    learning_var = tk.StringVar(value="学习 0 次  ·  成功 0 次  ·  待确认 0 次  ·  最佳提升 +0")

    main = ttk.Frame(root, padding=(28, 24, 28, 22))
    main.grid(row=0, column=0, sticky="nsew")
    main.columnconfigure(0, weight=1)
    main.rowconfigure(2, weight=1)

    ttk.Label(main, text="Make It Bigger", style="Title.TLabel").grid(row=0, column=0, sticky="w")
    ttk.Label(main, text="让本地 AI 根据你的选择执行操作", style="Subtitle.TLabel").grid(row=1, column=0, sticky="w", pady=(2, 18))

    card = ttk.LabelFrame(main, text="状态", padding=(18, 14))
    card.grid(row=2, column=0, sticky="nsew")
    card.columnconfigure(0, weight=1)
    card.rowconfigure(2, weight=1)

    ttk.Label(card, textvariable=phase_var, style="Phase.TLabel").grid(row=0, column=0, sticky="w")
    status = ttk.Label(card, textvariable=status_var, style="Status.TLabel", anchor="w", justify="left")
    status.grid(row=1, column=0, sticky="ew", pady=(7, 4))
    detail_label = ttk.Label(card, textvariable=detail_var, style="Detail.TLabel", anchor="nw", justify="left")
    detail_label.grid(row=2, column=0, sticky="nsew", pady=(0, 12))
    progress = ttk.Progressbar(card, variable=progress_var, maximum=100, mode="determinate")
    progress.grid(row=3, column=0, sticky="ew")

    actions = ttk.Frame(main)
    actions.grid(row=3, column=0, sticky="ew", pady=(18, 0))
    actions.columnconfigure(0, weight=1)
    number_button = ttk.Button(actions, text="让你选择的数变大", style="Primary.TButton", state="disabled")
    number_button.grid(row=0, column=0, sticky="ew")
    ttk.Label(actions, text="选择数字：识别屏幕上的数字，由你指定 AI 的目标。", style="Detail.TLabel").grid(row=1, column=0, sticky="w", pady=(5, 12))
    free_button = ttk.Button(actions, text="自由", style="Secondary.TButton", state="disabled")
    free_button.grid(row=2, column=0, sticky="ew")
    ttk.Label(actions, text="自由模式：让 AI 自主运行，直到检测到你的鼠标或键盘输入。", style="Detail.TLabel").grid(row=3, column=0, sticky="w", pady=(5, 0))

    footer = ttk.Frame(main)
    footer.grid(row=4, column=0, sticky="ew", pady=(18, 0))
    footer.columnconfigure(0, weight=1)
    ttk.Separator(footer).grid(row=0, column=0, sticky="ew", pady=(0, 9))
    ttk.Label(footer, textvariable=hardware_var, style="Footer.TLabel").grid(row=1, column=0, sticky="w")
    ttk.Label(footer, textvariable=learning_var, style="Footer.TLabel").grid(row=2, column=0, sticky="w", pady=(3, 0))

    def on_window_resize(event):
        if event.widget is root:
            wrap = max(320, int(event.width) - 120)
            try:
                status.configure(wraplength=wrap)
                detail_label.configure(wraplength=wrap)
            except tk.TclError:
                pass

    root.bind("<Configure>", on_window_resize)
    _refresh_info_vars()
    root.deiconify()
    root.lift()
    try:
        root.after(40, drain_ui_queue)
    except tk.TclError:
        pass


def initialize_ui_and_storage():
    global root, chosen_path, app_dir, deps_dir, temp_dir, hardware_profile
    root = tk.Tk()
    root.withdraw()
    root.update_idletasks()

    console = kernel32.GetConsoleWindow()
    if console:
        user32.ShowWindow(console, SW_HIDE)

    while True:
        chosen = filedialog.askdirectory(title="选择非系统盘文件夹")
        if not chosen:
            root.destroy()
            root = None
            return False
        chosen_path = Path(chosen).resolve()
        drive = chosen_path.drive.upper().rstrip("\\/")
        if drive and drive != SYSTEM_DRIVE:
            break
        messagebox.showerror("请选择非系统盘", f"系统盘是 {SYSTEM_DRIVE}。请选择其他磁盘上的文件夹。")

    app_dir = chosen_path / ".makeitbigger"
    deps_dir = app_dir / "deps"
    temp_dir = app_dir / "temp"
    app_dir.mkdir(parents=True, exist_ok=True)
    temp_dir.mkdir(parents=True, exist_ok=True)
    _init_runtime_logging()

    for key in ("TMP", "TEMP", "TMPDIR", "PIP_CACHE_DIR", "XDG_CACHE_HOME", "CUDA_CACHE_PATH", "OPENCV_OPENCL_CACHE_DIR"):
        os.environ[key] = str(temp_dir)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["PYTHONNOUSERSITE"] = "1"
    os.environ["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    os.environ["PIP_NO_INPUT"] = "1"
    os.environ["PIP_PROGRESS_BAR"] = "off"
    os.environ["PIP_CONFIG_FILE"] = os.devnull
    os.environ["OPENCV_LOG_LEVEL"] = "SILENT"

    build_main_ui(
        initial_phase="正在准备运行环境",
        initial_status="已选择并初始化存储目录",
        initial_detail="所有运行数据、依赖与学习结果仅保存在你选择的文件夹内。",
    )
    _apply_progress({"value": 10, "phase": "正在准备运行环境", "text": "已选择并初始化存储目录", "detail": "正在检查本机硬件配置…", "mode": "determinate"})
    try:
        root.update()
    except tk.TclError:
        return False
    if _shutdown_requested():
        return False

    _apply_progress({"value": 20, "phase": "正在准备运行环境", "text": "正在检查硬件", "detail": "正在读取 CPU、内存、磁盘与 NVIDIA GPU 信息。", "mode": "determinate"})
    try:
        root.update_idletasks()
    except tk.TclError:
        return False
    hardware_profile = _detect_hardware_profile()
    if _shutdown_requested():
        return False
    thread_hint = str(max(1, int(hardware_profile["cv_threads"])))
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[key] = thread_hint
    if deps_dir.exists() and str(deps_dir) not in sys.path:
        sys.path.insert(0, str(deps_dir))
    _refresh_info_vars()
    _apply_progress({"value": 35, "phase": "正在准备运行环境", "text": "正在验证本地依赖", "detail": "检查本地视觉依赖是否完整可用。", "mode": "determinate"})
    return True


def show_startup_error(exc):
    detail = str(exc).strip() or exc.__class__.__name__
    text = f"启动出错：{detail}。AI已停止。"
    if shutdown_event.is_set():
        return False
    try:
        build_main_ui(initial_phase="已停止", initial_status=text, initial_detail="AI 没有继续控制鼠标或键盘。")
        _apply_progress({"value": 0, "phase": "已停止", "text": text, "detail": "AI 没有继续控制鼠标或键盘。关闭窗口即可退出。", "mode": "determinate"})
        number_button.config(state="disabled")
        free_button.config(state="disabled")
        root.deiconify()
        root.lift()
        return True
    except Exception:
        try:
            user32.MessageBoxW(None, text, "Make It Bigger", 0x10)
        except Exception:
            pass
        return False

np = None
cv2 = None
Image = None
ImageGrab = None
ImageDraw = None
ImageFont = None

def bootstrap_dependencies():
    try:
        if _shutdown_requested():
            return
        _bootstrap_dependencies_impl()
    except Exception as exc:
        if not _shutdown_requested():
            post_ui("dependency_failed", f"本地运行依赖准备出错：{exc}")


def _bootstrap_dependencies_impl():
    global np, cv2, Image, ImageGrab, ImageDraw, ImageFont, deps_dir, recognizer, controller
    global hardware_thread, hook_thread
    ready_marker = ".ready-v4"
    stage_dir = app_dir / "deps.new"
    old_dir = app_dir / "deps.old"
    wheel_dir = app_dir / "wheels.new"

    py_tag = f"cp{sys.version_info.major}{sys.version_info.minor}"
    supported = {(3, 10), (3, 11), (3, 12), (3, 13)}
    if sys.implementation.name != "cpython" or sys.version_info[:2] not in supported or ctypes.sizeof(ctypes.c_void_p) != 8:
        raise RuntimeError("仅支持 Windows 11 x64 上的 64 位 CPython 3.10–3.13。")
    gil_probe = getattr(sys, "_is_gil_enabled", None)
    if callable(gil_probe) and not bool(gil_probe()):
        raise RuntimeError("当前依赖仅支持标准 GIL 构建的 64 位 CPython。")

    wheel_hashes = {
        "cp310": {
            "numpy-2.2.6-cp310-cp310-win_amd64.whl": "f0fd6321b839904e15c46e0d257fdd101dd7f530fe03fd6359c1ea63738703f3",
            "pillow-11.3.0-cp310-cp310-win_amd64.whl": "19d2ff547c75b8e3ff46f4d9ef969a06c30ab2d4263a9e287733aa8b2429ce8f",
        },
        "cp311": {
            "numpy-2.2.6-cp311-cp311-win_amd64.whl": "e8213002e427c69c45a52bbd94163084025f533a55a59d6f9c5b820774ef3303",
            "pillow-11.3.0-cp311-cp311-win_amd64.whl": "1a992e86b0dd7aeb1f053cd506508c0999d710a8f07b4c791c63843fc6a807ac",
        },
        "cp312": {
            "numpy-2.2.6-cp312-cp312-win_amd64.whl": "c1f9540be57940698ed329904db803cf7a402f3fc200bfe599334c9bd84a40b2",
            "pillow-11.3.0-cp312-cp312-win_amd64.whl": "a6444696fce635783440b7f7a9fc24b3ad10a9ea3f0ab66c5905be1c19ccf17d",
        },
        "cp313": {
            "numpy-2.2.6-cp313-cp313-win_amd64.whl": "b0544343a702fa80c95ad5d3d608ea3599dd54d4632df855e4c8d24eb6ecfa1c",
            "pillow-11.3.0-cp313-cp313-win_amd64.whl": "0bce5c4fd0921f99d2e858dc4d4d64193407e1b99478bc5cacecba2311abde51",
        },
    }
    expected_wheels = dict(wheel_hashes[py_tag])
    expected_wheels["opencv_python_headless-4.12.0.88-cp37-abi3-win_amd64.whl"] = "86b413bdd6c6bf497832e346cd5371995de148e579b9774f8eba686dee3f5528"

    if _shutdown_requested():
        return
    set_progress(35, "正在验证本地依赖", "检查本地视觉依赖是否完整可用。", phase="正在准备运行环境")

    def smoke_test(directory):
        if _shutdown_requested():
            return False
        env = os.environ.copy()
        env["PYTHONPATH"] = str(directory)
        env["MAKEITBIGGER_DEPS"] = str(directory)
        code = (
            "import os,pathlib,numpy as n,cv2,PIL; from PIL import Image; "
            "base=pathlib.Path(os.environ['MAKEITBIGGER_DEPS']).resolve(); "
            "mods=(n,cv2,PIL); assert all(base in pathlib.Path(m.__file__).resolve().parents for m in mods); "
            "a=n.zeros((8,8),dtype=n.uint8); assert cv2.countNonZero(a)==0; "
            "assert Image.new('L',(2,2)).size==(2,2)"
        )
        result = run_child(
            [sys.executable, "-c", code], cwd=str(app_dir), env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=_clamp(20.0 + hardware_profile["capacity"] * 4.0, 24.0, 45.0),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if _shutdown_requested():
            return False
        return result is not None and result.returncode == 0

    ready = deps_dir / ready_marker
    dependencies_ready = ready.exists() and smoke_test(deps_dir)
    if _shutdown_requested():
        return
    if not dependencies_ready:
        set_progress(
            55,
            "正在安装或修复本地依赖",
            "首次运行或依赖需要修复；安装仅写入你选择的文件夹。",
            phase="正在准备运行环境",
            mode="indeterminate",
        )
        shutil.rmtree(stage_dir, ignore_errors=True)
        shutil.rmtree(wheel_dir, ignore_errors=True)
        if _shutdown_requested():
            return
        stage_dir.mkdir(parents=True, exist_ok=True)
        wheel_dir.mkdir(parents=True, exist_ok=True)
        packages = ("numpy==2.2.6", "Pillow==11.3.0", "opencv-python-headless==4.12.0.88")
        download_cmd = [
            sys.executable, "-m", "pip", "download", "--no-cache-dir", "--disable-pip-version-check",
            "--timeout", "12", "--retries", "2", "--no-deps", "--only-binary=:all:",
            "--dest", str(wheel_dir), *packages,
        ]
        attempts = int(_clamp(round(math.log2(hardware_profile["cpu_count"] + 1.0)), 2, 4))
        installed = False
        for attempt in range(attempts):
            if _shutdown_requested():
                shutil.rmtree(stage_dir, ignore_errors=True)
                shutil.rmtree(wheel_dir, ignore_errors=True)
                return
            shutil.rmtree(wheel_dir, ignore_errors=True)
            wheel_dir.mkdir(parents=True, exist_ok=True)
            result = run_child(
                download_cmd, timeout=240.0, cwd=str(app_dir), env=os.environ.copy(),
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if _shutdown_requested():
                shutil.rmtree(stage_dir, ignore_errors=True)
                shutil.rmtree(wheel_dir, ignore_errors=True)
                return
            if result is None or result.returncode != 0:
                if shutdown_event.wait(_clamp((attempt + 1) ** 1.5, 1.0, 6.0)):
                    shutil.rmtree(stage_dir, ignore_errors=True)
                    shutil.rmtree(wheel_dir, ignore_errors=True)
                    return
                continue
            downloaded = {path.name: path for path in wheel_dir.glob("*.whl")}
            if set(downloaded) != set(expected_wheels):
                continue
            valid = True
            for name, expected_hash in expected_wheels.items():
                digest_state = hashlib.sha256()
                with downloaded[name].open("rb") as wheel_file:
                    for chunk in iter(lambda: wheel_file.read(1024 * 1024), b""):
                        digest_state.update(chunk)
                digest = digest_state.hexdigest()
                if digest.lower() != expected_hash.lower():
                    valid = False
                    _log_runtime("error", f"dependency wheel hash mismatch: {name}")
                    break
            if not valid:
                continue
            install_cmd = [
                sys.executable, "-m", "pip", "install", "--no-cache-dir", "--disable-pip-version-check",
                "--no-index", "--no-deps", "--target", str(stage_dir),
                *[str(downloaded[name]) for name in sorted(expected_wheels)],
            ]
            result = run_child(
                install_cmd, timeout=240.0, cwd=str(app_dir), env=os.environ.copy(),
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if result is not None and result.returncode == 0 and smoke_test(stage_dir):
                installed = True
                break
        shutil.rmtree(wheel_dir, ignore_errors=True)
        if not installed:
            shutil.rmtree(stage_dir, ignore_errors=True)
            if not _shutdown_requested():
                post_ui("dependency_failed", "本地运行依赖自动准备失败或完整性校验未通过。")
            return
        if _shutdown_requested():
            shutil.rmtree(stage_dir, ignore_errors=True)
            return
        (stage_dir / ready_marker).write_text("4", encoding="ascii")
        shutil.rmtree(old_dir, ignore_errors=True)
        try:
            if deps_dir.exists():
                os.replace(deps_dir, old_dir)
            os.replace(stage_dir, deps_dir)
            shutil.rmtree(old_dir, ignore_errors=True)
        except Exception:
            if not deps_dir.exists() and old_dir.exists():
                os.replace(old_dir, deps_dir)
            shutil.rmtree(stage_dir, ignore_errors=True)
            raise

    if _shutdown_requested():
        return
    set_progress(70, "本地依赖已就绪", "正在加载数字识别所需的本地视觉组件。", phase="正在准备运行环境")
    if str(deps_dir) not in sys.path:
        sys.path.insert(0, str(deps_dir))
    import importlib
    importlib.invalidate_caches()
    if _shutdown_requested():
        return
    import numpy as _np
    import cv2 as _cv2
    from PIL import Image as _Image, ImageGrab as _ImageGrab, ImageDraw as _ImageDraw, ImageFont as _ImageFont
    if _shutdown_requested():
        return
    np, cv2 = _np, _cv2
    Image, ImageGrab, ImageDraw, ImageFont = _Image, _ImageGrab, _ImageDraw, _ImageFont
    cv2.setNumThreads(max(1, int(hardware_profile["cv_threads"])))

    set_progress(75, "正在加载数字识别器", "正在生成或加载本机自建数字视觉模型。", phase="正在准备本地 AI")
    if _shutdown_requested():
        return
    recognizer = LocalDigitRecognizer()
    if _shutdown_requested():
        return
    controller = LearningController()
    if _shutdown_requested():
        return

    hardware_thread = threading.Thread(target=_hardware_monitor_loop, name="MakeItBiggerHardware", daemon=True)
    hardware_thread.start()
    set_progress(90, "正在安装鼠标和键盘输入监听", "监听就绪前 AI 不会控制任何输入。", phase="正在完成启动")
    if _shutdown_requested():
        return
    hook_thread = threading.Thread(target=controller.run_input_monitor, name="MakeItBiggerInputHook", daemon=True)
    hook_thread.start()

def dependency_failed(text):
    _clear_overlays_and_show_error(text)


def _as_decimal(value):
    if isinstance(value, Decimal):
        result = value
    elif isinstance(value, int):
        result = Decimal(value)
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("number is not finite")
        result = Decimal(str(value))
    else:
        result = Decimal(str(value).strip())
    if not result.is_finite():
        raise ValueError("number is not finite")
    return result


def _same_number(a, b):
    try:
        return _as_decimal(a) == _as_decimal(b)
    except (InvalidOperation, TypeError, ValueError):
        return False


def _decimal_quantum(value):
    number = _as_decimal(value)
    exponent = number.as_tuple().exponent
    return Decimal(1).scaleb(exponent)


def _observation_value_and_quantum(observation):
    if isinstance(observation, dict):
        value = _as_decimal(observation.get("value"))
        raw_quantum = observation.get("display_quantum")
        try:
            quantum = abs(_as_decimal(raw_quantum)) if raw_quantum is not None else abs(_decimal_quantum(value))
        except (InvalidOperation, TypeError, ValueError):
            quantum = abs(_decimal_quantum(value))
        return value, max(quantum, Decimal("1e-10000"))
    value = _as_decimal(observation)
    return value, max(abs(_decimal_quantum(value)), Decimal("1e-10000"))


def _same_ocr_number(a, b):
    try:
        av, aq = _observation_value_and_quantum(a)
        bv, bq = _observation_value_and_quantum(b)
        tolerance = min(aq, bq) * Decimal("0.25")
        return abs(av - bv) <= tolerance
    except (InvalidOperation, TypeError, ValueError):
        return False


def _number_key(value):
    return _as_decimal(value).normalize()


def _format_number(value):
    number = _as_decimal(value)
    if number.is_zero():
        return "0"
    normalized = number.normalize()
    adjusted = normalized.adjusted()
    if normalized == normalized.to_integral_value() and -6 <= adjusted <= 18:
        return format(normalized, "f")
    if -6 <= adjusted <= 18:
        return format(normalized, "f")
    return format(normalized, "E").replace("E", "e")


def _decimal_to_learning_float(value):
    number = abs(_as_decimal(value))
    if number.is_zero():
        return 0.0
    if number.adjusted() > 300:
        return 1e300
    try:
        converted = float(number)
    except (OverflowError, ValueError):
        return 1e300
    return min(1e300, max(0.0, converted))


class LocalDigitRecognizer:
    LABELS = tuple("0123456789+-.,eE")
    MODEL_VERSION = "self-trained-digit-mlp-v4"
    INPUT_SHAPE = (28, 20)
    HIDDEN = 96

    def __init__(self):
        self.model_path = app_dir / "digit_model.npz"
        self.self_sample_path = app_dir / "digit_self_samples.npz"
        self.self_sample_lock = threading.Lock()
        self.self_features = []
        self.self_labels = []
        self.new_self_samples = 0
        self.last_self_tune = time.monotonic()
        self.label_to_index = {label: i for i, label in enumerate(self.LABELS)}
        try:
            locale.setlocale(locale.LC_NUMERIC, "")
            conv = locale.localeconv()
        except Exception:
            conv = {}
        self.locale_decimal = str(conv.get("decimal_point") or ".")
        self.locale_thousands = str(conv.get("thousands_sep") or "")
        loaded = self._load_model()
        self._load_self_samples()
        if not loaded:
            set_progress(75, "正在生成本机数字视觉模型", "首次生成耗时不可预测；模型完全由本机生成和训练。", phase="正在准备本地 AI", mode="indeterminate")
            if _shutdown_requested():
                return
            self._train_model()
            if _shutdown_requested():
                return
            if self.self_features:
                self._fine_tune_self_samples(force=True)
            self._save_model()

    def _font_paths(self):
        windir = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
        preferred = [
            "segoeui.ttf", "seguisb.ttf", "arial.ttf", "arialbd.ttf", "calibri.ttf", "calibrib.ttf",
            "consola.ttf", "consolab.ttf", "tahoma.ttf", "verdana.ttf", "times.ttf", "trebuc.ttf",
            "cour.ttf", "courbd.ttf", "georgia.ttf", "impact.ttf"
        ]
        found = []
        for name in preferred:
            path = windir / name
            if path.exists():
                found.append(path)
        for pattern in ("*.ttf", "*.otf", "*.ttc"):
            for path in sorted(windir.glob(pattern)):
                if path not in found:
                    found.append(path)
        usable = []
        for path in found:
            try:
                ImageFont.truetype(str(path), 32)
                usable.append(path)
            except Exception:
                continue
        if not usable:
            raise RuntimeError("找不到可用的 Windows 字体。")
        return usable

    def _normalize_mask(self, mask):
        mask = np.asarray(mask, dtype=np.uint8)
        ys, xs = np.where(mask > 0)
        if len(xs) == 0:
            return np.zeros(self.INPUT_SHAPE, dtype=np.float32).reshape(-1)
        crop = mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
        h, w = crop.shape
        target_h, target_w = self.INPUT_SHAPE
        scale = min((target_w - 4.0) / max(w, 1), (target_h - 4.0) / max(h, 1))
        nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
        interpolation = cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LINEAR
        resized = cv2.resize(crop, (nw, nh), interpolation=interpolation)
        out = np.zeros((target_h, target_w), dtype=np.uint8)
        x0 = (target_w - nw) // 2
        y0 = (target_h - nh) // 2
        out[y0:y0 + nh, x0:x0 + nw] = resized
        return out.astype(np.float32).reshape(-1) / 255.0

    def _augment_mask(self, mask, rng):
        arr = np.asarray(mask, dtype=np.uint8)
        h, w = arr.shape
        angle = rng.uniform(-10.0, 10.0)
        scale_x = rng.uniform(0.76, 1.24)
        scale_y = rng.uniform(0.78, 1.22)
        matrix = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle, 1.0)
        matrix[0, 0] *= scale_x
        matrix[0, 1] *= scale_x
        matrix[1, 0] *= scale_y
        matrix[1, 1] *= scale_y
        matrix[0, 2] += rng.uniform(-5.0, 5.0)
        matrix[1, 2] += rng.uniform(-5.0, 5.0)
        arr = cv2.warpAffine(arr, matrix, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
        if rng.random() < 0.65:
            shift = rng.uniform(-0.10, 0.10) * w
            src = np.float32([[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]])
            dst = np.float32([[shift, 0], [w - 1 - shift, 0], [-shift, h - 1], [w - 1 + shift, h - 1]])
            perspective = cv2.getPerspectiveTransform(src, dst)
            arr = cv2.warpPerspective(arr, perspective, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
        if rng.random() < 0.48:
            k = rng.choice((2, 3))
            kernel = np.ones((k, k), dtype=np.uint8)
            if rng.random() < 0.5:
                arr = cv2.dilate(arr, kernel, iterations=1)
            else:
                arr = cv2.erode(arr, kernel, iterations=1)
        if rng.random() < 0.55:
            sigma = rng.uniform(0.15, 1.05)
            arr = cv2.GaussianBlur(arr, (0, 0), sigmaX=sigma, sigmaY=sigma)
        if rng.random() < 0.52:
            noise_rng = np.random.default_rng(rng.getrandbits(64))
            noise = noise_rng.normal(0.0, 13.0, size=arr.shape).astype(np.float32)
            arr = np.clip(arr.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        threshold = rng.randint(45, 175)
        _, arr = cv2.threshold(arr, threshold, 255, cv2.THRESH_BINARY)
        return arr

    def _font_sample(self, label, font_path, rng):
        canvas = Image.new("L", (88, 88), 0)
        draw = ImageDraw.Draw(canvas)
        size = rng.randint(22, 66)
        font = ImageFont.truetype(str(font_path), size)
        stroke = rng.randint(0, 2)
        bbox = draw.textbbox((0, 0), label, font=font, stroke_width=stroke)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        x = 44 - tw // 2 - bbox[0] + rng.randint(-5, 5)
        y = 44 - th // 2 - bbox[1] + rng.randint(-5, 5)
        draw.text((x, y), label, fill=255, font=font, stroke_width=stroke, stroke_fill=255)
        return self._augment_mask(np.asarray(canvas), rng)

    def _seven_segment_sample(self, label, rng):
        canvas = np.zeros((88, 88), dtype=np.uint8)
        thickness = rng.randint(3, 8)
        left = rng.randint(17, 24)
        right = rng.randint(62, 70)
        top = rng.randint(12, 18)
        middle = rng.randint(40, 46)
        bottom = rng.randint(70, 77)
        segments = {
            "a": ((left + 4, top), (right - 4, top)),
            "b": ((right, top + 4), (right, middle - 4)),
            "c": ((right, middle + 4), (right, bottom - 4)),
            "d": ((left + 4, bottom), (right - 4, bottom)),
            "e": ((left, middle + 4), (left, bottom - 4)),
            "f": ((left, top + 4), (left, middle - 4)),
            "g": ((left + 4, middle), (right - 4, middle)),
        }
        digits = {
            "0": "ab cdef".replace(" ", ""), "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg",
            "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg"
        }
        if label in digits:
            for name in digits[label]:
                p0, p1 = segments[name]
                cv2.line(canvas, p0, p1, 255, thickness=thickness, lineType=cv2.LINE_AA)
        elif label == "-":
            p0, p1 = segments["g"]
            cv2.line(canvas, p0, p1, 255, thickness=thickness, lineType=cv2.LINE_AA)
        elif label == "+":
            p0, p1 = segments["g"]
            cv2.line(canvas, p0, p1, 255, thickness=thickness, lineType=cv2.LINE_AA)
            cv2.line(canvas, ((left + right) // 2, top + 12), ((left + right) // 2, bottom - 12), 255, thickness=thickness, lineType=cv2.LINE_AA)
        elif label in ".,":
            cx = rng.randint(42, 51)
            cy = rng.randint(68, 77)
            cv2.circle(canvas, (cx, cy), max(2, thickness // 2), 255, -1, lineType=cv2.LINE_AA)
            if label == ",":
                cv2.line(canvas, (cx, cy + 1), (cx - rng.randint(2, 5), min(86, cy + rng.randint(7, 12))), 255, max(1, thickness // 2), lineType=cv2.LINE_AA)
        return self._augment_mask(canvas, rng)

    def _ood_augment_mask(self, mask, rng):
        arr = np.asarray(mask, dtype=np.uint8)
        h, w = arr.shape
        down = rng.uniform(0.42, 0.78)
        small = cv2.resize(arr, (max(8, int(w * down)), max(8, int(h * down))), interpolation=cv2.INTER_AREA)
        arr = cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)
        arr = cv2.GaussianBlur(arr, (0, 0), sigmaX=rng.uniform(0.8, 2.2))
        if rng.random() < 0.55:
            kernel = np.ones((rng.choice((2, 3)), rng.choice((2, 3))), dtype=np.uint8)
            arr = cv2.erode(arr, kernel, iterations=1) if rng.random() < 0.5 else cv2.dilate(arr, kernel, iterations=1)
        threshold = rng.randint(85, 205)
        _, arr = cv2.threshold(arr, threshold, 255, cv2.THRESH_BINARY)
        return arr

    def _make_training_set(self):
        train_rng = random.Random(731921)
        valid_rng = random.Random(918273)
        fonts = self._font_paths()
        holdout_fonts = fonts[::5] or fonts[-1:]
        holdout_set = {str(path).lower() for path in holdout_fonts}
        train_fonts = [path for path in fonts if str(path).lower() not in holdout_set] or fonts
        train_features, train_labels = [], []
        valid_features, valid_labels = [], []
        capacity = max(1.0, float(hardware_profile.get("capacity", 1.0)))
        base_font_rounds = int(_clamp(round(24 + capacity * 5.0), 28, 54))
        base_synth_rounds = int(_clamp(round(16 + capacity * 4.0), 20, 42))
        for label in self.LABELS:
            if _shutdown_requested():
                empty_x = np.empty((0, self.INPUT_SHAPE[0] * self.INPUT_SHAPE[1]), dtype=np.float32)
                empty_y = np.empty((0,), dtype=np.int32)
                return empty_x, empty_y, empty_x.copy(), empty_y.copy()
            font_rounds = int(round(base_font_rounds * (1.15 if label in ".," else 1.0)))
            for _ in range(font_rounds):
                mask = self._font_sample(label, train_rng.choice(train_fonts), train_rng)
                feat = self._normalize_mask(mask)
                if feat.sum() >= 2.0:
                    train_features.append(feat); train_labels.append(self.label_to_index[label])
            valid_rounds = max(7, int(round(font_rounds * 0.24)))
            for _ in range(valid_rounds):
                mask = self._font_sample(label, valid_rng.choice(holdout_fonts), valid_rng)
                mask = self._ood_augment_mask(mask, valid_rng)
                feat = self._normalize_mask(mask)
                if feat.sum() >= 2.0:
                    valid_features.append(feat); valid_labels.append(self.label_to_index[label])
            synth_rounds = int(round(base_synth_rounds * (1.20 if label.isdigit() else 0.75))) if label in "0123456789+-.," else 0
            for _ in range(synth_rounds):
                mask = self._seven_segment_sample(label, train_rng)
                feat = self._normalize_mask(mask)
                if feat.sum() >= 2.0:
                    train_features.append(feat); train_labels.append(self.label_to_index[label])
            for _ in range(max(3, synth_rounds // 5)):
                if not synth_rounds:
                    break
                mask = self._ood_augment_mask(self._seven_segment_sample(label, valid_rng), valid_rng)
                feat = self._normalize_mask(mask)
                if feat.sum() >= 2.0:
                    valid_features.append(feat); valid_labels.append(self.label_to_index[label])
        train_x = np.asarray(train_features, dtype=np.float32)
        train_y = np.asarray(train_labels, dtype=np.int32)
        valid_x = np.asarray(valid_features, dtype=np.float32)
        valid_y = np.asarray(valid_labels, dtype=np.int32)
        train_order = np.random.default_rng(731921).permutation(len(train_x))
        valid_order = np.random.default_rng(918273).permutation(len(valid_x))
        return train_x[train_order], train_y[train_order], valid_x[valid_order], valid_y[valid_order]

    def _forward(self, x):
        hidden = np.maximum(0.0, x @ self.w1 + self.b1)
        logits = hidden @ self.w2 + self.b2
        logits -= logits.max(axis=1, keepdims=True)
        exp = np.exp(logits)
        probs = exp / np.maximum(exp.sum(axis=1, keepdims=True), 1e-8)
        return hidden, probs

    def _train_model(self):
        train_x, train_y, valid_x, valid_y = self._make_training_set()
        if _shutdown_requested():
            return
        minimum = max(len(self.LABELS) * 12, self.HIDDEN * 2)
        if len(train_x) < minimum or len(valid_x) < len(self.LABELS) * 3:
            raise RuntimeError("本机训练或独立验证样本不足。")
        rng = np.random.default_rng(731921)
        input_dim = train_x.shape[1]
        output_dim = len(self.LABELS)
        self.w1 = (rng.standard_normal((input_dim, self.HIDDEN)).astype(np.float32) * math.sqrt(2.0 / input_dim))
        self.b1 = np.zeros((self.HIDDEN,), dtype=np.float32)
        self.w2 = (rng.standard_normal((self.HIDDEN, output_dim)).astype(np.float32) * math.sqrt(2.0 / self.HIDDEN))
        self.b2 = np.zeros((output_dim,), dtype=np.float32)
        params = [self.w1, self.b1, self.w2, self.b2]
        moments = [np.zeros_like(param) for param in params]
        variances = [np.zeros_like(param) for param in params]
        best_weights = [param.copy() for param in params]
        best_score = -1.0
        step = 0
        batch = max(1, min(len(train_x), int(hardware_profile["training_batch"])))
        epochs = max(1, int(hardware_profile["training_epochs"]))
        for _ in range(epochs):
            if _shutdown_requested():
                return
            order = rng.permutation(len(train_x))
            for start in range(0, len(order), batch):
                if _shutdown_requested():
                    return
                idx = order[start:start + batch]
                xb = train_x[idx]
                yb = train_y[idx]
                hidden, probs = self._forward(xb)
                grad = probs.copy()
                grad[np.arange(len(yb)), yb] -= 1.0
                grad /= max(1, len(yb))
                gw2 = hidden.T @ grad + self.w2 * 0.0001
                gb2 = grad.sum(axis=0)
                gh = grad @ self.w2.T
                gh[hidden <= 0.0] = 0.0
                gw1 = xb.T @ gh + self.w1 * 0.0001
                gb1 = gh.sum(axis=0)
                step += 1
                gradients = (gw1, gb1, gw2, gb2)
                for i, gradient in enumerate(gradients):
                    moments[i] *= 0.9
                    moments[i] += gradient * 0.1
                    variances[i] *= 0.999
                    variances[i] += gradient * gradient * 0.001
                    m_hat = moments[i] / (1.0 - 0.9 ** step)
                    v_hat = variances[i] / (1.0 - 0.999 ** step)
                    params[i] -= 0.003 * m_hat / (np.sqrt(v_hat) + 1e-8)
            if len(valid_x):
                _, valid_probs = self._forward(valid_x)
                score = float(np.mean(np.argmax(valid_probs, axis=1) == valid_y))
                if score > best_score:
                    best_score = score
                    best_weights = [param.copy() for param in params]
        self.w1[:], self.b1[:], self.w2[:], self.b2[:] = best_weights
        self.centroids = np.zeros((output_dim, input_dim), dtype=np.float32)
        self.radii = np.zeros((output_dim,), dtype=np.float32)
        for idx in range(output_dim):
            if _shutdown_requested():
                return
            members = train_x[train_y == idx]
            center = members.mean(axis=0)
            self.centroids[idx] = center
            distances = np.mean((members - center) ** 2, axis=1)
            self.radii[idx] = max(0.012, float(np.quantile(distances, 0.985)) * 2.2)

    def _load_self_samples(self):
        try:
            with np.load(self.self_sample_path, allow_pickle=False) as data:
                features = np.asarray(data["features"], dtype=np.float32)
                labels = np.asarray(data["labels"], dtype=np.int32)
            if features.ndim != 2 or features.shape[1] != self.INPUT_SHAPE[0] * self.INPUT_SHAPE[1] or labels.shape != (len(features),):
                return
            cap = 4096
            self.self_features = [row.copy() for row in features[-cap:]]
            self.self_labels = [int(v) for v in labels[-cap:] if 0 <= int(v) < len(self.LABELS)]
            if len(self.self_labels) != len(self.self_features):
                self.self_features = []
                self.self_labels = []
        except Exception:
            self.self_features = []
            self.self_labels = []

    def _save_self_samples(self):
        with self.self_sample_lock:
            if not self.self_features:
                return
            tmp = app_dir / "digit_self_samples.tmp.npz"
            np.savez_compressed(tmp, features=np.asarray(self.self_features, dtype=np.float32), labels=np.asarray(self.self_labels, dtype=np.int32))
            os.replace(tmp, self.self_sample_path)

    def _fine_tune_self_samples(self, force=False):
        if not self.self_features or _shutdown_requested():
            return
        now = time.monotonic()
        if not force and (self.new_self_samples < 48 or now - self.last_self_tune < 120.0):
            return
        with self.self_sample_lock:
            x = np.asarray(self.self_features[-1024:], dtype=np.float32)
            y = np.asarray(self.self_labels[-1024:], dtype=np.int32)
        replay_x = np.repeat(self.centroids, 4, axis=0)
        replay_y = np.repeat(np.arange(len(self.LABELS), dtype=np.int32), 4)
        x = np.concatenate((x, replay_x), axis=0)
        y = np.concatenate((y, replay_y), axis=0)
        rng = np.random.default_rng(int(now * 1000) & 0xFFFFFFFF)
        for _ in range(3):
            order = rng.permutation(len(x))
            for start in range(0, len(order), 96):
                idx = order[start:start + 96]
                xb, yb = x[idx], y[idx]
                hidden, probs = self._forward(xb)
                grad = probs.copy()
                grad[np.arange(len(yb)), yb] -= 1.0
                grad /= max(1, len(yb))
                gw2 = hidden.T @ grad + self.w2 * 0.00005
                gb2 = grad.sum(axis=0)
                gh = grad @ self.w2.T
                gh[hidden <= 0.0] = 0.0
                gw1 = xb.T @ gh + self.w1 * 0.00005
                gb1 = gh.sum(axis=0)
                self.w1 -= 0.0008 * gw1
                self.b1 -= 0.0008 * gb1
                self.w2 -= 0.0008 * gw2
                self.b2 -= 0.0008 * gb2
        real_x = np.asarray(self.self_features[-2048:], dtype=np.float32)
        real_y = np.asarray(self.self_labels[-2048:], dtype=np.int32)
        for idx in range(len(self.LABELS)):
            members = real_x[real_y == idx]
            if len(members) < 2:
                continue
            mean = members.mean(axis=0)
            self.centroids[idx] = self.centroids[idx] * 0.85 + mean * 0.15
            distances = np.mean((members - self.centroids[idx]) ** 2, axis=1)
            self.radii[idx] = max(float(self.radii[idx]), float(np.quantile(distances, 0.985)) * 1.6, 0.012)
        self.new_self_samples = 0
        self.last_self_tune = now
        self._save_model()

    def observe_verified_number(self, image, origin, observation, expected_text):
        if observation is None or float(observation.get("conf", 0.0)) < 0.86:
            return
        chars = observation.get("chars")
        text = str(observation.get("text", ""))
        expected = str(expected_text)
        if not isinstance(chars, list) or len(chars) != len(text) or text != expected or len(chars) != len(expected):
            return
        gray = np.asarray(image.convert("L"), dtype=np.uint8)
        additions = []
        for item, label in zip(chars, expected):
            if label not in self.label_to_index or str(item.get("char", "")) != label or float(item.get("conf", 0.0)) < 0.82:
                return
            x0, y0, x1, y1 = item["box"]
            ix0 = max(0, int(x0 - origin[0])); iy0 = max(0, int(y0 - origin[1]))
            ix1 = min(gray.shape[1], int(x1 - origin[0])); iy1 = min(gray.shape[0], int(y1 - origin[1]))
            if ix1 - ix0 < 2 or iy1 - iy0 < 2:
                return
            crop = gray[iy0:iy1, ix0:ix1]
            _, light = cv2.threshold(crop, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
            candidates = []
            for mask in (light, 255 - light):
                result = self._classify_mask(mask)
                if result is not None and result[0] == label and float(result[1]) >= 0.80:
                    candidates.append((float(result[1]), self._normalize_mask(mask)))
            if not candidates:
                return
            additions.append(max(candidates, key=lambda pair: pair[0])[1])
        with self.self_sample_lock:
            for feature, label in zip(additions, expected):
                self.self_features.append(feature)
                self.self_labels.append(self.label_to_index[label])
            cap = 4096
            if len(self.self_features) > cap:
                self.self_features = self.self_features[-cap:]
                self.self_labels = self.self_labels[-cap:]
            self.new_self_samples += len(additions)
        self._save_self_samples()
        self._fine_tune_self_samples()

    def _save_model(self):
        tmp = app_dir / "digit_model.tmp.npz"
        np.savez_compressed(
            tmp, version=np.asarray([self.MODEL_VERSION]), labels=np.asarray(self.LABELS),
            w1=self.w1, b1=self.b1, w2=self.w2, b2=self.b2,
            centroids=self.centroids, radii=self.radii
        )
        os.replace(tmp, self.model_path)

    def _load_model(self):
        try:
            with np.load(self.model_path, allow_pickle=False) as data:
                version = str(data["version"][0])
                labels = tuple(str(v) for v in data["labels"].tolist())
                if version != self.MODEL_VERSION or labels != self.LABELS:
                    return False
                w1 = np.asarray(data["w1"], dtype=np.float32)
                b1 = np.asarray(data["b1"], dtype=np.float32)
                w2 = np.asarray(data["w2"], dtype=np.float32)
                b2 = np.asarray(data["b2"], dtype=np.float32)
                centroids = np.asarray(data["centroids"], dtype=np.float32)
                radii = np.asarray(data["radii"], dtype=np.float32)
            if w1.shape != (self.INPUT_SHAPE[0] * self.INPUT_SHAPE[1], self.HIDDEN):
                return False
            if w2.shape != (self.HIDDEN, len(self.LABELS)) or centroids.shape != (len(self.LABELS), w1.shape[0]):
                return False
            if b1.shape != (self.HIDDEN,) or b2.shape != (len(self.LABELS),) or radii.shape != (len(self.LABELS),):
                return False
            self.w1, self.b1, self.w2, self.b2 = w1, b1, w2, b2
            self.centroids, self.radii = centroids, radii
            return True
        except Exception:
            return False

    def _classify_mask(self, crop):
        feat = self._normalize_mask(crop)
        if feat.sum() < 2.0:
            return None
        _, probs = self._forward(feat.reshape(1, -1))
        row = probs[0]
        order = np.argsort(row)[::-1]
        best_idx = int(order[0])
        second_idx = int(order[1])
        best_prob = float(row[best_idx])
        margin = best_prob - float(row[second_idx])
        distance = float(np.mean((feat - self.centroids[best_idx]) ** 2))
        label = self.LABELS[best_idx]
        min_prob = 0.32 if label in "+-.," else 0.35
        if best_prob < min_prob or margin < 0.06 or distance > float(self.radii[best_idx]):
            return None
        distance_score = max(0.0, 1.0 - distance / max(float(self.radii[best_idx]), 1e-6))
        return label, max(0.0, min(1.0, best_prob * 0.72 + distance_score * 0.28))

    def _parse_number_candidates(self, text):
        raw_text = str(text).strip()
        match = re.fullmatch(r"([+-]?)([0-9]+(?:[.,][0-9]*)*|[.,][0-9]+)(?:([eE])([+-]?\d+))?", raw_text)
        if not match:
            return []
        sign_text, mantissa, exponent_mark, exponent_text = match.groups()
        if not mantissa or not any(ch.isdigit() for ch in mantissa):
            return []
        exponent = int(exponent_text) if exponent_mark else 0
        if abs(exponent) > 10000:
            return []

        def add_value(values, normalized):
            try:
                with localcontext() as ctx:
                    ctx.prec = max(64, len(normalized) + abs(exponent) + 8)
                    value = Decimal(normalized)
                    if sign_text == "-":
                        value = -value
                    if exponent:
                        value = value.scaleb(exponent)
            except (InvalidOperation, ValueError, OverflowError):
                return
            if value.is_finite() and not any(_same_number(value, existing) for existing in values):
                values.append(value)

        values = []
        dots = mantissa.count(".")
        commas = mantissa.count(",")
        if dots and commas:
            decimal_sep = "." if mantissa.rfind(".") > mantissa.rfind(",") else ","
            grouping_sep = "," if decimal_sep == "." else "."
            compact = mantissa.replace(grouping_sep, "")
            if compact.count(decimal_sep) == 1:
                add_value(values, compact.replace(decimal_sep, "."))
        elif dots or commas:
            sep = "." if dots else ","
            parts = mantissa.split(sep)
            grouping_valid = len(parts) >= 2 and parts[0].isdigit() and all(part.isdigit() and len(part) == 3 for part in parts[1:])
            decimal_valid = len(parts) == 2 and all(part.isdigit() or part == "" for part in parts)
            prefer_grouping = sep == self.locale_thousands and sep != self.locale_decimal
            prefer_decimal = sep == self.locale_decimal
            interpretations = []
            if grouping_valid and prefer_grouping:
                interpretations.append("group")
            if decimal_valid and prefer_decimal:
                interpretations.append("decimal")
            if grouping_valid and "group" not in interpretations:
                interpretations.append("group")
            if decimal_valid and "decimal" not in interpretations:
                interpretations.append("decimal")
            for interpretation in interpretations:
                if interpretation == "group":
                    add_value(values, mantissa.replace(sep, ""))
                else:
                    normalized = mantissa.replace(sep, ".")
                    if normalized.startswith("."):
                        normalized = "0" + normalized
                    if normalized.endswith("."):
                        normalized += "0"
                    add_value(values, normalized)
        else:
            add_value(values, mantissa)
        return values

    def _parse_number_text(self, text, reference=None):
        candidates = self._parse_number_candidates(text)
        if not candidates:
            return None
        if reference is not None:
            try:
                ref = _as_decimal(reference)
                scale = max(Decimal(1), abs(ref))
                return min(candidates, key=lambda value: abs(value - ref) / scale)
            except (InvalidOperation, TypeError, ValueError):
                pass
        return candidates[0]


    def _best_numeric_span(self, selected):
        best = None
        for i in range(len(selected)):
            for j in range(i + 1, len(selected) + 1):
                span = selected[i:j]
                text = "".join(char["char"] for char in span)
                candidates = self._parse_number_candidates(text)
                if not candidates:
                    continue
                digit_count = sum(char["char"].isdigit() for char in span)
                if digit_count == 0:
                    continue
                mean_conf = sum(float(char["conf"]) for char in span) / len(span)
                exponent_bonus = 0.4 if "e" in text.lower() else 0.0
                score = digit_count * 2.0 + len(span) * 0.35 + mean_conf + exponent_bonus
                if best is None or score > best[0]:
                    best = (score, span, candidates[0], text, candidates)
        return best

    def _candidate_masks(self, gray, fast=False):
        h_img, w_img = gray.shape
        block = 31 if min(h_img, w_img) >= 31 else max(3, min(h_img, w_img) | 1)
        adaptive_inv = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, block, 9)
        _, otsu_inv = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
        if fast:
            return (adaptive_inv, otsu_inv)
        adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block, 9)
        _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        kernel_edge = max(3, int(round(math.sqrt(max(9, min(h_img, w_img))) / 4.0)) | 1)
        close_kernel = np.ones((kernel_edge, kernel_edge), dtype=np.uint8)
        return (
            adaptive_inv, adaptive, otsu_inv, otsu,
            cv2.morphologyEx(adaptive_inv, cv2.MORPH_CLOSE, close_kernel, iterations=1),
            cv2.morphologyEx(adaptive, cv2.MORPH_CLOSE, close_kernel, iterations=1),
        )

    def _char_overlap_fraction(self, a, b):
        x0 = max(a[0], b[0])
        y0 = max(a[1], b[1])
        x1 = min(a[2], b[2])
        y1 = min(a[3], b[3])
        inter = max(0, x1 - x0) * max(0, y1 - y0)
        area_a = max(1, (a[2] - a[0]) * (a[3] - a[1]))
        area_b = max(1, (b[2] - b[0]) * (b[3] - b[1]))
        return inter / float(min(area_a, area_b))

    def _add_char(self, chars, item):
        new_box = item["box"]
        new_area = max(1, (new_box[2] - new_box[0]) * (new_box[3] - new_box[1]))
        for old in chars:
            old_box = old["box"]
            overlap = self._char_overlap_fraction(new_box, old_box)
            if overlap < 0.82:
                continue
            old_area = max(1, (old_box[2] - old_box[0]) * (old_box[3] - old_box[1]))
            if new_area > old_area * 1.22 and float(item["conf"]) >= float(old["conf"]) - 0.12:
                old.update(item)
            elif old_area <= new_area * 1.22 and float(item["conf"]) > float(old["conf"]):
                old.update(item)
            return
        chars.append(item)

    def _repair_punctuation(self, chars):
        for item in chars:
            box = item["box"]
            h = max(1, box[3] - box[1])
            w = max(1, box[2] - box[0])
            if w / float(h) > 1.65 or item.get("char") in "+-":
                continue
            neighbors = []
            cx = (box[0] + box[2]) / 2.0
            for other in chars:
                if other is item:
                    continue
                ob = other["box"]
                oh = max(1, ob[3] - ob[1])
                ocx = (ob[0] + ob[2]) / 2.0
                if oh >= h * 1.8 and abs(ocx - cx) <= oh * 5.5 and abs(ob[3] - box[3]) <= oh * 0.38:
                    neighbors.append(oh)
            if not neighbors:
                continue
            reference = sorted(neighbors)[len(neighbors) // 2]
            if h <= reference * 0.42 and w <= reference * 0.42:
                item["char"] = "," if h > w * 1.45 else "."
                item["conf"] = max(float(item.get("conf", 0.0)), 0.86)

    def _mser_chars(self, gray, stop_event=None, deadline=None):
        h_img, w_img = gray.shape
        detector = cv2.MSER_create()
        detector.setMinArea(3)
        detector.setMaxArea(max(64, int(h_img * w_img * 0.025)))
        _, boxes = detector.detectRegions(gray)
        seen = set()
        chars = []
        for index, raw in enumerate(boxes):
            if index % max(8, int(math.sqrt(len(boxes) + 1))) == 0 and _scan_cancelled(stop_event, deadline):
                break
            x, y, w, h = (int(raw[0]), int(raw[1]), int(raw[2]), int(raw[3]))
            key = (x, y, w, h)
            if key in seen:
                continue
            seen.add(key)
            if h < 2 or h > min(640, h_img * 0.70) or w < 1 or w > min(520, w_img * 0.45):
                continue
            aspect = w / float(max(h, 1))
            if aspect < 0.035 or aspect > 8.0:
                continue
            pad = max(1, int(round(max(h, w) * 0.05)))
            x0, y0 = max(0, x - pad), max(0, y - pad)
            x1, y1 = min(w_img, x + w + pad), min(h_img, y + h + pad)
            crop = gray[y0:y1, x0:x1]
            _, light = cv2.threshold(crop, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
            dark = 255 - light
            choices = [candidate for candidate in (self._classify_mask(light), self._classify_mask(dark)) if candidate is not None]
            if not choices:
                continue
            label, conf = max(choices, key=lambda candidate: candidate[1])
            if label in ".," and h > max(20, int(w * 3.0)):
                continue
            self._add_char(chars, {"char": label, "conf": conf, "box": (x, y, x + w, y + h)})
        return chars

    def detect(self, pil_image, origin, stop_event=None, deadline=None, fast=False):
        if _scan_cancelled(stop_event, deadline):
            return []
        rgb = np.asarray(pil_image.convert("RGB"))
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        h_img, w_img = gray.shape
        chars = []
        masks = self._candidate_masks(gray, fast=fast)
        for mask_index, mask in enumerate(masks):
            if _scan_cancelled(stop_event, deadline):
                break
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            check_stride = max(8, int(math.sqrt(len(contours) + 1)))
            for contour_index, contour in enumerate(contours):
                if contour_index % check_stride == 0 and _scan_cancelled(stop_event, deadline):
                    break
                x, y, w, h = cv2.boundingRect(contour)
                if h < 2 or h > min(640, h_img * 0.70) or w < 1 or w > min(520, w_img * 0.45):
                    continue
                aspect = w / float(max(h, 1))
                if aspect < 0.035 or aspect > 8.0:
                    continue
                area = cv2.contourArea(contour)
                fill_ratio = area / float(max(1, w * h))
                if area < 3 or fill_ratio < 0.018 or (fill_ratio > 0.94 and w * h > 600):
                    continue
                pad = max(1, int(round(max(h, w) * 0.07)))
                x0, y0 = max(0, x - pad), max(0, y - pad)
                x1, y1 = min(w_img, x + w + pad), min(h_img, y + h + pad)
                result = self._classify_mask(mask[y0:y1, x0:x1])
                if result is None:
                    continue
                label, conf = result
                if label in ".," and h > max(20, int(w * 3.0)):
                    continue
                self._add_char(chars, {"char": label, "conf": conf, "box": (x, y, x + w, y + h)})
        if not fast and not _scan_cancelled(stop_event, deadline):
            for item in self._mser_chars(gray, stop_event=stop_event, deadline=deadline):
                self._add_char(chars, item)
        self._repair_punctuation(chars)
        chars.sort(key=lambda char: (char["box"][1], char["box"][0]))
        groups = []
        used = set()
        for i, char in enumerate(chars):
            if _scan_cancelled(stop_event, deadline):
                break
            if i in used:
                continue
            line = [i]
            box = char["box"]
            cy = (box[1] + box[3]) / 2.0
            hh = max(1, box[3] - box[1])
            for j in range(i + 1, len(chars)):
                if j in used:
                    continue
                other = chars[j]["box"]
                hj = max(1, other[3] - other[1])
                cyj = (other[1] + other[3]) / 2.0
                center_close = abs(cyj - cy) <= 0.55 * max(hh, hj)
                baseline_close = abs(other[3] - box[3]) <= 0.42 * max(hh, hj)
                punctuation = char["char"] in "+-.," or chars[j]["char"] in "+-.,"
                ratio_ok = 0.38 <= hj / max(hh, 1) <= 2.7
                if (center_close and (ratio_ok or punctuation)) or (punctuation and baseline_close):
                    line.append(j)
            line.sort(key=lambda idx: chars[idx]["box"][0])
            seq = [line[0]]
            for idx in line[1:]:
                prev = chars[seq[-1]]["box"]
                curr = chars[idx]["box"]
                gap = curr[0] - prev[2]
                typical_h = max(1, prev[3] - prev[1], curr[3] - curr[1])
                if gap <= typical_h * 0.85:
                    seq.append(idx)
            selected = [chars[idx] for idx in seq]
            best = self._best_numeric_span(selected)
            if best is not None:
                _, span, value, text, candidates = best
                gx0 = min(item["box"][0] for item in span)
                gy0 = min(item["box"][1] for item in span)
                gx1 = max(item["box"][2] for item in span)
                gy1 = max(item["box"][3] for item in span)
                confidence = sum(float(item["conf"]) for item in span) / len(span)
                groups.append({
                    "value": value, "value_candidates": candidates, "text": text, "raw_text": text,
                    "display_quantum": str(abs(_decimal_quantum(value))),
                    "box": (gx0 + origin[0], gy0 + origin[1], gx1 + origin[0], gy1 + origin[1]),
                    "chars": [dict(item, box=(item["box"][0] + origin[0], item["box"][1] + origin[1],
                                                   item["box"][2] + origin[0], item["box"][3] + origin[1])) for item in span],
                    "conf": confidence,
                })
                for idx in seq:
                    used.add(idx)
        return self._dedupe_groups(groups)

    def _dedupe_groups(self, groups):
        groups.sort(key=lambda group: (group["conf"], len(group["text"])), reverse=True)
        kept = []
        for group in groups:
            duplicate = False
            for old in kept:
                if self._iou(group["box"], old["box"]) > 0.60:
                    duplicate = True
                    break
            if not duplicate:
                kept.append(group)
        return kept

    def _iou(self, a, b):
        x0 = max(a[0], b[0])
        y0 = max(a[1], b[1])
        x1 = min(a[2], b[2])
        y1 = min(a[3], b[3])
        inter = max(0, x1 - x0) * max(0, y1 - y0)
        area_a = max(1, (a[2] - a[0]) * (a[3] - a[1]))
        area_b = max(1, (b[2] - b[0]) * (b[3] - b[1]))
        return inter / float(area_a + area_b - inter)


def _stable_window_title(title):
    text = str(title or "").strip()
    if not text:
        return ""
    parts = re.split(r"\s+[—–-]\s+", text)
    if len(parts) > 1:
        tail = parts[-1].strip()
        if 1 <= len(tail) <= 48:
            text = tail
    text = re.sub(r"[A-Za-z]:\\[^|<>]*", "<path>", text)
    text = re.sub(r"\b[0-9a-fA-F]{8,}\b", "#", text)
    text = re.sub(r"\d+", "#", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:48]


class LearningController:
    STATE_VERSION = 9
    MAX_STORED_POLICY_BYTES = 98304
    VALID_OPS = ("mouse_abs", "mouse_rel", "mouse_button", "wheel", "key_event", "unicode_text", "replace_number", "wait")
    IDLE_VALID_OPS = ("mouse_abs", "mouse_rel", "mouse_button", "wheel", "key_event", "wait")
    IDLE_SAFE_VKS = (0x09, 0x1B, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28)

    def __init__(self):
        self.state_path = app_dir / "learning.json"
        self.state_backup_path = app_dir / "learning.bak"
        self.state_recovered_from_backup = False
        self._limit_cache = None
        self._limit_cache_until = 0.0
        self.state_io_lock = threading.Lock()
        self.state_dirty = False
        self.last_state_save = time.monotonic()
        self.state_save_interval = float(hardware_profile["save_interval"])
        self._loading_legacy_gain = False
        self.state = self._load_state()
        self._compact_state()
        self.running = False
        self.mode = None
        self.stop_event = threading.Event()
        self.user_interrupt_event = threading.Event()
        self.hook_callback_error_event = threading.Event()
        self.overlay_mode = False
        self.arming = False
        self.arming_ignore_until = 0.0
        self.user_interrupt_pending = False
        self.target = None
        self.original_target = None
        self.current_value = None
        self.target_identity = None
        self.overlays = []
        self.overlay_targets = []
        self.hook_thread_id = 0
        self.input_hooks_ready = threading.Event()
        self.mouse_hook = None
        self.keyboard_hook = None
        self.mouse_proc = None
        self.keyboard_proc = None
        self.held_keys = set()
        self.held_mouse = set()
        self.system_stop_reason = None
        self.lock = threading.Lock()
        self.input_gate_lock = threading.RLock()
        self.input_enabled = False
        self.agent_thread = None
        recent_window = max(8, int(hardware_profile["recent_window"]))
        self.idle_recent_states = deque(maxlen=recent_window)
        self.idle_recent_actions = deque(maxlen=recent_window)
        self.idle_recent_windows = deque(maxlen=recent_window)
        self.last_replace_attempt = None

    def _fresh_state(self):
        return {
            "version": self.STATE_VERSION, "trials": 0, "successes": 0, "unknowns": 0, "best_gain": 0.0,
            "contexts": {}, "success_memory": [], "elite_policies": {},
            "idle_trials": 0, "idle_contexts": {}, "idle_memory": []
        }

    def _storage_limits(self):
        now = time.monotonic()
        if self._limit_cache is not None and now < self._limit_cache_until:
            return self._limit_cache
        try:
            usage = shutil.disk_usage(app_dir)
            total = max(1, int(usage.total))
            free = max(0, int(usage.free))
        except Exception:
            total = max(1, int(hardware_profile["disk_total"]))
            free = max(0, int(hardware_profile["disk_free"]))
        ram_total = max(1, int(hardware_profile["ram_total"]))
        free_ratio = free / float(total)
        reserve = max(int(total * 0.01), int(ram_total * 0.02))
        spendable = max(0, free - reserve)
        soft_budget = min(int(total * 0.00025), int(spendable * 0.0035), int(ram_total * 0.002))
        floor_budget = max(2 << 20, int(min(ram_total, total) * 0.00003))
        ceiling_budget = max(floor_budget, min(64 << 20, int(ram_total * 0.004), max(floor_budget, int(free * 0.01))))
        byte_budget = int(_clamp(max(floor_budget, soft_budget), floor_budget, ceiling_budget))
        scale = math.sqrt(byte_budget / float(max(1, 8 << 20)))
        capacity = max(1.0, float(hardware_profile["capacity"]))
        programs = int(_clamp(round(150 * scale * (0.8 + capacity * 0.08)), 96, 1024))
        contexts = int(_clamp(round(math.sqrt(programs) * 6.0), 36, 192))
        elites = int(_clamp(round(contexts * 0.9), 32, contexts))
        memory = int(_clamp(round(programs * 2.0), 192, 2048))
        history = int(_clamp(round(math.log2(programs + 1.0) * 2.2), 10, 40))
        self.state_save_interval = _clamp(30.0 + (1.0 - free_ratio) * 30.0, 30.0, 60.0)
        limits = {"programs": programs, "contexts": contexts, "elites": elites, "memory": memory, "history": history, "bytes": byte_budget}
        self._limit_cache = limits
        self._limit_cache_until = now + _clamp(self.state_save_interval / 2.0, 15.0, 30.0)
        return limits

    def _collapse_replace_scaffolding(self, program):
        def vk(op, code, down):
            return (op.get("op") == "key_event" and op.get("mode") == "vk"
                    and int(op.get("code", 0)) == code and bool(op.get("down", True)) is down)

        out = list(program)
        index = 0
        while index < len(out):
            if out[index].get("op") != "replace_number":
                index += 1
                continue
            start = index
            if index >= 4 and (vk(out[index - 4], 0x11, True) and vk(out[index - 3], 0x41, True)
                               and vk(out[index - 2], 0x41, False) and vk(out[index - 1], 0x11, False)):
                start = index - 4
                if start >= 2 and (out[start - 2].get("op") == "mouse_button"
                                   and out[start - 2].get("button") == "left" and bool(out[start - 2].get("down"))
                                   and out[start - 1].get("op") == "mouse_button"
                                   and out[start - 1].get("button") == "left" and not bool(out[start - 1].get("down"))):
                    start -= 2
                    if start >= 1 and out[start - 1].get("op") == "mouse_abs":
                        start -= 1
            end = index + 1
            if end + 1 < len(out) and vk(out[end], 0x0D, True) and vk(out[end + 1], 0x0D, False):
                end += 2
            if start != index or end != index + 1:
                replacement = out[index]
                out[start:end] = [replacement]
                index = start + 1
            else:
                index += 1
        return out

    def _normalize_program(self, program, space="target"):
        if not isinstance(program, list) or space not in ("target", "screen"):
            return []
        out = []
        held_mouse = set()
        held_keys = set()
        for source in program:
            if not isinstance(source, dict):
                return []
            kind = source.get("op")
            if kind not in self.VALID_OPS:
                return []
            if held_keys and kind != "key_event":
                return []
            op = {"op": kind}
            try:
                if kind == "mouse_abs":
                    if space == "target":
                        rx, ry = float(source["rx"]), float(source["ry"])
                        if not (math.isfinite(rx) and math.isfinite(ry)):
                            return []
                        op.update(rx=rx, ry=ry)
                    else:
                        sx, sy = float(source["sx"]), float(source["sy"])
                        if not (math.isfinite(sx) and math.isfinite(sy)):
                            return []
                        op.update(sx=_clamp(sx, 0.0, 1.0), sy=_clamp(sy, 0.0, 1.0))
                    duration = max(0.0, float(source.get("duration", 0.0)))
                    if not math.isfinite(duration):
                        return []
                    op["duration"] = duration
                elif kind == "mouse_rel":
                    if space == "target":
                        rdx, rdy = float(source["rdx"]), float(source["rdy"])
                        if not (math.isfinite(rdx) and math.isfinite(rdy)):
                            return []
                        op.update(rdx=rdx, rdy=rdy)
                    else:
                        sdx, sdy = float(source["sdx"]), float(source["sdy"])
                        if not (math.isfinite(sdx) and math.isfinite(sdy)):
                            return []
                        op.update(sdx=sdx, sdy=sdy)
                    duration = max(0.0, float(source.get("duration", 0.0)))
                    if not math.isfinite(duration):
                        return []
                    op["duration"] = duration
                    op["no_coalesce"] = bool(source.get("no_coalesce", False))
                elif kind == "mouse_button":
                    button = str(source.get("button", "left"))
                    if button not in ("left", "right", "middle", "x1", "x2"):
                        return []
                    down = bool(source.get("down", True))
                    if down:
                        if button in held_mouse:
                            return []
                        held_mouse.add(button)
                    else:
                        if button not in held_mouse:
                            return []
                        held_mouse.remove(button)
                    op.update(button=button, down=down)
                elif kind == "wheel":
                    delta = int(source.get("delta", 0))
                    if delta == 0:
                        return []
                    op.update(delta=delta, horizontal=bool(source.get("horizontal", False)))
                elif kind == "key_event":
                    mode = str(source.get("mode", "vk"))
                    if mode not in ("vk", "scan"):
                        return []
                    code = int(source.get("code", 0)) & 0xFFFF
                    if code == 0:
                        return []
                    extended = bool(source.get("extended", False))
                    down = bool(source.get("down", True))
                    identity = (mode, code, extended)
                    if down:
                        if identity in held_keys:
                            return []
                        held_keys.add(identity)
                    else:
                        if identity not in held_keys:
                            return []
                        held_keys.remove(identity)
                    op.update(mode=mode, code=code, down=down, extended=extended)
                elif kind == "unicode_text":
                    text = str(source.get("text", ""))
                    if not text:
                        return []
                    interval = max(0.0, float(source.get("interval", 0.0)))
                    if not math.isfinite(interval):
                        return []
                    op.update(text=text, interval=interval)
                elif kind == "replace_number":
                    delta = abs(_as_decimal(source.get("delta", "1")))
                    interval = max(0.0, float(source.get("interval", 0.0)))
                    if delta <= 0 or not math.isfinite(interval):
                        return []
                    op["delta"] = str(delta.normalize())
                    op["interval"] = interval
                elif kind == "wait":
                    seconds = max(0.0, float(source.get("seconds", 0.0)))
                    if not math.isfinite(seconds):
                        return []
                    op["seconds"] = seconds
            except (KeyError, TypeError, ValueError, OverflowError, InvalidOperation):
                return []
            out.append(op)
        if held_mouse or held_keys:
            return []
        out = self._collapse_replace_scaffolding(out)
        try:
            if len(json.dumps(out, ensure_ascii=False, separators=(",", ":")).encode("utf-8")) > self.MAX_STORED_POLICY_BYTES:
                return []
        except Exception:
            return []
        return out

    def _normalize_idle_program(self, program):
        normalized = self._normalize_program(program, space="screen")
        out = []
        for op in normalized:
            kind = op.get("op")
            if kind not in self.IDLE_VALID_OPS:
                return []
            if kind == "key_event":
                if op.get("mode") != "vk" or int(op.get("code", 0)) not in self.IDLE_SAFE_VKS:
                    return []
                op["extended"] = False
            out.append(op)
        return out

    def _load_idle_record(self, source):
        if not isinstance(source, dict):
            return None
        program = self._normalize_idle_program(source.get("program"))
        fingerprint = str(source.get("fingerprint", ""))
        if not program or not fingerprint:
            return None
        n = max(0, int(source.get("n", 0)))
        return {
            "fingerprint": fingerprint, "program": program, "n": n,
            "q": float(source.get("q", 0.0)), "reward_sum": float(source.get("reward_sum", 0.0)),
            "best_reward": float(source.get("best_reward", -1e9)), "last_seen": max(0, int(source.get("last_seen", 0)))
        }

    def _load_state(self):
        fresh = self._fresh_state()
        try:
            data = None
            source_path = None
            for candidate_path in (self.state_path, self.state_backup_path):
                try:
                    loaded = json.loads(candidate_path.read_text(encoding="utf-8"))
                    if isinstance(loaded, dict):
                        data = loaded
                        source_path = candidate_path
                        break
                except Exception as exc:
                    if candidate_path.exists():
                        _log_runtime("warning", f"learning state load failed for {candidate_path.name}: {exc}")
            if data is None:
                return fresh
            if source_path == self.state_backup_path:
                self.state_recovered_from_backup = True
                _log_runtime("warning", "learning state restored from learning.bak")
            stored_version = int(data.get("version", -1))
            if stored_version not in (5, 6, 7, 8, self.STATE_VERSION):
                return fresh
            self._loading_legacy_gain = stored_version < 8
            fresh["trials"] = max(0, int(data.get("trials", 0)))
            fresh["successes"] = max(0, int(data.get("successes", 0)))
            fresh["unknowns"] = max(0, int(data.get("unknowns", 0)))
            fresh["best_gain"] = max(0.0, float(data.get("best_gain", 0.0)))
            contexts = data.get("contexts", {})
            if isinstance(contexts, dict):
                for key, source_ctx in contexts.items():
                    if not isinstance(source_ctx, dict):
                        continue
                    ctx = {
                        "programs": [], "best_policy": None, "challenger": None,
                        "champion_history": [], "trials": max(0, int(source_ctx.get("trials", 0))),
                        "last_used": max(0, int(source_ctx.get("last_used", 0))),
                        "unknowns": max(0, int(source_ctx.get("unknowns", 0))),
                        "stagnation": max(0, int(source_ctx.get("stagnation", 0))) if stored_version >= 8 else 0,
                    }
                    source_programs = source_ctx.get("programs", [])
                    if isinstance(source_programs, list):
                        for source_rec in source_programs:
                            rec = self._load_record(source_rec)
                            if rec is not None:
                                ctx["programs"].append(rec)
                    best = self._load_policy(source_ctx.get("best_policy"))
                    if best is not None:
                        ctx["best_policy"] = best
                    challenger = self._load_challenger(source_ctx.get("challenger"))
                    if challenger is not None:
                        ctx["challenger"] = challenger
                    history = source_ctx.get("champion_history", [])
                    if isinstance(history, list):
                        for item in history:
                            loaded = self._load_policy(item)
                            if loaded is not None:
                                ctx["champion_history"].append(loaded)
                    fresh["contexts"][str(key)] = ctx
            elites = data.get("elite_policies", {})
            if isinstance(elites, dict):
                for key, source_policy in elites.items():
                    loaded = self._load_policy(source_policy)
                    if loaded is not None:
                        fresh["elite_policies"][str(key)] = loaded
            for key, ctx in fresh["contexts"].items():
                best = ctx.get("best_policy")
                if isinstance(best, dict) and key not in fresh["elite_policies"]:
                    fresh["elite_policies"][key] = json.loads(json.dumps(best))
            memory = data.get("success_memory", [])
            if isinstance(memory, list):
                for source_item in memory:
                    if not isinstance(source_item, dict):
                        continue
                    program = self._normalize_program(source_item.get("program"), space="target")
                    fingerprint = str(source_item.get("fingerprint", ""))
                    if not program or not fingerprint:
                        continue
                    fresh["success_memory"].append({
                        "window": str(source_item.get("window", "")), "fingerprint": fingerprint, "program": program,
                        "n": max(1, int(source_item.get("n", 1))), "reward_sum": float(source_item.get("reward_sum", 0.0)),
                        "gain_sum": 0.0 if self._loading_legacy_gain else float(source_item.get("gain_sum", 0.0)),
                        "best_reward": float(source_item.get("best_reward", 0.0)),
                        "best_gain": 0.0 if self._loading_legacy_gain else float(source_item.get("best_gain", 0.0)),
                        "last_seen": max(0, int(source_item.get("last_seen", 0))),
                    })
            fresh["idle_trials"] = max(0, int(data.get("idle_trials", 0)))
            idle_contexts = data.get("idle_contexts", {})
            if isinstance(idle_contexts, dict):
                for key, source_ctx in idle_contexts.items():
                    if not isinstance(source_ctx, dict):
                        continue
                    ctx = {"programs": [], "trials": max(0, int(source_ctx.get("trials", 0))), "last_used": max(0, int(source_ctx.get("last_used", 0)))}
                    programs = source_ctx.get("programs", [])
                    if isinstance(programs, list):
                        for source_rec in programs:
                            rec = self._load_idle_record(source_rec)
                            if rec is not None:
                                ctx["programs"].append(rec)
                    fresh["idle_contexts"][str(key)] = ctx
            idle_memory = data.get("idle_memory", [])
            if isinstance(idle_memory, list):
                for source_item in idle_memory:
                    if not isinstance(source_item, dict):
                        continue
                    program = self._normalize_idle_program(source_item.get("program"))
                    fingerprint = str(source_item.get("fingerprint", ""))
                    if not program or not fingerprint:
                        continue
                    fresh["idle_memory"].append({
                        "context": str(source_item.get("context", "")), "fingerprint": fingerprint, "program": program,
                        "n": max(1, int(source_item.get("n", 1))), "reward_sum": float(source_item.get("reward_sum", 0.0)),
                        "best_reward": float(source_item.get("best_reward", 0.0)), "last_seen": max(0, int(source_item.get("last_seen", 0))),
                    })
            self._loading_legacy_gain = False
            return fresh
        except Exception:
            self._loading_legacy_gain = False
            return fresh

    def _load_record(self, source):
        if not isinstance(source, dict):
            return None
        program = self._normalize_program(source.get("program"), space="target")
        fingerprint = str(source.get("fingerprint", ""))
        if not program or not fingerprint:
            return None
        n = max(0, int(source.get("n", 0)))
        legacy = bool(self._loading_legacy_gain)
        return {
            "fingerprint": fingerprint, "program": program, "n": n, "wins": max(0, int(source.get("wins", 0))),
            "q": float(source.get("q", 0.0)), "best_gain": 0.0 if legacy else float(source.get("best_gain", 0.0)),
            "best_reward": float(source.get("best_reward", 0.0)), "total_reward": float(source.get("total_reward", 0.0)),
            "total_gain": 0.0 if legacy else float(source.get("total_gain", 0.0)),
            "last_seen": max(0, int(source.get("last_seen", 0))), "blocked_until": max(0, int(source.get("blocked_until", 0))),
        }

    def _load_eval(self, source):
        if not isinstance(source, dict):
            return {"n": 0, "wins": 0, "reward_sum": 0.0, "gain_sum": 0.0}
        return {
            "n": max(0, int(source.get("n", 0))), "wins": max(0, int(source.get("wins", 0))),
            "reward_sum": float(source.get("reward_sum", 0.0)),
            "gain_sum": 0.0 if self._loading_legacy_gain else float(source.get("gain_sum", 0.0)),
        }

    def _load_policy(self, source):
        if not isinstance(source, dict):
            return None
        program = self._normalize_program(source.get("program"), space="target")
        fingerprint = str(source.get("fingerprint", ""))
        if not program or not fingerprint:
            return None
        return {
            "fingerprint": fingerprint, "program": program, "accepted_trial": max(0, int(source.get("accepted_trial", 0))),
            "success_floor": max(0.0, min(1.0, float(source.get("success_floor", 0.0)))),
            "gain_floor": 0.0 if self._loading_legacy_gain else max(0.0, float(source.get("gain_floor", 0.0))),
            "reward_floor": float(source.get("reward_floor", -1e9)), "evidence": self._load_eval(source.get("evidence")),
        }

    def _load_challenger(self, source):
        if not isinstance(source, dict):
            return None
        program = self._normalize_program(source.get("program"), space="target")
        fingerprint = str(source.get("fingerprint", ""))
        if not program or not fingerprint:
            return None
        return {
            "fingerprint": fingerprint, "program": program, "started_trial": max(0, int(source.get("started_trial", 0))),
            "candidate_eval": self._load_eval(source.get("candidate_eval")),
            "incumbent_eval": self._load_eval(source.get("incumbent_eval")),
        }

    def _mark_state_dirty(self, urgent=False):
        self.state_dirty = True
        if urgent:
            self._save_state(force=True)


    def _maybe_save_state(self):
        if self.state_dirty and time.monotonic() - self.last_state_save >= self.state_save_interval:
            self._save_state(force=False)


    def _save_state(self, force=True):
        if not force and not self.state_dirty:
            return
        with self.state_io_lock:
            if not force and not self.state_dirty:
                return
            self.state["version"] = self.STATE_VERSION
            self._sync_elite_policies()
            self._compact_state()
            limits = self._storage_limits()
            payload = self._fit_state_payload(limits["bytes"])
            encoded_size = len(payload.encode("utf-8"))
            if encoded_size > limits["bytes"]:
                raise RuntimeError(f"学习状态超过硬上限：{encoded_size}>{limits['bytes']}")
            tmp = app_dir / "learning.tmp"
            backup_tmp = app_dir / "learning.bak.tmp"
            with open(tmp, "w", encoding="utf-8", newline="") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            if self.state_path.exists() and not self.state_recovered_from_backup:
                try:
                    old_payload = self.state_path.read_bytes()
                    with open(backup_tmp, "wb") as handle:
                        handle.write(old_payload)
                        handle.flush()
                        os.fsync(handle.fileno())
                    os.replace(backup_tmp, self.state_backup_path)
                finally:
                    try:
                        backup_tmp.unlink(missing_ok=True)
                    except Exception:
                        pass
            os.replace(tmp, self.state_path)
            if self.state_recovered_from_backup:
                with open(backup_tmp, "w", encoding="utf-8", newline="") as handle:
                    handle.write(payload)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(backup_tmp, self.state_backup_path)
                self.state_recovered_from_backup = False
            self.state_dirty = False
            self.last_state_save = time.monotonic()

    def _fit_state_payload(self, max_bytes):
        max_bytes = int(max_bytes)
        if max_bytes <= 0:
            raise RuntimeError("学习状态字节上限无效")

        def encode():
            return json.dumps(self.state, ensure_ascii=False, separators=(",", ":"))

        def size(payload):
            return len(payload.encode("utf-8"))

        payload = encode()
        if size(payload) <= max_bytes:
            return payload
        self._compact_state(aggressive=True)
        payload = encode()

        memory = self.state.get("success_memory", [])
        if isinstance(memory, list):
            memory.sort(key=self._memory_quality, reverse=True)
            while memory and size(payload) > max_bytes:
                memory.pop()
                payload = encode()

        idle_memory = self.state.get("idle_memory", [])
        if isinstance(idle_memory, list):
            idle_memory.sort(key=self._idle_memory_quality, reverse=True)
            while idle_memory and size(payload) > max_bytes:
                idle_memory.pop()
                payload = encode()

        idle_contexts = self.state.get("idle_contexts", {})
        while isinstance(idle_contexts, dict) and idle_contexts and size(payload) > max_bytes:
            victim = min(idle_contexts.items(), key=lambda pair: (self._idle_context_quality(pair[1]), int(pair[1].get("last_used", 0))))[0]
            del idle_contexts[victim]
            payload = encode()

        contexts = self.state.get("contexts", {})
        if isinstance(contexts, dict):
            for cap in (64, 32, 16, 8, 4, 2, 1):
                if size(payload) <= max_bytes:
                    break
                for ctx in contexts.values():
                    self._compact_context(ctx, cap, 1)
                payload = encode()
            while contexts and size(payload) > max_bytes:
                victim = min(contexts.items(), key=lambda pair: self._context_rank(pair[1]))[0]
                del contexts[victim]
                payload = encode()

        elites = self.state.get("elite_policies", {})
        while isinstance(elites, dict) and elites and size(payload) > max_bytes:
            victim = min(elites.items(), key=lambda pair: self._elite_rank(pair[0], pair[1]))[0]
            del elites[victim]
            payload = encode()

        if size(payload) > max_bytes:
            for field in ("success_memory", "idle_memory"):
                value = self.state.get(field)
                if isinstance(value, list):
                    value.clear()
            for field in ("contexts", "idle_contexts", "elite_policies"):
                value = self.state.get(field)
                if isinstance(value, dict):
                    value.clear()
            payload = encode()

        if size(payload) > max_bytes:
            preserved = {
                "version": self.STATE_VERSION,
                "trials": max(0, int(self.state.get("trials", 0))),
                "successes": max(0, int(self.state.get("successes", 0))),
                "unknowns": max(0, int(self.state.get("unknowns", 0))),
                "best_gain": float(self.state.get("best_gain", 0.0)),
                "contexts": {}, "success_memory": [], "elite_policies": {},
                "idle_trials": max(0, int(self.state.get("idle_trials", 0))),
                "idle_contexts": {}, "idle_memory": []
            }
            self.state.clear()
            self.state.update(preserved)
            payload = encode()

        if size(payload) > max_bytes:
            raise RuntimeError("学习状态最小载荷仍超过硬字节上限")
        return payload

    def _policy_fingerprint(self, program, target):
        canonical = []
        for op in program:
            kind = op.get("op")
            if kind == "mouse_abs":
                canonical.append((kind, round(float(op.get("rx", 0.0)) * 4.0) / 4.0,
                                  round(float(op.get("ry", 0.0)) * 4.0) / 4.0,
                                  self._time_bucket(op.get("duration", 0.0))))
            elif kind == "mouse_rel":
                canonical.append((kind, round(float(op.get("rdx", 0.0)) * 4.0) / 4.0,
                                  round(float(op.get("rdy", 0.0)) * 4.0) / 4.0,
                                  self._time_bucket(op.get("duration", 0.0)), bool(op.get("no_coalesce", False))))
            elif kind == "mouse_button":
                canonical.append((kind, str(op.get("button", "left")), bool(op.get("down", True))))
            elif kind == "wheel":
                canonical.append((kind, int(round(float(op.get("delta", 0)) / 120.0)), bool(op.get("horizontal", False))))
            elif kind == "key_event":
                canonical.append((kind, str(op.get("mode", "vk")), int(op.get("code", 0)) & 0xFFFF,
                                  bool(op.get("down", True)), bool(op.get("extended", False))))
            elif kind == "unicode_text":
                text = str(op.get("text", ""))
                number = recognizer._parse_number_text(text) if recognizer is not None else None
                if number is not None:
                    number = float(number)
                    text_key = ("numeric", self._magnitude_bucket(number), 1 if number >= 0 else -1)
                else:
                    text_key = ("text", hashlib.blake2b(text.encode("utf-8", "replace"), digest_size=6).hexdigest())
                canonical.append((kind, text_key, self._time_bucket(op.get("interval", 0.0))))
            elif kind == "replace_number":
                delta = max(1e-12, abs(float(op.get("delta", 1.0))))
                canonical.append((kind, self._magnitude_bucket(delta), self._time_bucket(op.get("interval", 0.0))))
            elif kind == "wait":
                canonical.append((kind, self._time_bucket(op.get("seconds", 0.0))))
        raw = json.dumps(canonical, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return hashlib.blake2b(raw, digest_size=12).hexdigest()

    def _time_bucket(self, value):
        seconds = max(0.0, float(value))
        return int(round(math.log1p(seconds) * 12.0))

    def _magnitude_bucket(self, value):
        magnitude = abs(float(value))
        if magnitude < 1e-12:
            return 0
        return int(round(math.log10(magnitude) * 8.0))

    def _record_quality(self, rec):
        n = max(1, int(rec.get("n", 0)))
        rate = int(rec.get("wins", 0)) / n
        gain = float(rec.get("total_gain", 0.0)) / n
        reward = float(rec.get("total_reward", 0.0)) / n
        confidence = 1.0 - math.exp(-n / 8.0)
        weak_penalty = 1.0 if n >= 8 and rate < 0.05 and gain <= 0.0 and reward < -0.1 else 0.0
        return rate * 4.0 + math.log1p(max(0.0, gain)) * 0.55 + reward * 0.65 + float(rec.get("q", 0.0)) * 0.35 + confidence * 0.20 - weak_penalty

    def _memory_quality(self, item):
        n = max(1, int(item.get("n", 1)))
        return (float(item.get("gain_sum", 0.0)) / n, float(item.get("reward_sum", 0.0)) / n, math.log1p(n), int(item.get("last_seen", 0)))

    def _compact_context(self, ctx, program_cap, history_cap):
        protected = set()
        best = ctx.get("best_policy")
        challenger = ctx.get("challenger")
        if isinstance(best, dict):
            protected.add(best.get("fingerprint"))
        if isinstance(challenger, dict):
            protected.add(challenger.get("fingerprint"))
        records = list(ctx.get("programs", []))
        records.sort(
            key=lambda rec: (
                rec.get("fingerprint") in protected,
                int(rec.get("wins", 0)) > 0,
                self._record_quality(rec),
                int(rec.get("last_seen", 0)),
            ),
            reverse=True,
        )
        ctx["programs"] = records[:max(1, int(program_cap))]
        history = list(ctx.get("champion_history", []))
        ctx["champion_history"] = history[-max(1, int(history_cap)):]

    def _context_quality(self, ctx):
        best = ctx.get("best_policy")
        best_score = 0.0
        if isinstance(best, dict):
            best_score = float(best.get("success_floor", 0.0)) * 5.0 + math.log1p(float(best.get("gain_floor", 0.0)))
        return best_score + math.log1p(max(0, int(ctx.get("trials", 0)))) * 0.08

    def _context_rank(self, ctx):
        return (self._context_quality(ctx), int(ctx.get("last_used", 0)))

    def _idle_record_quality(self, rec):
        n = max(1, int(rec.get("n", 0)))
        avg_reward = float(rec.get("reward_sum", 0.0)) / n
        confidence = 1.0 - math.exp(-n / 6.0)
        return avg_reward * 0.70 + float(rec.get("q", 0.0)) * 0.30 + confidence * 0.05

    def _idle_memory_quality(self, item):
        n = max(1, int(item.get("n", 1)))
        return float(item.get("reward_sum", 0.0)) / n + math.log1p(n) * 0.02 + int(item.get("last_seen", 0)) * 1e-9

    def _compact_idle_context(self, ctx, program_cap):
        records = list(ctx.get("programs", []))
        records.sort(key=lambda rec: (self._idle_record_quality(rec), int(rec.get("last_seen", 0))), reverse=True)
        ctx["programs"] = records[:max(1, int(program_cap))]

    def _idle_context_quality(self, ctx):
        records = ctx.get("programs", [])
        best = max((self._idle_record_quality(rec) for rec in records), default=0.0)
        return best + math.log1p(max(0, int(ctx.get("trials", 0)))) * 0.05 + int(ctx.get("last_used", 0)) * 1e-9

    def _compact_state(self, aggressive=False):
        if not hasattr(self, "state"):
            return
        limits = self._storage_limits()
        program_cap = max(128, limits["programs"] // (2 if aggressive else 1))
        history_cap = max(6, limits["history"] // (2 if aggressive else 1))
        for ctx in self.state.get("contexts", {}).values():
            if isinstance(ctx, dict):
                self._compact_context(ctx, program_cap, history_cap)
        contexts = self.state.get("contexts", {})
        context_cap = max(24, limits["contexts"] // (2 if aggressive else 1))
        if isinstance(contexts, dict) and len(contexts) > context_cap:
            ranked = sorted(contexts.items(), key=lambda pair: self._context_rank(pair[1]), reverse=True)
            self.state["contexts"] = dict(ranked[:context_cap])
        elite_cap = max(24, limits["elites"] // (2 if aggressive else 1))
        self._trim_elite_policies(elite_cap)
        memory = self.state.get("success_memory", [])
        if isinstance(memory, list):
            memory.sort(key=self._memory_quality, reverse=True)
            memory_cap = max(128, limits["memory"] // (2 if aggressive else 1))
            del memory[memory_cap:]
        idle_program_cap = max(48, limits["programs"] // (4 if aggressive else 2))
        for ctx in self.state.get("idle_contexts", {}).values():
            if isinstance(ctx, dict):
                self._compact_idle_context(ctx, idle_program_cap)
        idle_contexts = self.state.get("idle_contexts", {})
        idle_context_cap = max(16, limits["contexts"] // (3 if aggressive else 2))
        if isinstance(idle_contexts, dict) and len(idle_contexts) > idle_context_cap:
            ranked = sorted(idle_contexts.items(), key=lambda pair: self._idle_context_quality(pair[1]), reverse=True)
            self.state["idle_contexts"] = dict(ranked[:idle_context_cap])
        idle_memory = self.state.get("idle_memory", [])
        if isinstance(idle_memory, list):
            idle_memory.sort(key=self._idle_memory_quality, reverse=True)
            idle_memory_cap = max(64, limits["memory"] // (4 if aggressive else 2))
            del idle_memory[idle_memory_cap:]

    def _eval_update(self, stats, reward, gain):
        stats["n"] = int(stats.get("n", 0)) + 1
        if reward > 0:
            stats["wins"] = int(stats.get("wins", 0)) + 1
        stats["reward_sum"] = float(stats.get("reward_sum", 0.0)) + float(reward)
        stats["gain_sum"] = float(stats.get("gain_sum", 0.0)) + float(gain)

    def _wilson_lower(self, wins, n, z=1.2815515655446004):
        n = max(0, int(n))
        if n == 0:
            return 0.0
        p = max(0.0, min(1.0, float(wins) / n))
        denom = 1.0 + z * z / n
        center = p + z * z / (2.0 * n)
        margin = z * math.sqrt((p * (1.0 - p) + z * z / (4.0 * n)) / n)
        return max(0.0, (center - margin) / denom)

    def _policy_from_evidence(self, program, fingerprint, evidence):
        n = max(1, int(evidence.get("n", 0)))
        wins = max(0, int(evidence.get("wins", 0)))
        avg_gain = float(evidence.get("gain_sum", 0.0)) / n
        avg_reward = float(evidence.get("reward_sum", 0.0)) / n
        return {
            "fingerprint": fingerprint, "program": json.loads(json.dumps(program)),
            "accepted_trial": int(self.state.get("trials", 0)),
            "success_floor": self._wilson_lower(wins, n),
            "gain_floor": max(0.0, avg_gain * 0.92), "reward_floor": avg_reward - 0.08,
            "evidence": dict(evidence)
        }

    def _elite_quality(self, policy):
        if not isinstance(policy, dict):
            return (-1.0, -1.0, -1e9, -1)
        return (
            float(policy.get("success_floor", 0.0)),
            float(policy.get("gain_floor", 0.0)),
            float(policy.get("reward_floor", -1e9)),
            int(policy.get("accepted_trial", 0)),
        )

    def _policy_is_not_worse(self, candidate, incumbent):
        if not isinstance(candidate, dict):
            return False
        if not isinstance(incumbent, dict):
            return True
        return (
            float(candidate.get("success_floor", 0.0)) + 1e-12 >= float(incumbent.get("success_floor", 0.0))
            and float(candidate.get("gain_floor", 0.0)) + 1e-12 >= float(incumbent.get("gain_floor", 0.0))
            and float(candidate.get("reward_floor", -1e9)) + 1e-12 >= float(incumbent.get("reward_floor", -1e9))
        )

    def _policy_is_strict_upgrade(self, candidate, incumbent):
        if not self._policy_is_not_worse(candidate, incumbent):
            return False
        if not isinstance(incumbent, dict):
            return True
        return (
            float(candidate.get("success_floor", 0.0)) > float(incumbent.get("success_floor", 0.0)) + 1e-9
            or float(candidate.get("gain_floor", 0.0)) > float(incumbent.get("gain_floor", 0.0)) + 1e-9
            or float(candidate.get("reward_floor", -1e9)) > float(incumbent.get("reward_floor", -1e9)) + 1e-9
        )

    def _elite_rank(self, key, policy):
        ctx = self.state.get("contexts", {}).get(str(key))
        if isinstance(ctx, dict):
            recent = int(ctx.get("last_used", 0))
        else:
            recent = int(policy.get("accepted_trial", 0)) if isinstance(policy, dict) else 0
        return (self._elite_quality(policy), recent)

    def _trim_elite_policies(self, cap=None):
        elites = self.state.setdefault("elite_policies", {})
        if not isinstance(elites, dict):
            self.state["elite_policies"] = {}
            return
        if cap is None:
            cap = self._storage_limits()["elites"]
        cap = max(1, int(cap))
        if len(elites) <= cap:
            return
        ranked = sorted(elites.items(), key=lambda pair: self._elite_rank(pair[0], pair[1]), reverse=True)
        self.state["elite_policies"] = dict(ranked[:cap])

    def _store_elite_policy(self, key, policy):
        if not isinstance(policy, dict):
            return
        elites = self.state.setdefault("elite_policies", {})
        current = elites.get(str(key))
        if current is None or self._policy_is_strict_upgrade(policy, current):
            elites[str(key)] = json.loads(json.dumps(policy))
        self._trim_elite_policies()

    def _sync_elite_policies(self):
        elites = self.state.setdefault("elite_policies", {})
        for key, ctx in self.state.get("contexts", {}).items():
            if not isinstance(ctx, dict):
                continue
            best = ctx.get("best_policy")
            elite = elites.get(str(key))
            if self._policy_is_strict_upgrade(elite, best):
                ctx["best_policy"] = json.loads(json.dumps(elite))
                ctx["challenger"] = None
            elif self._policy_is_strict_upgrade(best, elite):
                elites[str(key)] = json.loads(json.dumps(best))
        self._trim_elite_policies()

    def clear_user_interrupt(self):
        self.user_interrupt_event.clear()
        with self.lock:
            self.user_interrupt_pending = False

    def _clear_target_tracking(self):
        self.target = None
        self.original_target = None
        self.current_value = None
        self.target_identity = None
        self.last_replace_attempt = None

    def handle_runtime_error(self, exc, context="运行过程"):
        detail = str(exc).strip() or exc.__class__.__name__
        _log_runtime("error", f"{context}: {detail}")
        reason = f"{context}出错：{detail}。AI已停止。可重新选择模式。"
        with self.input_gate_lock:
            self.input_enabled = False
            self.stop_event.set()
        with self.lock:
            self.user_interrupt_pending = False
            self.system_stop_reason = reason
            self.overlay_mode = False
        self._clear_target_tracking()
        self._release_all_inputs()
        if app_alive.is_set():
            post_ui("runtime_error", reason)
        return reason

    def select_target(self, target):
        self.clear_user_interrupt()
        chosen = dict(target)
        self.target = chosen
        self.original_target = dict(chosen)
        self.current_value = chosen["value"]
        self.target_identity = {
            "initial_box": list(chosen["box"]),
            "window": None,
            "context": None,
        }

    def _cursor_pos(self):
        pt = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        return (pt.x, pt.y)

    def _window_signature(self, target):
        x0, y0, x1, y1 = target["box"]
        pt = wintypes.POINT(int((x0 + x1) / 2), int((y0 + y1) / 2))
        hwnd = user32.WindowFromPoint(pt)
        if hwnd:
            root_hwnd = user32.GetAncestor(hwnd, GA_ROOT)
            if root_hwnd:
                hwnd = root_hwnd
        if not hwnd:
            hwnd = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(hwnd)
        title_buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
        class_buf = ctypes.create_unicode_buffer(128)
        user32.GetClassNameW(hwnd, class_buf, len(class_buf))
        title = _stable_window_title(title_buf.value)
        cls = class_buf.value.strip()[:48]
        return f"{cls}|{title}"

    def _target_window_info(self, target):
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        x0, y0, x1, y1 = target["box"]
        pt = wintypes.POINT(int((x0 + x1) / 2), int((y0 + y1) / 2))
        hwnd = user32.WindowFromPoint(pt)
        if hwnd:
            root_hwnd = user32.GetAncestor(hwnd, GA_ROOT)
            if root_hwnd:
                hwnd = root_hwnd
        rect = wintypes.RECT()
        if not hwnd or not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            rect.left, rect.top, rect.right, rect.bottom = vx0, vy0, vx1 + 1, vy1 + 1
            hwnd = None
        dpi = 96
        if hwnd:
            try:
                dpi = max(48, int(user32.GetDpiForWindow(hwnd) or 96))
            except Exception:
                dpi = 96
        return hwnd, rect, dpi

    def _visual_context_token(self):
        stored = (self.target_identity or {}).get("context")
        if stored is None:
            return "v0"
        try:
            arr = np.asarray(stored, dtype=np.float32).reshape(24, 30)
            small = cv2.resize(arr, (8, 6), interpolation=cv2.INTER_AREA)
            median = float(np.median(small))
            bits = 0
            for value in small.reshape(-1):
                bits = (bits << 1) | int(float(value) >= median)
            return f"v{bits:012x}"
        except Exception:
            return "v0"

    def _context_key(self, target):
        x0, y0, x1, y1 = target["box"]
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        _, rect, dpi = self._target_window_info(target)
        ww = max(1.0, float(rect.right - rect.left))
        wh = max(1.0, float(rect.bottom - rect.top))
        locx = int(_clamp(((cx - rect.left) / ww) * 12.0, 0.0, 11.999))
        locy = int(_clamp(((cy - rect.top) / wh) * 12.0, 0.0, 11.999))
        logical_h = max(1.0, (y1 - y0) * 96.0 / max(48.0, float(dpi)))
        logical_wh = max(1.0, wh * 96.0 / max(48.0, float(dpi)))
        size_bucket = int(_clamp(round((logical_h / logical_wh) * 120.0), 0, 99))
        signature = self._window_signature(target)
        digits = len(str(self.original_target.get("raw_text", self.original_target.get("text", self.original_target["value"]))))
        return f"{signature}|w{locx},{locy}|d{digits}|s{size_bucket}|{self._visual_context_token()}"

    def _context_descriptor(self, image, origin, box):
        x0, y0, x1, y1 = box
        bw = max(6, x1 - x0)
        bh = max(6, y1 - y0)
        margin_x = max(28, int(bw * 3.4))
        margin_y = max(24, int(bh * 2.8))
        ix0 = max(0, int(x0 - margin_x - origin[0]))
        iy0 = max(0, int(y0 - margin_y - origin[1]))
        ix1 = min(image.width, int(x1 + margin_x - origin[0]))
        iy1 = min(image.height, int(y1 + margin_y - origin[1]))
        if ix1 - ix0 < 12 or iy1 - iy0 < 12:
            return None
        gray = np.asarray(image.crop((ix0, iy0, ix1, iy1)).convert("L"), dtype=np.uint8).copy()
        tx0 = max(0, int(x0 - origin[0] - ix0 - bw * 0.25))
        ty0 = max(0, int(y0 - origin[1] - iy0 - bh * 0.25))
        tx1 = min(gray.shape[1], int(x1 - origin[0] - ix0 + bw * 0.25))
        ty1 = min(gray.shape[0], int(y1 - origin[1] - iy0 + bh * 0.25))
        fill = int(np.median(gray))
        gray[ty0:ty1, tx0:tx1] = fill
        small = cv2.resize(gray, (30, 24), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
        mean = float(small.mean())
        std = float(small.std())
        if std > 0.03:
            small = (small - mean) / std
            small = np.clip((small + 3.0) / 6.0, 0.0, 1.0)
        return small.reshape(-1).tolist()

    def _ensure_identity_context(self, image, origin):
        if self.target_identity is None or self.target is None:
            return
        if not self.target_identity.get("window"):
            self.target_identity["window"] = self._window_signature(self.target)
        if self.target_identity.get("context") is None:
            desc = self._context_descriptor(image, origin, self.target["box"])
            if desc is not None:
                self.target_identity["context"] = desc

    def _match_target(self, numbers, image, origin, wide=False):
        if not numbers or self.target is None or self.original_target is None:
            return None
        old_box = self.target["box"]
        ox = (old_box[0] + old_box[2]) / 2.0
        oy = (old_box[1] + old_box[3]) / 2.0
        oh = max(1.0, old_box[3] - old_box[1])
        ident = self.target_identity or {}
        initial_box = ident.get("initial_box", old_box)
        ix = (initial_box[0] + initial_box[2]) / 2.0
        iy = (initial_box[1] + initial_box[3]) / 2.0
        stored_context = ident.get("context")
        stored_window = ident.get("window", "")
        ranked = []
        for source in numbers:
            n = dict(source)
            candidates = source.get("value_candidates")
            if self.current_value is not None and isinstance(candidates, list) and candidates:
                n["value"] = recognizer._parse_number_text(source.get("text", ""), reference=self.current_value)
                if n["value"] is None:
                    n["value"] = source["value"]
            b = n["box"]
            cx = (b[0] + b[2]) / 2.0
            cy = (b[1] + b[3]) / 2.0
            nh = max(1.0, b[3] - b[1])
            dist = math.hypot(cx - ox, cy - oy) / oh
            overlap = recognizer._iou(b, old_box)
            size_penalty = abs(math.log(nh / oh))
            if wide:
                score = min(dist, 10.0) * 0.22 + size_penalty * 0.9 - overlap * 1.7
                score += math.hypot(cx - ix, cy - iy) / max(oh, 12.0) * 0.018
                if self.current_value is not None and _same_ocr_number(n, self.target):
                    score -= 0.35
            else:
                score = dist * 0.72 + size_penalty * 1.15 - overlap * 2.6
            if stored_window:
                candidate_window = self._window_signature(n)
                if candidate_window != stored_window:
                    score += 1.8 if wide else 2.8
            if stored_context is None and not _same_ocr_number(n, self.original_target):
                score += 1.35
            if stored_context is not None:
                desc = self._context_descriptor(image, origin, b)
                if desc is None:
                    score += 1.0
                else:
                    a = np.asarray(stored_context, dtype=np.float32)
                    d = np.asarray(desc, dtype=np.float32)
                    mse = float(np.mean((a - d) ** 2))
                    score += mse * (7.0 if wide else 8.5)
            ranked.append((score, n))
        ranked.sort(key=lambda pair: pair[0])
        if not ranked:
            return None
        threshold = 5.2 if wide else 3.5
        return ranked[0][1] if ranked[0][0] <= threshold else None

    def _screen_bounds(self):
        vx, vy = virtual_origin()
        return vx, vy, vx + max(1, user32.GetSystemMetrics(78)) - 1, vy + max(1, user32.GetSystemMetrics(79)) - 1

    def _exploration_level(self, ctx):
        trials = max(1, int(ctx.get("trials", 0)))
        stagnation = max(0, int(ctx.get("stagnation", 0)))
        required = max(3, int(round(math.log2(trials + 3.0))))
        return min(3, stagnation // required)


    def _window_bounds_for_target(self, target):
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        _, rect, _ = self._target_window_info(target)
        return max(vx0, rect.left), max(vy0, rect.top), min(vx1, rect.right - 1), min(vy1, rect.bottom - 1)


    def _point_to_target_relative(self, x, y, target):
        x0, y0, x1, y1 = target["box"]
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        h = max(1.0, y1 - y0)
        return (float(x) - cx) / h, (float(y) - cy) / h


    def _random_point(self, target, level):
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        x0, y0, x1, y1 = target["box"]
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        h = max(1.0, y1 - y0)
        level = int(_clamp(level, 0, 3))
        if level == 0:
            x = random.uniform(x0, max(x0 + 1, x1))
            y = random.uniform(y0, max(y0 + 1, y1))
        elif level == 1:
            radius = random.uniform(1.0, 3.0) * h
            angle = random.uniform(0.0, math.tau)
            x = cx + math.cos(angle) * radius + random.gauss(0.0, h * 0.35)
            y = cy + math.sin(angle) * radius + random.gauss(0.0, h * 0.35)
        elif level == 2:
            wx0, wy0, wx1, wy1 = self._window_bounds_for_target(target)
            x = random.uniform(wx0, max(wx0 + 1, wx1))
            y = random.uniform(wy0, max(wy0 + 1, wy1))
        else:
            wx0, wy0, wx1, wy1 = self._window_bounds_for_target(target)
            edge_bias = random.random() < 0.35
            if edge_bias:
                x = random.choice((random.uniform(wx0, wx0 + (wx1 - wx0) * 0.22), random.uniform(wx1 - (wx1 - wx0) * 0.22, wx1)))
                y = random.uniform(wy0, wy1)
            else:
                x = random.uniform(wx0, max(wx0 + 1, wx1))
                y = random.uniform(wy0, max(wy0 + 1, wy1))
        x = _clamp(x, vx0, vx1)
        y = _clamp(y, vy0, vy1)
        return self._point_to_target_relative(x, y, target)


    def _random_duration(self, mean):
        return random.expovariate(1.0 / max(1e-6, float(mean)))

    def _random_count(self, stop_probability=0.68):
        count = 1
        while random.random() > stop_probability:
            count += 1
        return count

    def _random_text(self):
        digits = "0123456789"
        count = max(1, self._random_count(0.72))
        body = "".join(random.choice(digits) for _ in range(count))
        if random.random() < 0.24:
            separator = recognizer.locale_decimal if recognizer is not None and recognizer.locale_decimal in (".", ",") else "."
            tail = "".join(random.choice(digits) for _ in range(max(1, min(4, self._random_count(0.68)))))
            body += separator + tail
        if random.random() < 0.14:
            exponent = random.randint(-max(1, count), max(2, count * 2))
            body += random.choice(("e", "E")) + ("+" if exponent >= 0 and random.random() < 0.5 else "") + str(exponent)
        return body


    def _grow_key_tap(self):
        priority = (0x26, 0x28, 0x6B, 0x6D, 0xBB, 0xBD)
        code = random.choice(priority)
        return [
            {"op": "key_event", "mode": "vk", "code": code, "down": True, "extended": False},
            {"op": "key_event", "mode": "vk", "code": code, "down": False, "extended": False},
        ]


    def _random_operation(self, target, level):
        kinds = ("move", "click", "mouse_rel", "wheel", "key", "replace_number", "wait")
        locality = 1.0 + max(0, 2 - int(level)) * 0.25
        weights = (12 * locality, 17 * locality, 4, 15, 14, 20, 8)
        kind = random.choices(kinds, weights=weights, k=1)[0]
        if kind in ("move", "click"):
            rx, ry = self._random_point(target, level)
            move = {"op": "mouse_abs", "rx": rx, "ry": ry, "duration": self._random_duration(0.18 if kind == "move" else 0.12)}
            if kind == "move":
                return [move]
            return [
                move,
                {"op": "mouse_button", "button": "left", "down": True},
                {"op": "wait", "seconds": self._random_duration(0.04)},
                {"op": "mouse_button", "button": "left", "down": False},
            ]
        if kind == "mouse_rel":
            spread = 0.55 + 0.85 * int(level)
            return [{"op": "mouse_rel", "rdx": random.gauss(0.0, spread), "rdy": random.gauss(0.0, spread),
                     "duration": self._random_duration(0.14), "no_coalesce": False}]
        if kind == "wheel":
            steps = random.choice((-3, -2, -1, 1, 2, 3))
            return [{"op": "wheel", "delta": steps * 120, "horizontal": random.random() < 0.08}]
        if kind == "key":
            return self._grow_key_tap()
        if kind == "replace_number":
            current = abs(_as_decimal(self.current_value or 0))
            exponent = current.adjusted() if current else 0
            deltas = (Decimal(1).scaleb(exponent - 2), Decimal(1).scaleb(exponent - 1), Decimal(1),
                      Decimal(1).scaleb(exponent), Decimal(1).scaleb(exponent + 1))
            delta = abs(random.choice(deltas))
            return [{"op": "replace_number", "delta": str(delta.normalize()), "interval": self._random_duration(0.02)}]
        return [{"op": "wait", "seconds": self._random_duration(0.20)}]

    def _random_program(self, target, level=0):
        if random.random() < 0.34:
            current = abs(_as_decimal(self.current_value or 0))
            exponent = current.adjusted() if current else 0
            delta = abs(random.choice((Decimal(1), Decimal(1).scaleb(exponent - 1),
                                       Decimal(1).scaleb(exponent), Decimal(1).scaleb(exponent + 1))))
            return [{"op": "replace_number", "delta": str(delta.normalize()), "interval": self._random_duration(0.02)}]
        chunks = max(1, self._random_count(0.64))
        program = []
        for _ in range(chunks):
            program.extend(self._random_operation(target, level))
        normalized = self._normalize_program(program, space="target")
        return normalized if normalized else self._grow_key_tap()

    def _mutate_program(self, program, target, level=0):
        mutated = self._normalize_program(json.loads(json.dumps(program)), space="target")
        if not mutated or random.random() < 0.16:
            return self._random_program(target, level)
        mode = random.choice(("tweak", "tweak", "insert", "replace_all"))
        if mode == "replace_all":
            return self._random_program(target, level)
        if mode == "insert":
            chunk = self._random_operation(target, level)
            index = random.randrange(len(mutated) + 1)
            candidate = mutated[:index] + chunk + mutated[index:]
            normalized = self._normalize_program(candidate, space="target")
            return normalized if normalized else mutated
        index = random.randrange(len(mutated))
        op = mutated[index]
        kind = op.get("op")
        factor = math.exp(random.gauss(0.0, 0.35))
        if kind == "mouse_abs":
            spread = 0.25 + 0.45 * int(level)
            op["rx"] = float(op.get("rx", 0.0)) + random.gauss(0.0, spread)
            op["ry"] = float(op.get("ry", 0.0)) + random.gauss(0.0, spread)
            op["duration"] = max(0.0, float(op.get("duration", 0.0)) * factor)
        elif kind == "mouse_rel":
            spread = 0.25 + 0.45 * int(level)
            op["rdx"] = float(op.get("rdx", 0.0)) + random.gauss(0.0, spread)
            op["rdy"] = float(op.get("rdy", 0.0)) + random.gauss(0.0, spread)
            op["duration"] = max(0.0, float(op.get("duration", 0.0)) * factor)
        elif kind == "mouse_button":
            old_button = str(op.get("button", "left"))
            new_button = random.choice(("left", "right", "middle"))
            for item in mutated:
                if item.get("op") == "mouse_button" and str(item.get("button", "left")) == old_button:
                    item["button"] = new_button
        elif kind == "wheel":
            steps = int(round(float(op.get("delta", 120)) / 120.0)) + random.choice((-2, -1, 1, 2))
            op["delta"] = (steps or random.choice((-1, 1))) * 120
        elif kind == "key_event":
            old_identity = (str(op.get("mode", "vk")), int(op.get("code", 0)), bool(op.get("extended", False)))
            replacement = self._grow_key_tap()[0]
            for item in mutated:
                if item.get("op") == "key_event" and (str(item.get("mode", "vk")), int(item.get("code", 0)), bool(item.get("extended", False))) == old_identity:
                    item["mode"] = replacement["mode"]
                    item["code"] = replacement["code"]
                    item["extended"] = replacement["extended"]
        elif kind == "unicode_text":
            op["text"] = self._random_text()
            op["interval"] = max(0.0, float(op.get("interval", 0.0)) * factor)
        elif kind == "replace_number":
            op["delta"] = max(1e-6, abs(float(op.get("delta", 1.0))) * factor)
            op["interval"] = max(0.0, float(op.get("interval", 0.0)) * factor)
        elif kind == "wait":
            op["seconds"] = max(0.0, float(op.get("seconds", 0.0)) * factor)
        normalized = self._normalize_program(mutated, space="target")
        return normalized if normalized else self._random_program(target, level)

    def _ctx(self, key):
        contexts = self.state["contexts"]
        if key not in contexts:
            limits = self._storage_limits()
            if len(contexts) >= limits["contexts"]:
                victim = min(contexts.items(), key=lambda pair: self._context_rank(pair[1]))[0]
                del contexts[victim]
            elite = self.state.get("elite_policies", {}).get(str(key))
            contexts[key] = {
                "programs": [], "best_policy": json.loads(json.dumps(elite)) if isinstance(elite, dict) else None,
                "challenger": None, "champion_history": [], "trials": 0, "stagnation": 0,
                "last_used": int(self.state.get("trials", 0)),
            }
        ctx = contexts[key]
        ctx.setdefault("stagnation", 0)
        ctx["last_used"] = int(self.state.get("trials", 0))
        return ctx

    def _find_record(self, ctx, fingerprint):
        for rec in ctx.get("programs", []):
            if rec.get("fingerprint") == fingerprint:
                return rec
        return None

    def _maybe_seed_best_policy(self, key, ctx, rec):
        if ctx.get("best_policy") is not None:
            return
        n = int(rec.get("n", 0))
        wins = int(rec.get("wins", 0))
        if n < 8 or wins < 3:
            return
        evidence = {"n": n, "wins": wins, "reward_sum": float(rec.get("total_reward", 0.0)), "gain_sum": float(rec.get("total_gain", 0.0))}
        ctx["best_policy"] = self._policy_from_evidence(rec["program"], rec["fingerprint"], evidence)
        self._store_elite_policy(key, ctx["best_policy"])
        self._mark_state_dirty(urgent=True)

    def _maybe_nominate_challenger(self, ctx, rec):
        best = ctx.get("best_policy")
        if best is None or ctx.get("challenger") is not None:
            return
        if rec.get("fingerprint") == best.get("fingerprint"):
            return
        if int(rec.get("blocked_until", 0)) > int(ctx.get("trials", 0)):
            return
        n = int(rec.get("n", 0))
        wins = int(rec.get("wins", 0))
        if n < 8 or wins < 3:
            return
        evidence = {"n": n, "wins": wins, "reward_sum": float(rec.get("total_reward", 0.0)), "gain_sum": float(rec.get("total_gain", 0.0))}
        candidate = self._policy_from_evidence(rec["program"], rec["fingerprint"], evidence)
        if not self._policy_is_strict_upgrade(candidate, best):
            return
        ctx["challenger"] = {
            "fingerprint": rec["fingerprint"], "program": json.loads(json.dumps(rec["program"])),
            "started_trial": int(ctx.get("trials", 0)),
            "candidate_eval": {"n": 0, "wins": 0, "reward_sum": 0.0, "gain_sum": 0.0},
            "incumbent_eval": {"n": 0, "wins": 0, "reward_sum": 0.0, "gain_sum": 0.0}
        }

    def _resolve_challenger(self, key, ctx):
        challenger = ctx.get("challenger")
        best = ctx.get("best_policy")
        if challenger is None or best is None:
            return
        cand = challenger["candidate_eval"]
        inc = challenger["incumbent_eval"]
        cand_n = max(0, int(cand.get("n", 0)))
        inc_n = max(0, int(inc.get("n", 0)))
        if cand_n < 16 or inc_n < 16:
            return
        cand_success = self._wilson_lower(cand["wins"], cand_n)
        inc_success = self._wilson_lower(inc["wins"], inc_n)
        cand_gain = float(cand["gain_sum"]) / cand_n
        inc_gain = float(inc["gain_sum"]) / inc_n
        cand_reward = float(cand["reward_sum"]) / cand_n
        inc_reward = float(inc["reward_sum"]) / inc_n
        candidate_policy = self._policy_from_evidence(challenger["program"], challenger["fingerprint"], cand)
        preserves_champion = self._policy_is_not_worse(candidate_policy, best)
        not_worse_in_validation = (
            cand_success + 1e-12 >= inc_success
            and cand_gain + 1e-12 >= inc_gain
            and cand_reward + 1e-12 >= inc_reward
        )
        clearly_better_in_validation = (
            cand_success > inc_success + 0.02
            or cand_gain > inc_gain * 1.05 + 1e-9
            or cand_reward > inc_reward + 0.05
        )
        if preserves_champion and self._policy_is_strict_upgrade(candidate_policy, best) and not_worse_in_validation and clearly_better_in_validation:
            ctx["champion_history"].append(json.loads(json.dumps(best)))
            ctx["best_policy"] = candidate_policy
            self._store_elite_policy(key, candidate_policy)
            ctx["challenger"] = None
            self._compact_context(ctx, self._storage_limits()["programs"], self._storage_limits()["history"])
            self._mark_state_dirty(urgent=True)
            return
        clearly_worse = (
            cand_success + 0.03 < inc_success
            or cand_gain + max(1e-9, abs(inc_gain) * 0.06) < inc_gain
            or cand_reward + 0.07 < inc_reward
            or not self._policy_is_not_worse(candidate_policy, best)
        )
        if clearly_worse or (cand_n >= 48 and inc_n >= 48):
            rec = self._find_record(ctx, challenger["fingerprint"])
            if rec is not None:
                rec["blocked_until"] = int(ctx.get("trials", 0)) + 192
            ctx["challenger"] = None

    def _semanticize_numeric_program(self, program):
        if self.current_value is None or recognizer is None:
            return json.loads(json.dumps(program))
        current = _as_decimal(self.current_value)
        prepared = []
        for source in program:
            op = dict(source)
            if op.get("op") == "unicode_text":
                parsed = recognizer._parse_number_text(str(op.get("text", "")))
                if parsed is not None:
                    difference = parsed - current
                    delta = difference if difference > 0 else abs(difference)
                    if delta == 0:
                        delta = max(Decimal(1), abs(current) * Decimal("0.01"))
                    op = {"op": "replace_number", "delta": str(delta.normalize()),
                          "interval": max(0.0, float(op.get("interval", 0.0)))}
            prepared.append(op)
        return prepared

    def _pick_program(self, key, target):
        ctx = self._ctx(key)
        challenger = ctx.get("challenger")
        best = ctx.get("best_policy")
        if challenger is not None and best is not None:
            cand_n = int(challenger["candidate_eval"].get("n", 0))
            inc_n = int(challenger["incumbent_eval"].get("n", 0))
            if cand_n * 2 <= inc_n:
                prepared = self._semanticize_numeric_program(challenger["program"])
                return prepared, "challenger"
            prepared = self._semanticize_numeric_program(best["program"])
            return prepared, "incumbent_validation"
        programs = ctx["programs"]
        context_trials = int(ctx.get("trials", 0))
        confidence = 0.0
        if isinstance(best, dict):
            evidence = best.get("evidence", {})
            sample_confidence = 1.0 - math.exp(-max(0, int(evidence.get("n", 0))) / 10.0)
            performance_confidence = max(0.0, min(1.0, float(best.get("success_floor", 0.0)) + 0.25))
            confidence = sample_confidence * performance_confidence
        epsilon = 1.0
        if best is not None:
            epsilon = 0.16 * math.exp(-context_trials / 90.0) * (1.0 - 0.65 * confidence)
            epsilon += 0.018 * (1.0 - confidence) * math.exp(-context_trials / 700.0)
            if random.random() >= epsilon:
                return self._semanticize_numeric_program(best["program"]), "best"
        ranked = sorted(programs, key=lambda rec: (self._record_quality(rec), int(rec.get("n", 0))), reverse=True)
        base = None
        if best is not None and random.random() < 0.62:
            base = best["program"]
        elif ranked and random.random() < 0.74:
            pool_size = max(1, int(math.sqrt(len(ranked))))
            base = random.choice(ranked[:pool_size])["program"]
        elif self.state.get("success_memory") and random.random() < 0.62:
            window = self._window_signature(target)
            matches = [item for item in self.state["success_memory"] if item.get("window") == window]
            if matches:
                weighted = sorted(matches, key=self._memory_quality, reverse=True)
                base = random.choice(weighted[:max(1, int(math.sqrt(len(weighted))))])["program"]
        level = self._exploration_level(ctx)
        program = self._mutate_program(base, target, level) if base is not None else self._random_program(target, level)
        return self._semanticize_numeric_program(program), "explore"

    def _learn_program(self, key, program, reward, step_gain, role="explore"):
        self.state["trials"] = int(self.state.get("trials", 0)) + 1
        if step_gain > 0.0:
            self.state["successes"] = int(self.state.get("successes", 0)) + 1
        ctx = self._ctx(key)
        ctx["trials"] = int(ctx.get("trials", 0)) + 1
        ctx["last_used"] = int(self.state["trials"])
        if step_gain > 0.0:
            ctx["stagnation"] = 0
        else:
            ctx["stagnation"] = int(ctx.get("stagnation", 0)) + 1
        normalized = self._normalize_program(program, space="target")
        self._mark_state_dirty()
        if not normalized:
            self._maybe_save_state()
            return
        fingerprint = self._policy_fingerprint(normalized, self.target)
        rec = self._find_record(ctx, fingerprint)
        if rec is None:
            rec = {
                "fingerprint": fingerprint, "program": json.loads(json.dumps(normalized)), "n": 0, "q": 0.0,
                "wins": 0, "best_gain": 0.0, "best_reward": -1e9, "total_reward": 0.0, "total_gain": 0.0,
                "last_seen": int(self.state["trials"]), "blocked_until": 0,
            }
            ctx["programs"].append(rec)
        rec["n"] = int(rec.get("n", 0)) + 1
        rec["total_reward"] = float(rec.get("total_reward", 0.0)) + float(reward)
        rec["total_gain"] = float(rec.get("total_gain", 0.0)) + float(step_gain)
        rec["last_seen"] = int(self.state["trials"])
        alpha = 1.0 / math.sqrt(rec["n"])
        rec["q"] = float(rec.get("q", 0.0)) + alpha * (float(reward) - float(rec.get("q", 0.0)))
        if step_gain > 0.0:
            rec["wins"] = int(rec.get("wins", 0)) + 1
            rec["best_gain"] = max(float(rec.get("best_gain", 0.0)), float(step_gain))
        if float(reward) > float(rec.get("best_reward", -1e9)):
            rec["best_reward"] = float(reward)
            rec["program"] = json.loads(json.dumps(normalized))
        if step_gain > 0.0:
            window = self._window_signature(self.target)
            memory = self.state.setdefault("success_memory", [])
            remembered = None
            for item in memory:
                if item.get("window") == window and item.get("fingerprint") == fingerprint:
                    remembered = item
                    break
            if remembered is None:
                remembered = {
                    "window": window, "fingerprint": fingerprint, "program": json.loads(json.dumps(normalized)),
                    "n": 0, "reward_sum": 0.0, "gain_sum": 0.0, "best_reward": -1e9, "best_gain": 0.0,
                    "last_seen": int(self.state["trials"]),
                }
                memory.append(remembered)
            remembered["n"] = int(remembered.get("n", 0)) + 1
            remembered["reward_sum"] = float(remembered.get("reward_sum", 0.0)) + float(reward)
            remembered["gain_sum"] = float(remembered.get("gain_sum", 0.0)) + float(step_gain)
            remembered["last_seen"] = int(self.state["trials"])
            if float(reward) > float(remembered.get("best_reward", -1e9)):
                remembered["best_reward"] = float(reward)
                remembered["best_gain"] = max(float(remembered.get("best_gain", 0.0)), float(step_gain))
                remembered["program"] = json.loads(json.dumps(normalized))
        challenger = ctx.get("challenger")
        best = ctx.get("best_policy")
        if challenger is not None and best is not None:
            if role == "challenger":
                self._eval_update(challenger["candidate_eval"], reward, step_gain)
            elif role == "incumbent_validation":
                self._eval_update(challenger["incumbent_eval"], reward, step_gain)
            self._resolve_challenger(key, ctx)
        self._maybe_seed_best_policy(key, ctx, rec)
        if role == "explore" and ctx.get("challenger") is None:
            self._maybe_nominate_challenger(ctx, rec)
        limits = self._storage_limits()
        if len(ctx["programs"]) > limits["programs"]:
            self._compact_context(ctx, limits["programs"], limits["history"])
        if len(self.state.get("success_memory", [])) > limits["memory"]:
            self._compact_state()
        self.state_dirty = True
        self._maybe_save_state()

    def _foreground_window_signature(self):
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return "no-window"
        length = user32.GetWindowTextLengthW(hwnd)
        title_buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
        class_buf = ctypes.create_unicode_buffer(128)
        user32.GetClassNameW(hwnd, class_buf, len(class_buf))
        return f"{class_buf.value.strip()[:48]}|{_stable_window_title(title_buf.value)}"

    def _idle_context_key(self):
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        width_bucket = max(1, (vx1 - vx0 + 1) // 320)
        height_bucket = max(1, (vy1 - vy0 + 1) // 180)
        return f"{self._foreground_window_signature()}|{width_bucket}x{height_bucket}"

    def _idle_program_fingerprint(self, program):
        canonical = []
        for op in program:
            kind = op.get("op")
            if kind == "mouse_abs":
                canonical.append((kind, round(float(op.get("sx", 0.0)), 3), round(float(op.get("sy", 0.0)), 3), self._time_bucket(op.get("duration", 0.0))))
            elif kind == "mouse_rel":
                canonical.append((kind, round(float(op.get("sdx", 0.0)), 3), round(float(op.get("sdy", 0.0)), 3),
                                  self._time_bucket(op.get("duration", 0.0)), bool(op.get("no_coalesce", False))))
            elif kind == "mouse_button":
                canonical.append((kind, str(op.get("button", "left")), bool(op.get("down", True))))
            elif kind == "wheel":
                canonical.append((kind, int(round(float(op.get("delta", 0)) / 120.0)), bool(op.get("horizontal", False))))
            elif kind == "key_event":
                canonical.append((kind, int(op.get("code", 0)), bool(op.get("down", True))))
            elif kind == "wait":
                canonical.append((kind, self._time_bucket(op.get("seconds", 0.0))))
        raw = json.dumps(canonical, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return hashlib.blake2b(raw, digest_size=12).hexdigest()

    def _idle_random_point(self):
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        width = max(1.0, float(vx1 - vx0 + 1))
        height = max(1.0, float(vy1 - vy0 + 1))
        if random.random() < 0.62:
            cx, cy = self._cursor_pos()
            x = random.gauss(cx, width * 0.14)
            y = random.gauss(cy, height * 0.14)
        else:
            x = random.uniform(vx0, vx1)
            y = random.uniform(vy0, vy1)
        return _clamp((x - vx0) / width, 0.0, 1.0), _clamp((y - vy0) / height, 0.0, 1.0)

    def _idle_key_tap(self):
        code = random.choice(self.IDLE_SAFE_VKS)
        return [
            {"op": "key_event", "mode": "vk", "code": code, "down": True, "extended": False},
            {"op": "key_event", "mode": "vk", "code": code, "down": False, "extended": False},
        ]

    def _random_idle_program(self):
        sx, sy = self._idle_random_point()
        gesture = random.choices(("move", "click", "scroll", "key", "move_rel", "compound"), weights=(18, 18, 20, 18, 12, 14), k=1)[0]
        if gesture == "move":
            return [{"op": "mouse_abs", "sx": sx, "sy": sy, "duration": self._random_duration(0.24)}]
        if gesture == "click":
            return [
                {"op": "mouse_abs", "sx": sx, "sy": sy, "duration": self._random_duration(0.18)},
                {"op": "mouse_button", "button": "left", "down": True},
                {"op": "wait", "seconds": self._random_duration(0.045)},
                {"op": "mouse_button", "button": "left", "down": False},
            ]
        if gesture == "scroll":
            delta = random.choice((-720, -360, -240, -120, 120, 240, 360, 720))
            return [{"op": "mouse_abs", "sx": sx, "sy": sy, "duration": self._random_duration(0.16)}, {"op": "wheel", "delta": delta, "horizontal": random.random() < 0.12}]
        if gesture == "key":
            return self._idle_key_tap()
        if gesture == "move_rel":
            return [{"op": "mouse_rel", "sdx": random.gauss(0.0, 0.08), "sdy": random.gauss(0.0, 0.08), "duration": self._random_duration(0.18), "no_coalesce": False}]
        program = [
            {"op": "mouse_abs", "sx": sx, "sy": sy, "duration": self._random_duration(0.18)},
            {"op": "mouse_button", "button": "left", "down": True},
            {"op": "mouse_button", "button": "left", "down": False},
            {"op": "wait", "seconds": self._random_duration(0.10)},
        ]
        if random.random() < 0.5:
            program.extend(self._idle_key_tap())
        else:
            program.append({"op": "wheel", "delta": random.choice((-240, -120, 120, 240)), "horizontal": False})
        return self._normalize_idle_program(program)

    def _mutate_idle_program(self, program):
        mutated = self._normalize_idle_program(json.loads(json.dumps(program)))
        if not mutated:
            return self._random_idle_program()
        op = mutated[random.randrange(len(mutated))]
        kind = op.get("op")
        factor = math.exp(random.gauss(0.0, 0.35))
        if kind == "mouse_abs":
            op["sx"] = _clamp(float(op.get("sx", 0.5)) + random.gauss(0.0, 0.06), 0.0, 1.0)
            op["sy"] = _clamp(float(op.get("sy", 0.5)) + random.gauss(0.0, 0.06), 0.0, 1.0)
            op["duration"] = max(0.0, float(op.get("duration", 0.0)) * factor)
        elif kind == "mouse_rel":
            op["sdx"] = float(op.get("sdx", 0.0)) + random.gauss(0.0, 0.05)
            op["sdy"] = float(op.get("sdy", 0.0)) + random.gauss(0.0, 0.05)
            op["duration"] = max(0.0, float(op.get("duration", 0.0)) * factor)
        elif kind == "wheel":
            steps = int(round(float(op.get("delta", 120)) / 120.0)) + random.choice((-2, -1, 1, 2))
            op["delta"] = (steps or random.choice((-1, 1))) * 120
        elif kind == "key_event":
            old_code = int(op.get("code", 0))
            code = random.choice(self.IDLE_SAFE_VKS)
            for item in mutated:
                if item.get("op") == "key_event" and int(item.get("code", 0)) == old_code:
                    item["code"] = code
        elif kind == "wait":
            op["seconds"] = max(0.0, min(0.8, float(op.get("seconds", 0.0)) * factor))
        if random.random() < 0.18:
            return self._random_idle_program()
        normalized = self._normalize_idle_program(mutated)
        return normalized if normalized else self._random_idle_program()

    def _idle_ctx(self, key):
        contexts = self.state.setdefault("idle_contexts", {})
        if key not in contexts:
            limits = self._storage_limits()
            cap = max(16, limits["contexts"] // 2)
            if len(contexts) >= cap:
                victim = min(contexts.items(), key=lambda pair: self._idle_context_quality(pair[1]))[0]
                del contexts[victim]
            contexts[key] = {"programs": [], "trials": 0, "last_used": int(self.state.get("idle_trials", 0))}
        return contexts[key]

    def _pick_idle_program(self, key):
        ctx = self._idle_ctx(key)
        programs = ctx.get("programs", [])
        trials = int(ctx.get("trials", 0))
        epsilon = 0.72 * math.exp(-trials / 55.0) + 0.12
        ranked = sorted(programs, key=lambda rec: (self._idle_record_quality(rec), int(rec.get("n", 0))), reverse=True)
        if ranked and random.random() >= epsilon:
            return json.loads(json.dumps(random.choice(ranked[:max(1, min(4, int(math.sqrt(len(ranked))) + 1))])["program"]))
        base = None
        if ranked and random.random() < 0.64:
            base = random.choice(ranked[:max(1, min(6, int(math.sqrt(len(ranked))) + 1))])["program"]
        elif self.state.get("idle_memory") and random.random() < 0.45:
            matches = [item for item in self.state["idle_memory"] if item.get("context") == key]
            pool = matches if matches else self.state["idle_memory"]
            if pool:
                pool = sorted(pool, key=self._idle_memory_quality, reverse=True)
                base = random.choice(pool[:max(1, min(6, int(math.sqrt(len(pool))) + 1))])["program"]
        return self._mutate_idle_program(base) if base is not None else self._random_idle_program()

    def _idle_state_signature(self, image):
        pixels = max(1, int(hardware_profile["screen_pixels"]))
        ratio = math.sqrt(max(1.0, pixels) / float(1920 * 1080))
        width = int(_clamp(round(48 * ratio ** 0.25), 40, 72))
        height = max(24, int(round(width * 9.0 / 16.0)))
        arr = np.asarray(image.convert("L").resize((width, height), Image.Resampling.BILINEAR), dtype=np.float32) / 255.0
        quantized = np.clip(np.round(arr * 15.0), 0, 15).astype(np.uint8)
        digest = hashlib.blake2b(quantized.tobytes(), digest_size=10).hexdigest()
        return digest, arr


    def _idle_intrinsic_reward(self, before, after, program, before_window, after_window, before_cursor):
        before_hash, before_arr = self._idle_state_signature(before)
        after_hash, after_arr = self._idle_state_signature(after)
        visual_delta = float(np.mean(np.abs(after_arr - before_arr)))
        if self.idle_recent_states:
            novelty = min(float(np.mean(np.abs(after_arr - old_arr))) for _, old_arr in self.idle_recent_states)
            recent_match = min(float(np.mean(np.abs(after_arr - old_arr))) for _, old_arr in list(self.idle_recent_states)[-min(4, len(self.idle_recent_states)):])
        else:
            novelty = visual_delta
            recent_match = visual_delta
        action = self._idle_program_fingerprint(self._normalize_idle_program(program))
        repetitions = sum(1 for old_action in self.idle_recent_actions if old_action == action)
        action_diversity = 1.0 / (1.0 + repetitions)
        no_change_penalty = max(0.0, 0.02 - visual_delta) * 6.0
        return_penalty = max(0.0, 0.025 - recent_match) * 4.5 if after_hash != before_hash else 0.08
        moderate_change = 1.0 - math.exp(-visual_delta * 8.0)

        escape_count = sum(1 for op in program if op.get("op") == "key_event" and bool(op.get("down", True)) and int(op.get("code", 0)) == 0x1B)
        window_switch = before_window != after_window
        recent_switches = 0
        if self.idle_recent_windows:
            sequence = list(self.idle_recent_windows) + [after_window]
            recent_switches = sum(1 for a, b in zip(sequence, sequence[1:]) if a != b)
        window_penalty = (0.15 if window_switch else 0.0) + min(0.18, recent_switches * 0.03)
        if before_window != "no-window" and after_window == "no-window":
            window_penalty += 0.20

        vx0, vy0, vx1, vy1 = self._screen_bounds()
        diagonal = max(1.0, math.hypot(vx1 - vx0 + 1, vy1 - vy0 + 1))
        cursor_x, cursor_y = before_cursor
        large_click_penalty = 0.0
        pending_point = None
        for op in program:
            if op.get("op") == "mouse_abs":
                pending_point = (vx0 + float(op.get("sx", 0.5)) * (vx1 - vx0 + 1), vy0 + float(op.get("sy", 0.5)) * (vy1 - vy0 + 1))
            elif op.get("op") == "mouse_button" and bool(op.get("down", True)) and pending_point is not None:
                travel = math.hypot(pending_point[0] - cursor_x, pending_point[1] - cursor_y) / diagonal
                if travel > 0.34:
                    large_click_penalty += min(0.16, 0.07 + (travel - 0.34) * 0.20)
                cursor_x, cursor_y = pending_point

        reward = (novelty * 2.2 + action_diversity * 0.18 + moderate_change * 0.18
                  - no_change_penalty - return_penalty - repetitions * 0.035
                  - escape_count * 0.16 - window_penalty - large_click_penalty)
        self.idle_recent_states.append((after_hash, after_arr))
        self.idle_recent_actions.append(action)
        self.idle_recent_windows.append(after_window)
        return _clamp(reward, -0.55, 1.0)

    def _learn_idle_program(self, key, program, reward):
        self.state["idle_trials"] = int(self.state.get("idle_trials", 0)) + 1
        ctx = self._idle_ctx(key)
        ctx["trials"] = int(ctx.get("trials", 0)) + 1
        ctx["last_used"] = int(self.state["idle_trials"])
        normalized = self._normalize_idle_program(program)
        self._mark_state_dirty()
        if not normalized:
            self._maybe_save_state()
            return
        fingerprint = self._idle_program_fingerprint(normalized)
        rec = None
        for item in ctx["programs"]:
            if item.get("fingerprint") == fingerprint:
                rec = item
                break
        if rec is None:
            rec = {"fingerprint": fingerprint, "program": json.loads(json.dumps(normalized)), "n": 0,
                   "q": 0.0, "reward_sum": 0.0, "best_reward": -1e9, "last_seen": int(self.state["idle_trials"])}
            ctx["programs"].append(rec)
        rec["n"] = int(rec.get("n", 0)) + 1
        rec["reward_sum"] = float(rec.get("reward_sum", 0.0)) + float(reward)
        rec["last_seen"] = int(self.state["idle_trials"])
        alpha = 1.0 / math.sqrt(rec["n"])
        rec["q"] = float(rec.get("q", 0.0)) + alpha * (float(reward) - float(rec.get("q", 0.0)))
        if float(reward) > float(rec.get("best_reward", -1e9)):
            rec["best_reward"] = float(reward)
            rec["program"] = json.loads(json.dumps(normalized))
        if reward > 0.03:
            memory = self.state.setdefault("idle_memory", [])
            remembered = None
            for item in memory:
                if item.get("context") == key and item.get("fingerprint") == fingerprint:
                    remembered = item
                    break
            if remembered is None:
                remembered = {"context": key, "fingerprint": fingerprint, "program": json.loads(json.dumps(normalized)),
                              "n": 0, "reward_sum": 0.0, "best_reward": -1e9, "last_seen": int(self.state["idle_trials"])}
                memory.append(remembered)
            remembered["n"] = int(remembered.get("n", 0)) + 1
            remembered["reward_sum"] = float(remembered.get("reward_sum", 0.0)) + float(reward)
            remembered["last_seen"] = int(self.state["idle_trials"])
            if float(reward) > float(remembered.get("best_reward", -1e9)):
                remembered["best_reward"] = float(reward)
                remembered["program"] = json.loads(json.dumps(normalized))
        limits = self._storage_limits()
        if len(ctx["programs"]) > max(48, limits["programs"] // 2):
            self._compact_idle_context(ctx, max(48, limits["programs"] // 2))
        if len(self.state.get("idle_memory", [])) > max(64, limits["memory"] // 2):
            self._compact_state()
        self._maybe_save_state()

    def _signed_long(self, value):
        value = int(value)
        if value < -2147483648:
            return -2147483648
        if value > 2147483647:
            return 2147483647
        return value

    def _send_input_failed(self):
        self.clear_user_interrupt()
        with self.input_gate_lock:
            self.input_enabled = False
            self.stop_event.set()
        self.system_stop_reason = "Windows 拒绝了 AI 的鼠标或键盘输入，AI已停止。可重新选择模式。"

    def _raw_mouse_packet(self, dx, dy, data, flags, release=False):
        with self.input_gate_lock:
            if not release and (not self.input_enabled or self.stop_event.is_set()):
                return False
            packet = INPUT()
            packet.type = INPUT_MOUSE
            packet.mi = MOUSEINPUT(self._signed_long(dx), self._signed_long(dy), int(data) & 0xFFFFFFFF, int(flags) & 0xFFFFFFFF, 0, INPUT_TAG)
            if int(user32.SendInput(1, ctypes.byref(packet), ctypes.sizeof(INPUT))) != 1:
                self._send_input_failed()
                return False
            self._track_raw_mouse(int(data), int(flags))
            return True

    def _track_raw_mouse(self, data, flags):
        mapping = (
            ("left", MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
            ("right", MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
            ("middle", MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP),
        )
        for name, down_flag, up_flag in mapping:
            if flags & down_flag:
                self.held_mouse.add(name)
            if flags & up_flag:
                self.held_mouse.discard(name)
        if flags & MOUSEEVENTF_XDOWN:
            if data & 1:
                self.held_mouse.add("x1")
            if data & 2:
                self.held_mouse.add("x2")
        if flags & MOUSEEVENTF_XUP:
            if data & 1:
                self.held_mouse.discard("x1")
            if data & 2:
                self.held_mouse.discard("x2")

    def _raw_mouse_move_abs(self, x, y):
        vx, vy = virtual_origin()
        vw = max(2, user32.GetSystemMetrics(78))
        vh = max(2, user32.GetSystemMetrics(79))
        nx = max(0, min(65535, int(round((int(x) - vx) * 65535.0 / (vw - 1)))))
        ny = max(0, min(65535, int(round((int(y) - vy) * 65535.0 / (vh - 1)))))
        return self._raw_mouse_packet(nx, ny, 0, MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK)

    def _raw_mouse_move_rel(self, dx, dy, no_coalesce=False):
        flags = MOUSEEVENTF_MOVE | (MOUSEEVENTF_MOVE_NOCOALESCE if no_coalesce else 0)
        return self._raw_mouse_packet(dx, dy, 0, flags)

    def _button_packet(self, button, down, release=False):
        mapping = {
            "left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, 0),
            "right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, 0),
            "middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP, 0),
            "x1": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, 1),
            "x2": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, 2),
        }
        down_flag, up_flag, data = mapping.get(button, mapping["left"])
        return self._raw_mouse_packet(0, 0, data, down_flag if down else up_flag, release=release)

    def _mouse_button(self, button, down, force=False):
        if self.stop_event.is_set() and down and not force:
            return False
        return self._button_packet(button, down, release=force)

    def _raw_keyboard_packet(self, vk, scan, flags, release=False):
        return self._raw_keyboard_sequence(((vk, scan, flags),), release=release)

    def _raw_keyboard_sequence(self, events, release=False):
        events = tuple(events)
        if not events:
            return True
        with self.input_gate_lock:
            if not release and (not self.input_enabled or self.stop_event.is_set()):
                return False
            packets = (INPUT * len(events))()
            normalized_events = []
            for index, (vk, scan, flags) in enumerate(events):
                vk = int(vk) & 0xFFFF
                scan = int(scan) & 0xFFFF
                flags = int(flags) & 0xFFFFFFFF
                packets[index].type = INPUT_KEYBOARD
                packets[index].ki = KEYBDINPUT(vk, scan, flags, 0, INPUT_TAG)
                normalized_events.append((vk, scan, flags))
            sent = int(user32.SendInput(len(events), packets, ctypes.sizeof(INPUT)))
            for vk, scan, flags in normalized_events[:max(0, min(sent, len(normalized_events)))]:
                self._track_raw_keyboard(vk, scan, flags)
            if sent != len(events):
                self._send_input_failed()
                return False
            return True

    def _track_raw_keyboard(self, vk, scan, flags):
        extended = bool(flags & KEYEVENTF_EXTENDEDKEY)
        if flags & KEYEVENTF_UNICODE:
            identity = ("unicode", int(scan) & 0xFFFF, extended)
        elif flags & KEYEVENTF_SCANCODE:
            identity = ("scan", int(scan) & 0xFFFF, extended)
        else:
            identity = ("vk", int(vk) & 0xFFFF, extended)
        if flags & KEYEVENTF_KEYUP:
            self.held_keys.discard(identity)
        else:
            self.held_keys.add(identity)

    def _key_event(self, mode, code, down, extended=False, force=False):
        if self.stop_event.is_set() and down and not force:
            return False
        flags = (KEYEVENTF_EXTENDEDKEY if extended else 0) | (0 if down else KEYEVENTF_KEYUP)
        if mode == "scan":
            flags |= KEYEVENTF_SCANCODE
            return self._raw_keyboard_packet(0, code, flags, release=force)
        return self._raw_keyboard_packet(code, 0, flags, release=force)

    def _unicode_unit(self, unit, down, force=False):
        if self.stop_event.is_set() and down and not force:
            return False
        flags = KEYEVENTF_UNICODE | (0 if down else KEYEVENTF_KEYUP)
        return self._raw_keyboard_packet(0, unit, flags, release=force)

    def _mouse_move_abs(self, x, y, duration=0.0):
        if self.stop_event.is_set():
            return False
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        x = max(vx0, min(vx1, int(x)))
        y = max(vy0, min(vy1, int(y)))
        sx, sy = self._cursor_pos()
        dx, dy = x - sx, y - sy
        duration = max(0.0, float(duration))
        if duration == 0.0:
            return self._raw_mouse_move_abs(x, y)
        dist = math.hypot(dx, dy)
        steps = max(1, int(math.ceil(duration * 90.0)), int(math.ceil(dist / 18.0)))
        pause = duration / steps
        nx, ny = (-dy / max(dist, 1.0), dx / max(dist, 1.0))
        curve = random.gauss(0.0, 0.045) * min(dist, 220.0)
        for i in range(1, steps + 1):
            if self.stop_event.is_set():
                return False
            t = i / steps
            ease = 3 * t * t - 2 * t * t * t
            bend = math.sin(math.pi * t) * curve
            if not self._raw_mouse_move_abs(int(round(sx + dx * ease + nx * bend)), int(round(sy + dy * ease + ny * bend))):
                return False
            if pause > 0 and self.stop_event.wait(pause):
                return False
        return True

    def _mouse_move_rel(self, dx, dy, duration=0.0, no_coalesce=False):
        if self.stop_event.is_set():
            return False
        dx, dy = self._signed_long(dx), self._signed_long(dy)
        duration = max(0.0, float(duration))
        if duration == 0.0:
            return self._raw_mouse_move_rel(dx, dy, no_coalesce)
        steps = max(1, int(math.ceil(duration * 90.0)), int(math.ceil(max(abs(dx), abs(dy)) / 18.0)))
        pause = duration / steps
        sent_x = sent_y = 0
        for i in range(1, steps + 1):
            if self.stop_event.is_set():
                return False
            target_x = int(round(dx * i / steps))
            target_y = int(round(dy * i / steps))
            if not self._raw_mouse_move_rel(target_x - sent_x, target_y - sent_y, no_coalesce):
                return False
            sent_x, sent_y = target_x, target_y
            if pause > 0 and self.stop_event.wait(pause):
                return False
        return True

    def _wheel(self, delta, horizontal=False):
        if self.stop_event.is_set():
            return False
        return self._raw_mouse_packet(0, 0, int(delta), MOUSEEVENTF_HWHEEL if horizontal else MOUSEEVENTF_WHEEL)

    def _type_text(self, text, interval=0.0):
        units = str(text).encode("utf-16-le")
        interval = max(0.0, float(interval))
        for i in range(0, len(units), 2):
            if self.stop_event.is_set():
                return False
            unit = units[i] | (units[i + 1] << 8)
            if not self._raw_keyboard_sequence(((0, unit, KEYEVENTF_UNICODE), (0, unit, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP))):
                return False
            if interval > 0 and self.stop_event.wait(interval):
                return False
        return True

    def _release_all_inputs(self):
        release_error = None
        for button in list(self.held_mouse):
            try:
                self._mouse_button(button, False, force=True)
            except Exception as exc:
                release_error = release_error or exc
            finally:
                self.held_mouse.discard(button)
        for mode, code, extended in list(self.held_keys):
            try:
                if mode == "unicode":
                    self._unicode_unit(code, False, force=True)
                else:
                    self._key_event(mode, code, False, extended=extended, force=True)
            except Exception as exc:
                release_error = release_error or exc
            finally:
                self.held_keys.discard((mode, code, extended))
        if release_error is not None:
            self.clear_user_interrupt()
            self.stop_event.set()
            if self.system_stop_reason is None:
                self.system_stop_reason = f"释放鼠标或键盘状态时出错：{release_error}。AI已停止。"

    def _caret_near_target(self):
        if self.target is None:
            return False
        foreground = user32.GetForegroundWindow()
        if not foreground:
            return False
        thread_id = int(user32.GetWindowThreadProcessId(foreground, None))
        if not thread_id:
            return False
        info = GUITHREADINFO()
        info.cbSize = ctypes.sizeof(GUITHREADINFO)
        if not user32.GetGUIThreadInfo(thread_id, ctypes.byref(info)) or not info.hwndCaret:
            return False
        target_root, _, _ = self._target_window_info(self.target)
        focus_root = user32.GetAncestor(info.hwndFocus, GA_ROOT) if info.hwndFocus else None
        caret_root = user32.GetAncestor(info.hwndCaret, GA_ROOT) if info.hwndCaret else None
        if target_root and target_root not in (focus_root, caret_root, foreground):
            return False
        p0 = wintypes.POINT(info.rcCaret.left, info.rcCaret.top)
        p1 = wintypes.POINT(info.rcCaret.right, info.rcCaret.bottom)
        if not user32.ClientToScreen(info.hwndCaret, ctypes.byref(p0)):
            return False
        if not user32.ClientToScreen(info.hwndCaret, ctypes.byref(p1)):
            p1 = wintypes.POINT(p0.x + 2, p0.y + 18)
        x0, y0, x1, y1 = self.target["box"]
        h = max(4.0, y1 - y0)
        w = max(4.0, x1 - x0)
        margin_x = max(h * 2.5, w * 0.45)
        margin_y = h * 1.4
        cx = (p0.x + p1.x) / 2.0
        cy = (p0.y + p1.y) / 2.0
        return (x0 - margin_x <= cx <= x1 + margin_x and y0 - margin_y <= cy <= y1 + margin_y)

    def _replace_number(self, delta, interval=0.0):
        if self.current_value is None or self.target is None:
            raise RuntimeError("当前数字或目标位置不可用，无法执行参数化替换")
        delta_value = abs(_as_decimal(delta))
        if delta_value <= 0:
            raise ValueError("replace_number 的 delta 必须是有限正数")
        next_value = _as_decimal(self.current_value) + delta_value
        if not next_value.is_finite():
            raise OverflowError("参数化替换结果不是有限数字")
        x0, y0, x1, y1 = self.target["box"]
        cx = int(round((x0 + x1) / 2.0))
        cy = int(round((y0 + y1) / 2.0))
        if not self._mouse_move_abs(cx, cy, 0.08):
            return False
        if not self._mouse_button("left", True):
            return False
        if not self._mouse_button("left", False):
            return False
        if self.stop_event.wait(0.055):
            return False
        if not self._caret_near_target():
            self.last_replace_attempt = None
            return True
        key = self._context_key(self.target)
        ctx = self._ctx(key)
        use_enter = bool(ctx.get("replace_enter_required", False))
        if not self._raw_keyboard_sequence(((0x11, 0, 0), (0x41, 0, 0), (0x41, 0, KEYEVENTF_KEYUP), (0x11, 0, KEYEVENTF_KEYUP))):
            return False
        expected_text = _format_number(next_value)
        if not self._type_text(expected_text, interval):
            return False
        if use_enter and not self._raw_keyboard_sequence(((0x0D, 0, 0), (0x0D, 0, KEYEVENTF_KEYUP))):
            return False
        self.last_replace_attempt = {"context": key, "expected": next_value, "text": expected_text, "used_enter": use_enter}
        return True

    def _target_absolute_point(self, op):
        if self.target is None:
            raise RuntimeError("目标坐标不可用")
        x0, y0, x1, y1 = self.target["box"]
        h = max(1.0, y1 - y0)
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        return int(round(cx + float(op["rx"]) * h)), int(round(cy + float(op["ry"]) * h))


    def _screen_absolute_point(self, op):
        vx0, vy0, vx1, vy1 = self._screen_bounds()
        width = max(1.0, float(vx1 - vx0))
        height = max(1.0, float(vy1 - vy0))
        return int(round(vx0 + float(op["sx"]) * width)), int(round(vy0 + float(op["sy"]) * height))


    def _perform_program(self, program):
        space = "target" if self.mode == "grow" else "screen"
        normalized = self._normalize_program(program, space=space)
        if not normalized:
            return False
        completed = True
        try:
            index = 0
            while index < len(normalized):
                if self.stop_event.is_set():
                    completed = False
                    break
                op = normalized[index]
                kind = op.get("op")
                ok = True
                if kind == "key_event":
                    block = []
                    while index < len(normalized) and normalized[index].get("op") == "key_event":
                        item = normalized[index]
                        flags = (KEYEVENTF_EXTENDEDKEY if bool(item.get("extended", False)) else 0)
                        if not bool(item.get("down", True)):
                            flags |= KEYEVENTF_KEYUP
                        if str(item.get("mode", "vk")) == "scan":
                            flags |= KEYEVENTF_SCANCODE
                            block.append((0, int(item.get("code", 0)), flags))
                        else:
                            block.append((int(item.get("code", 0)), 0, flags))
                        index += 1
                    ok = self._raw_keyboard_sequence(block)
                    if ok is False:
                        completed = False
                        break
                    continue
                if kind == "mouse_abs":
                    x, y = self._target_absolute_point(op) if space == "target" else self._screen_absolute_point(op)
                    ok = self._mouse_move_abs(x, y, op.get("duration", 0.0))
                elif kind == "mouse_rel":
                    if space == "target":
                        if self.target is None:
                            ok = False
                        else:
                            h = max(1.0, self.target["box"][3] - self.target["box"][1])
                            dx = int(round(float(op["rdx"]) * h))
                            dy = int(round(float(op["rdy"]) * h))
                            ok = self._mouse_move_rel(dx, dy, op.get("duration", 0.0), bool(op.get("no_coalesce", False)))
                    else:
                        vx0, vy0, vx1, vy1 = self._screen_bounds()
                        dx = int(round(float(op["sdx"]) * max(1, vx1 - vx0 + 1)))
                        dy = int(round(float(op["sdy"]) * max(1, vy1 - vy0 + 1)))
                        ok = self._mouse_move_rel(dx, dy, op.get("duration", 0.0), bool(op.get("no_coalesce", False)))
                elif kind == "mouse_button":
                    ok = self._mouse_button(op.get("button", "left"), bool(op.get("down", True)))
                elif kind == "wheel":
                    ok = self._wheel(op.get("delta", 120), bool(op.get("horizontal", False)))
                elif kind == "unicode_text":
                    ok = self._type_text(op.get("text", ""), op.get("interval", 0.0))
                elif kind == "replace_number":
                    ok = self._replace_number(op.get("delta", 1.0), op.get("interval", 0.0))
                elif kind == "wait" and self.stop_event.wait(max(0.0, float(op.get("seconds", 0.0)))):
                    ok = False
                if ok is False:
                    completed = False
                    break
                index += 1
            return completed and not self.stop_event.is_set()
        finally:
            self._release_all_inputs()

    def _detect_target_region(self, image, origin, window_scope=False):
        if self.target is None:
            return None
        if window_scope:
            gx0, gy0, gx1, gy1 = self._window_bounds_for_target(self.target)
        else:
            x0, y0, x1, y1 = self.target["box"]
            h = max(6, y1 - y0)
            margin_x = max(int(h * 8.0), x1 - x0)
            margin_y = int(h * 5.0)
            gx0, gy0, gx1, gy1 = x0 - margin_x, y0 - margin_y, x1 + margin_x, y1 + margin_y
        ix0 = max(0, int(gx0 - origin[0])); iy0 = max(0, int(gy0 - origin[1]))
        ix1 = min(image.width, int(gx1 - origin[0] + 1)); iy1 = min(image.height, int(gy1 - origin[1] + 1))
        if ix1 - ix0 < 6 or iy1 - iy0 < 6:
            return None
        crop = image.crop((ix0, iy0, ix1, iy1))
        crop_origin = (origin[0] + ix0, origin[1] + iy0)
        numbers = detect_multiscale_image(crop, crop_origin, scales=(1.0,), stop_event=self.stop_event)
        return self._match_target(numbers, crop, crop_origin, wide=window_scope)

    def _reacquire_target(self, bounded_rounds=None):
        rounds = 0
        while app_alive.is_set() and not shutdown_event.is_set() and not self.stop_event.is_set() and self.target is not None:
            image, origin = capture_screen()
            numbers = detect_multiscale_image(image, origin, scales=(1.0, 0.84, 1.18), stop_event=self.stop_event)
            observed = self._match_target(numbers, image, origin, wide=True)
            if observed is not None:
                self.target = dict(observed)
                self.current_value = observed["value"]
                self._ensure_identity_context(image, origin)
                return observed
            rounds += 1
            if bounded_rounds is not None and rounds >= bounded_rounds:
                return None
            if self.stop_event.wait(min(0.45, 0.12 + rounds * 0.03)):
                return None
        return None

    def start(self, mode="grow"):
        if _shutdown_requested() or mode not in ("grow", "free") or not self.input_hooks_ready.is_set():
            return False
        with self.input_gate_lock:
            if mode == "grow" and self.arming and (self.user_interrupt_event.is_set() or self.stop_event.is_set()):
                return False
            with self.lock:
                if self.running:
                    return False
                if mode == "grow" and (self.target is None or self.original_target is None):
                    return False
                self.user_interrupt_event.clear()
                self.hook_callback_error_event.clear()
                self.stop_event.clear()
                self.system_stop_reason = None
                self.user_interrupt_pending = False
                self.mode = mode
                self.arming = False
                self.running = True
                self.input_enabled = True
        root.withdraw()
        loop = self._agent_loop if mode == "grow" else self._idle_agent_loop
        thread = threading.Thread(target=loop, name=f"MakeItBiggerAgent-{mode}", daemon=True)
        with self.lock:
            self.agent_thread = thread
        thread.start()
        return True

    def _reward_for(self, before_value, observed_value):
        baseline = _as_decimal(self.original_target["value"])
        before = _as_decimal(before_value)
        observed = _as_decimal(observed_value)
        absolute_gain_decimal = max(Decimal(0), observed - baseline)
        step_gain_decimal = max(Decimal(0), observed - before)
        absolute_gain = _decimal_to_learning_float(absolute_gain_decimal)
        step_gain = _decimal_to_learning_float(step_gain_decimal)
        self.state["best_gain"] = max(float(self.state.get("best_gain", 0.0)), absolute_gain)
        if step_gain_decimal > 0:
            if before <= baseline < observed:
                reward = 1.0 + min(1.8, math.log1p(step_gain) * 0.45)
            else:
                reward = 0.45 + min(1.2, math.log1p(step_gain) * 0.35)
            return reward, step_gain
        if observed == before:
            return (-0.04 if observed > baseline else -0.18), 0.0
        if observed > baseline:
            return -0.55, 0.0
        deficit = _decimal_to_learning_float(baseline - observed)
        return -min(1.25, 0.72 + math.log1p(deficit) * 0.12), 0.0

    def _record_unknown_observation(self, key):
        self.state["unknowns"] = int(self.state.get("unknowns", 0)) + 1
        ctx = self._ctx(key)
        ctx["unknowns"] = int(ctx.get("unknowns", 0)) + 1
        self.state_dirty = True
        self._maybe_save_state()

    def _confirm_changed_observation(self, first):
        if first is None or float(first.get("conf", 0.0)) < 0.72:
            return None
        if self.stop_event.wait(0.12):
            return None
        image, origin = capture_screen()
        second = self._detect_target_region(image, origin, window_scope=False)
        if second is None:
            second = self._detect_target_region(image, origin, window_scope=True)
        if second is None or float(second.get("conf", 0.0)) < 0.72:
            return None
        expected_window = (self.target_identity or {}).get("window")
        first_window = self._window_signature(first)
        second_window = self._window_signature(second)
        if expected_window and (first_window != expected_window or second_window != expected_window):
            return None
        if first_window != second_window:
            return None
        if recognizer._iou(first["box"], second["box"]) < 0.42:
            return None
        if not _same_ocr_number(first, second):
            return None
        stored_context = (self.target_identity or {}).get("context")
        if stored_context is not None:
            desc = self._context_descriptor(image, origin, second["box"])
            if desc is None:
                return None
            a = np.asarray(stored_context, dtype=np.float32)
            d = np.asarray(desc, dtype=np.float32)
            if float(np.mean((a - d) ** 2)) > 0.11:
                return None
        attempt = self.last_replace_attempt
        if attempt is not None:
            expected = attempt.get("expected")
            if expected is not None and _same_number(first.get("value"), expected) and _same_number(second.get("value"), expected):
                expected_text = str(attempt.get("text", ""))
                if float(first.get("conf", 0.0)) >= 0.86 and float(second.get("conf", 0.0)) >= 0.86:
                    recognizer.observe_verified_number(image, origin, second, expected_text)
        return second

    def _agent_loop(self):
        runtime_error = False
        exit_reason = "AI已停止。可重新选择模式。"
        try:
            self.stop_event.wait(0.22)
            while app_alive.is_set() and not shutdown_event.is_set() and not self.stop_event.is_set() and self.target is not None:
                image, origin = capture_screen()
                refreshed = self._detect_target_region(image, origin, window_scope=False)
                if refreshed is None:
                    refreshed = self._detect_target_region(image, origin, window_scope=True)
                if refreshed is None:
                    refreshed = self._reacquire_target(bounded_rounds=12)
                    if refreshed is None:
                        if self.stop_event.is_set():
                            break
                        self.clear_user_interrupt()
                        self._clear_target_tracking()
                        exit_reason = "目标数字已无法重新识别，AI已停止。可重新选择模式。"
                        break
                    image, origin = capture_screen()
                self.target = dict(refreshed)
                self._ensure_identity_context(image, origin)
                self.current_value = refreshed["value"]
                target = dict(self.target)
                before_value = self.current_value
                key = self._context_key(target)
                program, role = self._pick_program(key, target)
                if not self._perform_program(program):
                    if self.system_stop_reason:
                        exit_reason = self.system_stop_reason
                    break
                if self.stop_event.is_set() or self.stop_event.wait(random.uniform(0.28, 0.72)):
                    if self.system_stop_reason:
                        exit_reason = self.system_stop_reason
                    break
                image, origin = capture_screen()
                observed = self._detect_target_region(image, origin, window_scope=False)
                if observed is None:
                    observed = self._detect_target_region(image, origin, window_scope=True)
                if observed is None:
                    observed = self._reacquire_target(bounded_rounds=3)
                if observed is None:
                    if self.stop_event.is_set():
                        break
                    self._learn_program(key, program, -0.34, 0.0, role)
                    observed = self._reacquire_target(bounded_rounds=12)
                    if observed is None:
                        if self.stop_event.is_set():
                            break
                        self.clear_user_interrupt()
                        self._clear_target_tracking()
                        exit_reason = "目标数字已无法重新识别，AI已停止。可重新选择模式。"
                        break
                    self.target = dict(observed)
                    self.current_value = observed["value"]
                    continue
                self.target = dict(observed)
                observed_value = observed["value"]
                changed = not _same_ocr_number(target, observed)
                if changed:
                    confirmed = self._confirm_changed_observation(observed)
                    if confirmed is None:
                        self.target = dict(target)
                        self.current_value = before_value
                        self._record_unknown_observation(key)
                        _log_runtime("warning", "changed OCR observation was not confirmed; learning result marked unknown")
                        continue
                    observed = confirmed
                    self.target = dict(confirmed)
                    observed_value = confirmed["value"]
                attempt = self.last_replace_attempt
                if attempt is not None and attempt.get("context") == key:
                    ctx = self._ctx(key)
                    if _same_number(observed_value, attempt.get("expected")):
                        ctx["replace_no_enter_successes"] = int(ctx.get("replace_no_enter_successes", 0)) + (0 if attempt.get("used_enter") else 1)
                        if not attempt.get("used_enter"):
                            ctx["replace_enter_required"] = False
                            ctx["replace_no_enter_failures"] = 0
                    elif _same_number(observed_value, before_value) and not attempt.get("used_enter"):
                        failures = int(ctx.get("replace_no_enter_failures", 0)) + 1
                        ctx["replace_no_enter_failures"] = failures
                        if failures >= 2:
                            ctx["replace_enter_required"] = True
                    self.state_dirty = True
                self.last_replace_attempt = None
                reward, step_gain = self._reward_for(before_value, observed_value)
                self.current_value = observed_value
                self._learn_program(key, program, reward, step_gain, role)
        except Exception as exc:
            runtime_error = True
            exit_reason = self.handle_runtime_error(exc, "AI控制/识别/学习过程")
        finally:
            with self.input_gate_lock:
                self.input_enabled = False
            self._release_all_inputs()
            hook_failed = self.hook_callback_error_event.is_set()
            if hook_failed:
                self.system_stop_reason = "用户输入监听回调出错。AI已停止。可重新选择模式。"
                _log_runtime("error", "low-level input hook callback failed")
            with self.lock:
                user_interrupted = self.user_interrupt_event.is_set() and not hook_failed
                self.user_interrupt_pending = bool(user_interrupted)
                self.running = False
                self.mode = None
            if self.system_stop_reason and not self.user_interrupt_pending:
                exit_reason = self.system_stop_reason
            if not runtime_error:
                try:
                    self._save_state(force=True)
                except Exception as exc:
                    runtime_error = True
                    user_interrupted = False
                    exit_reason = self.handle_runtime_error(exc, "学习状态保存")
            if app_alive.is_set() and not runtime_error:
                if user_interrupted and self.user_interrupt_pending:
                    post_ui("show_user_control")
                else:
                    self.clear_user_interrupt()
                    post_ui("show_agent_stopped", exit_reason)
            with self.lock:
                if self.agent_thread is threading.current_thread():
                    self.agent_thread = None

    def _idle_agent_loop(self):
        runtime_error = False
        exit_reason = "自由模式 AI 已停止。可重新选择模式。"
        try:
            self.stop_event.wait(0.22)
            while app_alive.is_set() and not shutdown_event.is_set() and not self.stop_event.is_set():
                before, _ = capture_screen()
                before_window = self._foreground_window_signature()
                before_cursor = self._cursor_pos()
                key = self._idle_context_key()
                program = self._pick_idle_program(key)
                if not self._perform_program(program):
                    if self.system_stop_reason:
                        exit_reason = self.system_stop_reason
                    break
                if self.stop_event.is_set() or self.stop_event.wait(random.uniform(0.30, 0.70)):
                    if self.system_stop_reason:
                        exit_reason = self.system_stop_reason
                    break
                after, _ = capture_screen()
                if self.stop_event.is_set():
                    break
                after_window = self._foreground_window_signature()
                reward = self._idle_intrinsic_reward(before, after, program, before_window, after_window, before_cursor)
                self._learn_idle_program(key, program, reward)
        except Exception as exc:
            runtime_error = True
            exit_reason = self.handle_runtime_error(exc, "自由模式AI控制/视觉/学习过程")
        finally:
            with self.input_gate_lock:
                self.input_enabled = False
            self._release_all_inputs()
            hook_failed = self.hook_callback_error_event.is_set()
            if hook_failed:
                self.system_stop_reason = "用户输入监听回调出错。AI已停止。可重新选择模式。"
                _log_runtime("error", "low-level input hook callback failed")
            with self.lock:
                user_interrupted = self.user_interrupt_event.is_set() and not hook_failed
                self.user_interrupt_pending = bool(user_interrupted)
                self.running = False
                self.mode = None
            if self.system_stop_reason and not self.user_interrupt_pending:
                exit_reason = self.system_stop_reason
            if not runtime_error:
                try:
                    self._save_state(force=True)
                except Exception as exc:
                    runtime_error = True
                    user_interrupted = False
                    exit_reason = self.handle_runtime_error(exc, "自由模式学习状态保存")
            if app_alive.is_set() and not runtime_error:
                if user_interrupted and self.user_interrupt_pending:
                    post_ui("show_user_control")
                else:
                    self.clear_user_interrupt()
                    post_ui("show_agent_stopped", exit_reason)
            with self.lock:
                if self.agent_thread is threading.current_thread():
                    self.agent_thread = None

    def _register_user_input(self, source=None, w_param=None):
        with self.input_gate_lock:
            if (self.arming and source == "mouse" and int(w_param or 0) == WM_LBUTTONUP
                    and time.monotonic() < self.arming_ignore_until):
                self.arming_ignore_until = 0.0
                return
            if self.running or self.arming:
                self.input_enabled = False
                self.user_interrupt_event.set()
                self.stop_event.set()

    def run_input_monitor(self):
        try:
            self.monitor_input()
        except Exception as exc:
            if not _shutdown_requested():
                self.handle_runtime_error(exc, "用户输入监听线程")

    def monitor_input(self):
        self.hook_thread_id = kernel32.GetCurrentThreadId()

        @HOOKPROC
        def mouse_proc(n_code, w_param, l_param):
            try:
                if n_code >= 0:
                    info = ctypes.cast(l_param, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                    if int(info.dwExtraInfo) != INPUT_TAG:
                        self._register_user_input("mouse", w_param)
            except Exception as exc:
                self.input_enabled = False
                self.hook_callback_error_event.set()
                self.stop_event.set()
            return user32.CallNextHookEx(self.mouse_hook, n_code, w_param, l_param)

        @HOOKPROC
        def keyboard_proc(n_code, w_param, l_param):
            try:
                if n_code >= 0:
                    info = ctypes.cast(l_param, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                    if int(info.dwExtraInfo) != INPUT_TAG:
                        self._register_user_input("keyboard", w_param)
            except Exception as exc:
                self.input_enabled = False
                self.hook_callback_error_event.set()
                self.stop_event.set()
            return user32.CallNextHookEx(self.keyboard_hook, n_code, w_param, l_param)

        self.mouse_proc = mouse_proc
        self.keyboard_proc = keyboard_proc
        module = kernel32.GetModuleHandleW(None)
        self.mouse_hook = user32.SetWindowsHookExW(WH_MOUSE_LL, self.mouse_proc, module, 0)
        self.keyboard_hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL, self.keyboard_proc, module, 0)
        if not self.mouse_hook or not self.keyboard_hook:
            if self.mouse_hook:
                user32.UnhookWindowsHookEx(self.mouse_hook)
            if self.keyboard_hook:
                user32.UnhookWindowsHookEx(self.keyboard_hook)
            self.mouse_hook = None
            self.keyboard_hook = None
            self.input_hooks_ready.clear()
            self.handle_runtime_error(RuntimeError("无法安装用户输入监听钩子"), "用户输入监听初始化")
            return

        self.input_hooks_ready.set()
        post_ui("enable_controls")
        msg = wintypes.MSG()
        try:
            while app_alive.is_set() and not shutdown_event.is_set():
                result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if result <= 0:
                    break
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
        finally:
            self.input_hooks_ready.clear()
            if self.mouse_hook:
                user32.UnhookWindowsHookEx(self.mouse_hook)
            if self.keyboard_hook:
                user32.UnhookWindowsHookEx(self.keyboard_hook)
            self.mouse_hook = None
            self.keyboard_hook = None
            if app_alive.is_set() and not shutdown_event.is_set():
                self.handle_runtime_error(RuntimeError("用户输入监听线程已停止"), "用户输入监听")


recognizer = None
controller = None


def virtual_origin():
    return (user32.GetSystemMetrics(76), user32.GetSystemMetrics(77))


def capture_screen():
    origin = virtual_origin()
    return ImageGrab.grab(all_screens=True), origin


def _merge_number_observations(observations):
    clusters = []
    for item in observations:
        best_cluster = None
        best_iou = 0.0
        for cluster in clusters:
            overlap = recognizer._iou(item["box"], cluster["box"])
            if overlap > best_iou:
                best_iou = overlap
                best_cluster = cluster
        if best_cluster is None or best_iou < 0.46:
            clusters.append({"box": item["box"], "items": [item]})
        else:
            best_cluster["items"].append(item)
            representative = max(best_cluster["items"], key=lambda g: float(g.get("conf", 0.0)))
            best_cluster["box"] = representative["box"]
    merged = []
    for cluster in clusters:
        votes = {}
        values = {}
        for item in cluster["items"]:
            key = _number_key(item["value"])
            values[key] = item["value"]
            votes[key] = votes.get(key, 0.0) + max(0.05, float(item.get("conf", 0.0)))
        key = max(votes.items(), key=lambda kv: kv[1])[0]
        value = values[key]
        matching = [item for item in cluster["items"] if _number_key(item["value"]) == key]
        best = max(matching, key=lambda g: float(g.get("conf", 0.0)))
        result = dict(best)
        result["value"] = value
        result["conf"] = min(1.0, float(best.get("conf", 0.0)) + min(0.18, 0.035 * (len(matching) - 1)))
        merged.append(result)
    merged.sort(key=lambda g: (float(g.get("conf", 0.0)), len(str(g.get("text", g.get("value", ""))))), reverse=True)
    return merged


def _scan_cancelled(stop_event=None, deadline=None):
    if shutdown_event.is_set() or not app_alive.is_set():
        return True
    if stop_event is not None and stop_event.is_set():
        return True
    return deadline is not None and time.monotonic() >= float(deadline)


def detect_multiscale_image(image, origin, scales=(1.0, 0.86, 1.16), stop_event=None, deadline=None, fast=False):
    observations = []
    for scale in scales:
        if _scan_cancelled(stop_event, deadline):
            break
        scale = float(scale)
        if abs(scale - 1.0) < 0.001:
            scaled = image
        else:
            scaled = image.resize((max(1, int(round(image.width * scale))), max(1, int(round(image.height * scale)))), Image.Resampling.BILINEAR)
        found = recognizer.detect(scaled, (0, 0), stop_event=stop_event, deadline=deadline, fast=fast)
        inv = 1.0 / scale
        for item in found:
            x0, y0, x1, y1 = item["box"]
            mapped = dict(item)
            mapped["box"] = (
                int(round(x0 * inv + origin[0])), int(round(y0 * inv + origin[1])),
                int(round(x1 * inv + origin[0])), int(round(y1 * inv + origin[1])),
            )
            if isinstance(item.get("chars"), list):
                mapped["chars"] = []
                for char in item["chars"]:
                    cx0, cy0, cx1, cy1 = char["box"]
                    mapped_char = dict(char)
                    mapped_char["box"] = (
                        int(round(cx0 * inv + origin[0])), int(round(cy0 * inv + origin[1])),
                        int(round(cx1 * inv + origin[0])), int(round(cy1 * inv + origin[1])),
                    )
                    mapped["chars"].append(mapped_char)
            observations.append(mapped)
    return _merge_number_observations(observations)


def detect_multiframe_screen(frame_count=None, scales=None, stop_event=None, deadline=None):
    if frame_count is None:
        frame_count = int(hardware_profile["scan_frames"])
    if scales is None:
        scales = tuple(hardware_profile["scan_scales"])
    observations = []
    for frame in range(max(1, int(frame_count))):
        if _scan_cancelled(stop_event, deadline):
            break
        image, origin = capture_screen()
        pixels = max(1, image.width * image.height)
        coarse_scale = min(1.0, math.sqrt(float(hardware_profile["coarse_pixel_budget"]) / pixels))
        coarse_scale = _clamp(coarse_scale, 0.35, 1.0)
        coarse = detect_multiscale_image(image, origin, scales=(coarse_scale,), stop_event=stop_event, deadline=deadline, fast=True)

        if not _scan_cancelled(stop_event, deadline) and (not coarse or (frame == 0 and coarse_scale < 0.72)):
            tile_pixels = max(1, int(hardware_profile["tile_pixel_budget"]))
            aspect = image.width / float(max(1, image.height))
            tile_w = max(320, int(round(math.sqrt(tile_pixels * max(1.0, aspect)))))
            tile_h = max(240, int(round(tile_pixels / float(tile_w))))
            overlap_x = max(8, int(tile_w * 0.06))
            overlap_y = max(8, int(tile_h * 0.06))
            step_x = max(1, tile_w - overlap_x)
            step_y = max(1, tile_h - overlap_y)
            y = 0
            while y < image.height and not _scan_cancelled(stop_event, deadline):
                x = 0
                while x < image.width and not _scan_cancelled(stop_event, deadline):
                    right = min(image.width, x + tile_w)
                    bottom = min(image.height, y + tile_h)
                    crop = image.crop((x, y, right, bottom))
                    coarse.extend(detect_multiscale_image(crop, (origin[0] + x, origin[1] + y), scales=(1.0,), stop_event=stop_event, deadline=deadline, fast=True))
                    if right >= image.width:
                        break
                    x += step_x
                if bottom >= image.height:
                    break
                y += step_y

        coarse = _merge_number_observations(coarse)
        observations.extend(coarse)
        regions = []
        for item in coarse:
            x0, y0, x1, y1 = item["box"]
            h = max(1, y1 - y0)
            w = max(1, x1 - x0)
            mx = max(w, int(h * 4.0))
            my = max(h, int(h * 2.0))
            regions.append([x0 - mx, y0 - my, x1 + mx, y1 + my])
        merged_regions = []
        for region in regions:
            joined = False
            for existing in merged_regions:
                if not (region[2] < existing[0] or region[0] > existing[2] or region[3] < existing[1] or region[1] > existing[3]):
                    existing[0] = min(existing[0], region[0]); existing[1] = min(existing[1], region[1])
                    existing[2] = max(existing[2], region[2]); existing[3] = max(existing[3], region[3])
                    joined = True
                    break
            if not joined:
                merged_regions.append(region)
        for gx0, gy0, gx1, gy1 in merged_regions:
            if _scan_cancelled(stop_event, deadline):
                break
            ix0 = max(0, int(gx0 - origin[0])); iy0 = max(0, int(gy0 - origin[1]))
            ix1 = min(image.width, int(gx1 - origin[0])); iy1 = min(image.height, int(gy1 - origin[1]))
            if ix1 - ix0 < 4 or iy1 - iy0 < 4:
                continue
            crop = image.crop((ix0, iy0, ix1, iy1))
            observations.extend(detect_multiscale_image(crop, (origin[0] + ix0, origin[1] + iy0), scales=scales, stop_event=stop_event, deadline=deadline, fast=False))
        if frame + 1 < int(frame_count) and stop_event is not None:
            if stop_event.wait(_clamp(0.04 + 0.01 * frame, 0.04, 0.08)):
                break
    return _merge_number_observations(observations)


def enable_main_controls():
    if controller is None or not controller.input_hooks_ready.is_set() or _shutdown_requested():
        return
    number_button.config(state="normal", command=scan_numbers)
    free_button.config(state="normal", command=start_free)
    _apply_progress({
        "value": 100,
        "phase": "已就绪",
        "text": "请选择运行模式",
        "detail": "数字识别正常 · 鼠标键盘监听正常",
        "mode": "determinate",
    })
    _refresh_info_vars()


def _launch_scan_worker():
    global scan_thread
    if _shutdown_requested() or controller is None or not controller.overlay_mode:
        return
    scan_thread = threading.Thread(target=_scan_worker, name="MakeItBiggerScan", daemon=True)
    scan_thread.start()


def scan_numbers():
    if _shutdown_requested() or controller is None or controller.running or controller.overlay_mode:
        return
    controller.clear_user_interrupt()
    with controller.input_gate_lock:
        controller.input_enabled = False
        controller.stop_event.clear()
    controller.overlay_mode = True
    _apply_progress({
        "value": 100,
        "phase": "正在扫描",
        "text": "正在识别屏幕上的数字",
        "detail": "扫描耗时不可预测，因此这里使用活动进度而不是虚构剩余时间。",
        "mode": "indeterminate",
    })
    root.withdraw()
    delay = max(120, int(round(1000.0 / max(2.0, hardware_profile["capacity"]))))
    root.after(delay, _launch_scan_worker)


def start_free():
    if _shutdown_requested() or controller is None or controller.running or controller.overlay_mode:
        return
    controller.clear_user_interrupt()
    controller._clear_target_tracking()
    if not controller.start("free"):
        dependency_failed("用户输入监听不可用，AI不会开始控制。")


def _scan_worker():
    if _shutdown_requested() or controller is None:
        return
    deadline = time.monotonic() + float(hardware_profile["scan_deadline"])
    try:
        numbers = detect_multiframe_screen(stop_event=controller.stop_event, deadline=deadline)
        if _shutdown_requested() or controller is None or not controller.overlay_mode:
            return
        if numbers:
            post_ui("show_overlays", numbers)
            return
        controller.overlay_mode = False
        post_ui("runtime_error", "未识别到屏幕上的数字。")
    except Exception as exc:
        if controller is not None and not _shutdown_requested():
            controller.handle_runtime_error(exc, "扫描/截图/数字识别")


def show_number_overlays(numbers):
    if _shutdown_requested() or controller is None:
        return
    controller.overlays = []
    controller.overlay_targets = list(numbers)
    for idx, item in enumerate(numbers):
        if _shutdown_requested():
            return
        x0, y0, x1, y1 = item["box"]
        pad = max(2, int((y1 - y0) * 0.10))
        x0, y0, x1, y1 = x0 - pad, y0 - pad, x1 + pad, y1 + pad
        w, h = max(6, x1 - x0), max(6, y1 - y0)
        win = tk.Toplevel(root)
        win.withdraw()
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.attributes("-alpha", 0.36)
        r, g, b = colorsys.hsv_to_rgb((idx * 0.61803398875) % 1.0, 0.70, 1.0)
        win.configure(bg=f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}")
        win.bind("<Button-1>", lambda event, i=idx: choose_number(i))
        win.deiconify()
        win.update_idletasks()
        hwnd = user32.GetAncestor(wintypes.HWND(win.winfo_id()), GA_ROOT)
        if not hwnd:
            hwnd = wintypes.HWND(win.winfo_id())
        if not user32.SetWindowPos(hwnd, HWND_TOPMOST, int(x0), int(y0), int(w), int(h), SWP_NOACTIVATE | SWP_SHOWWINDOW):
            win.destroy()
            raise ctypes.WinError()
        controller.overlays.append(win)


def choose_number(index):
    if _shutdown_requested() or controller is None:
        return
    if index >= len(controller.overlays) or index >= len(controller.overlay_targets):
        return
    selected_win = controller.overlays[index]
    all_windows = list(controller.overlays)
    controller.select_target(controller.overlay_targets[index])
    for i, win in enumerate(all_windows):
        if i != index:
            win.destroy()
    controller.overlays = [selected_win]
    controller.overlay_targets = [controller.target]
    with controller.input_gate_lock:
        controller.user_interrupt_event.clear()
        controller.stop_event.clear()
        controller.arming = True
        controller.arming_ignore_until = time.monotonic() + 0.18
        controller.input_enabled = False
    fade_selected(selected_win, 0)


def fade_selected(win, frame):
    if _shutdown_requested():
        try:
            if win.winfo_exists():
                win.destroy()
        except Exception:
            pass
        return
    if controller is None:
        return
    if controller.arming and (controller.stop_event.is_set() or controller.user_interrupt_event.is_set()):
        try:
            if win.winfo_exists():
                win.destroy()
        except Exception:
            pass
        controller.overlays = []
        controller.overlay_targets = []
        controller.overlay_mode = False
        with controller.input_gate_lock:
            controller.arming = False
            controller.input_enabled = False
        controller.clear_user_interrupt()
        controller.stop_event.clear()
        controller._clear_target_tracking()
        _show_main_with_status("启动已取消。可重新选择模式。")
        return
    if not win.winfo_exists():
        return
    total = 30
    if frame >= total:
        win.destroy()
        controller.overlays = []
        controller.overlay_targets = []
        controller.overlay_mode = False
        if not controller.start("grow"):
            with controller.input_gate_lock:
                was_cancelled = controller.user_interrupt_event.is_set() or controller.stop_event.is_set()
                controller.arming = False
                controller.input_enabled = False
            if was_cancelled:
                controller.clear_user_interrupt()
                controller.stop_event.clear()
                controller._clear_target_tracking()
                _show_main_with_status("启动已取消。可重新选择模式。")
            else:
                dependency_failed("用户输入监听不可用，AI不会开始控制。")
        return
    alpha = 0.36 * (1.0 - frame / total)
    win.attributes("-alpha", max(0.01, alpha))
    root.after(100, lambda: fade_selected(win, frame + 1))


def _clear_overlays_and_show_error(text):
    if controller is not None:
        controller.clear_user_interrupt()
        controller.stop_event.set()
        with controller.input_gate_lock:
            controller.input_enabled = False
            controller.arming = False
        controller.overlay_mode = False
        controller.system_stop_reason = str(text)
        try:
            controller._release_all_inputs()
        except Exception:
            pass
        controller._clear_target_tracking()
        for win in list(controller.overlays):
            try:
                if win.winfo_exists():
                    win.destroy()
            except tk.TclError:
                continue
        controller.overlays = []
        controller.overlay_targets = []
    _show_main_with_status(text)


def _show_main_with_status(text):
    if _shutdown_requested() or root is None:
        return
    text = str(text)
    is_error = any(token in text for token in ("出错", "失败", "不可用", "未识别", "拒绝"))
    _apply_progress({
        "value": 100 if not is_error else 0,
        "phase": "已停止" if is_error else "已就绪",
        "text": text,
        "detail": "AI 当前不控制鼠标或键盘。可重新选择模式。",
        "mode": "determinate",
    })
    if controller is not None and controller.input_hooks_ready.is_set():
        number_button.config(state="normal", command=scan_numbers)
        free_button.config(state="normal", command=start_free)
    else:
        number_button.config(state="disabled")
        free_button.config(state="disabled")
    _refresh_info_vars()
    root.deiconify()
    root.lift()


def show_main_user_control():
    _show_main_with_status("已检测到你的鼠标或键盘输入，AI已停止。")


def show_main_agent_stopped(reason):
    _show_main_with_status(reason)


def _tk_callback_exception(exc_type, exc_value, exc_tb):
    exc = exc_value if isinstance(exc_value, BaseException) else RuntimeError(str(exc_value))
    if controller is not None:
        controller.handle_runtime_error(exc, "界面/扫描回调")
    else:
        dependency_failed(f"运行出错：{exc}")


def shutdown():
    global shutdown_started
    with shutdown_lock:
        if shutdown_started:
            return
        shutdown_started = True

    shutdown_event.set()
    app_alive.clear()

    if root is not None:
        try:
            root.withdraw()
        except tk.TclError:
            pass

    agent_thread = None
    if controller is not None:
        try:
            controller.stop_event.set()
        except Exception:
            pass
        try:
            with controller.input_gate_lock:
                controller.input_enabled = False
        except Exception:
            try:
                controller.input_enabled = False
            except Exception:
                pass
        try:
            controller.clear_user_interrupt()
        except Exception:
            pass
        try:
            controller._release_all_inputs()
        except Exception:
            pass
        try:
            controller.overlay_mode = False
            for win in list(controller.overlays):
                try:
                    win.destroy()
                except Exception:
                    pass
            controller.overlays = []
            controller.overlay_targets = []
        except Exception:
            pass
        try:
            if controller.hook_thread_id:
                user32.PostThreadMessageW(controller.hook_thread_id, WM_QUIT, 0, 0)
        except Exception:
            pass
        try:
            with controller.lock:
                agent_thread = controller.agent_thread
        except Exception:
            agent_thread = getattr(controller, "agent_thread", None)

    terminate_child_processes()

    deadline = time.monotonic() + 1.5
    threads = [bootstrap_thread, hardware_thread, hook_thread, scan_thread, agent_thread]
    seen = set()
    for thread in threads:
        if thread is None or thread is threading.current_thread() or id(thread) in seen:
            continue
        seen.add(id(thread))
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            thread.join(timeout=min(0.5, remaining))
        except Exception:
            pass

    if controller is not None:
        try:
            controller._save_state()
        except Exception:
            pass

    if root is not None:
        try:
            root.destroy()
        except Exception:
            pass


def run_application():
    global bootstrap_thread
    try:
        if not initialize_ui_and_storage():
            return
        if _shutdown_requested():
            return
        root.report_callback_exception = _tk_callback_exception
        bootstrap_thread = threading.Thread(target=bootstrap_dependencies, name="MakeItBiggerBootstrap", daemon=True)
        bootstrap_thread.start()
        root.mainloop()
    except Exception as exc:
        app_alive.clear()
        terminate_child_processes()
        if controller is not None:
            try:
                controller.stop_event.set()
            except Exception:
                pass
            try:
                with controller.input_gate_lock:
                    controller.input_enabled = False
            except Exception:
                pass
            try:
                controller._release_all_inputs()
            except Exception:
                pass
            try:
                if controller.hook_thread_id:
                    user32.PostThreadMessageW(controller.hook_thread_id, WM_QUIT, 0, 0)
            except Exception:
                pass
        if show_startup_error(exc):
            root.report_callback_exception = _tk_callback_exception
            try:
                root.mainloop()
            except Exception:
                pass


run_application()
